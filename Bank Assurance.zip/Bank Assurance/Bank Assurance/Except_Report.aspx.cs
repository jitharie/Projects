﻿using System;
using System.Data;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Bank_Assurance.Controller;
using Bank_Assurance.Other;

namespace Bank_Assurance
{
    public partial class Except_Report : System.Web.UI.Page
    {
        PlanController control = new PlanController();
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                if (!IsPostBack)
                {
                    txtDays.Text = "30";
                    DataSet visits = control.getVisitTypeChange(-30);
                    if (visits.Tables[0].Rows.Count > 0)
                    {
                        vstTypeChange_View.DataSource = visits;
                        vstTypeChange_View.DataBind();
                    }

                    DataSet banks = control.getBankVisitChange(-30);
                    if (banks.Tables[0].Rows.Count > 0)
                    {
                        vstBankChange_View.DataSource = banks;
                        vstBankChange_View.DataBind();
                    }
                }

            }
            catch (Exception ex)
            {
                WebMsgBox.Show(ex.Message);
            }
        }

        protected void btnSearch_Click(object sender, EventArgs e)
        {
            int days = 0;
            if (txtDays.Text != "" && txtDays.Text != null)
            {
                days = Convert.ToInt32("-" + txtDays.Text);
            }

            DataSet visits = control.getVisitTypeChange(days);
            if (visits.Tables[0].Rows.Count > 0)
            {
                vstTypeChange_View.DataSource = visits;
                vstTypeChange_View.DataBind();
            }
            else
            {
                vstTypeChange_View.DataSource = null;
                vstTypeChange_View.DataBind();
            }

            DataSet banks = control.getBankVisitChange(days);
            if (banks.Tables[0].Rows.Count > 0)
            {
                vstBankChange_View.DataSource = banks;
                vstBankChange_View.DataBind();
            }
            else
            {
                vstBankChange_View.DataSource = null;
                vstBankChange_View.DataBind();
            }
        }
    }
}