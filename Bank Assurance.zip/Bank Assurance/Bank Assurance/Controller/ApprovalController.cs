﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using Microsoft.ApplicationBlocks.Data;
using System.Configuration;

namespace Bank_Assurance.Controller
{
    public class ApprovalController
    {
        string strConnString = ConfigurationManager.ConnectionStrings["dwhConnStr"].ConnectionString;
        public DataSet getUsernamestoddl()
        {
            string Query = @"select NAME,EMPID from Password_New_System a, (select distinct USER_ID from .[BANK_ASS_ITINERARY]) b
                            where a.EMPID=b.USER_ID";
            return SqlHelper.ExecuteDataset(strConnString, CommandType.Text, Query);
        }

        

        public DataSet getdetails_approval(string userID)
        {
            string Query = @"select CONVERT(varchar(10),b.ITINERARY_DATE,120) AS Date,b.VISIT_TYPE ,b.REMARKS as REMARKS,[dbo].BranchBank_format('ITINERARY',CONVERT(varchar(10),b.ITINERARY_DATE,120),USER_ID)as Bank_visits
                                from [BANK_ASS_ITINERARY]b
                                where USER_ID = '" + userID+ "' and  IS_APPROVED='No';";
            return SqlHelper.ExecuteDataset(strConnString, CommandType.Text, Query);
        }

        public int UpdateApprovedStatus(string day,string userID,string Aremarks,string status)
        {
            string Query = @"update [BANK_ASS_ITINERARY] set IS_APPROVED = '"+status+"', APPROVER_REMARKS ='"+Aremarks+"' where ITINERARY_DATE = '" + day+"' and USER_ID='"+userID+"';";
            return SqlHelper.ExecuteNonQuery(strConnString, CommandType.Text, Query);
        }

        
    }
}