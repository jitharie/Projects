﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using Microsoft.ApplicationBlocks.Data;
using System.Configuration;


namespace Bank_Assurance.Controller
{
    public class PlanController
    {
        string strConnString = ConfigurationManager.ConnectionStrings["dwhConnStr"].ConnectionString;

        public DataSet getVisitType()
        {
            string Query = "select DESCRIPTION from BANK_ASS_CODE Where TYPE = 'VISIT_TYPE'";

            return SqlHelper.ExecuteDataset(strConnString, CommandType.Text, Query);
        }

        public DataSet getBranch()
        {
            string Query = @"select LONGDESC as BRANCH_NAME, SHORTDESC as BRANCH_CODE
                             from cscsuboffice where SHORTDESC in (select distinct SUB_OFFICE_CODE from ACTIVE_SO)
                             order by LONGDESC";
            return SqlHelper.ExecuteDataset(strConnString, CommandType.Text, Query);
        }

        public DataSet getBank()
        {
            string Query = @"select DESCRIPTION,CODE
                            from BANK_ASS_CODE
                            where TYPE='BANK';
                            ";
            return SqlHelper.ExecuteDataset(strConnString, CommandType.Text, Query);
        }

        public DataSet getHolidays()
        {
            string Query = "Select Date from calender1";
            return SqlHelper.ExecuteDataset(strConnString, CommandType.Text, Query);
        }

        public DataSet getVisitTypeChange(int days)
        {
            string Query = "select b.USER_ID,CONVERT(varchar(10),b.ACTIVITY_DATE,120) AS ACTIVITY_DATE,a.VISIT_TYPE as ITINERARY, b.VISIT_TYPE as ACTIVITY,b.REMARKS as ACTIVITY_REMARKS" + Environment.NewLine +
                        "from [BANK_ASS_ITINERARY] a, [BANK_ASS_ACTIVITY] b" + Environment.NewLine +
                        "where " + Environment.NewLine +
                        "a.USER_ID=b.USER_ID and" + Environment.NewLine +
                        "a.ITINERARY_DATE=b.ACTIVITY_DATE and" + Environment.NewLine +
                        "a.VISIT_TYPE<>b.VISIT_TYPE and" + Environment.NewLine +
                        "b.ACTIVITY_DATE between dateadd(dd," + days + ",convert(datetime,substring(cast(getdate() as varchar) ,1,12))) and convert(datetime,substring(cast(getdate() as varchar) ,1,12)) " + Environment.NewLine +
                        "order by b.USER_ID,b.ACTIVITY_DATE";
            return SqlHelper.ExecuteDataset(strConnString, CommandType.Text, Query);
        }

        public DataSet getBankVisitChange(int days)
        {
            string Query = "select b.USER_ID,CONVERT(varchar(10),b.ACTIVITY_DATE,120) As ACTIVITY_DATE ,a.BRANCH_CODE+'-'+a.BANK_CODE  as ITINERARY, b.BRANCH_CODE+'-'+b.BANK_CODE as ACTIVITY" + Environment.NewLine +
                        "from [BANK_ASS_ITINERARY_BRANCH_BANK] a, [BANK_ASS_ACTIVITY_BRANCH_BANK] b" + Environment.NewLine +
                        "where " + Environment.NewLine +
                        "a.USER_ID=b.USER_ID and" + Environment.NewLine +
                        "a.ITINERARY_DATE=b.ACTIVITY_DATE and" + Environment.NewLine +
                        "(a.BRANCH_CODE+a.BANK_CODE<>b.BRANCH_CODE+b.BANK_CODE ) and" + Environment.NewLine +
                        "b.ACTIVITY_DATE between dateadd(dd," + days + ",convert(datetime,substring(cast(getdate() as varchar) ,1,12))) and convert(datetime,substring(cast(getdate() as varchar) ,1,12)) " + Environment.NewLine +
                        "order by b.USER_ID,b.ACTIVITY_DATE";
            return SqlHelper.ExecuteDataset(strConnString, CommandType.Text, Query);

        }
    }
}