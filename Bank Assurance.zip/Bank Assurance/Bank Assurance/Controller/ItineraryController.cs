﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using Microsoft.ApplicationBlocks.Data;
using System.Configuration;


namespace Bank_Assurance.Controller
{
    public class ItineraryController
    {
        string strConnString = ConfigurationManager.ConnectionStrings["dwhConnStr"].ConnectionString;

        public int InsertInineraryValues(string Date, string UserID, string visitType, string remarks, string CIP, string status)
        {
            SqlParameter[] param = null;
            string Query = @"INSERT INTO [BANK_ASS_ITINERARY]
                               ([ITINERARY_DATE]
                               ,[USER_ID]
                               ,[VISIT_TYPE]
                               ,[REMARKS]
                               ,[CREATE_DATE]
                               ,[CREATE_IP]
                               ,[IS_APPROVED]) 
                                values ('" + Date + "','" + UserID + "','" + visitType + "','" + remarks + "',getdate(),'" + CIP + "','" + status + "')";

            return SqlHelper.ExecuteNonQuery(strConnString, CommandType.Text, Query, param);
        }

        public int InsertInineraryBankBranch(string Date, string UserID, string Bank, string Branch)
        {
            SqlParameter[] param = null;
            string Query = "INSERT INTO [BANK_ASS_ITINERARY_BRANCH_BANK] values ('" + Date + "','" + UserID + "','" + Bank + "','" + Branch + "')";

            return SqlHelper.ExecuteNonQuery(strConnString, CommandType.Text, Query, param);

        }

        public DataSet getBankItineraryDetails(string date, string userid)
        {
            string Query = @"Select CONVERT(varchar(10),ITINERARY_DATE,120) as DATE,BRANCH_CODE,BANK_CODE
                            from [BANK_ASS_ITINERARY_BRANCH_BANK] 
                            where ITINERARY_DATE ='" + date + "' and USER_ID = '" + userid + "'";
            return SqlHelper.ExecuteDataset(strConnString, CommandType.Text, Query);
        }

        public int DeletefromBankItinerary(string date, string userid)
        {
            string Query = @"delete from BANK_ASS_ITINERARY where ITINERARY_DATE = '" + date + "' and USER_ID='" + userid + "'"; ;
            return SqlHelper.ExecuteNonQuery(strConnString, CommandType.Text, Query);
        }

        public int DeletefromBBankItinerary(string date, string userid)
        {
            string Query = @"delete from [BANK_ASS_ITINERARY_BRANCH_BANK] where ITINERARY_DATE = '" + date + "' and USER_ID='" + userid + "'"; ;
            return SqlHelper.ExecuteNonQuery(strConnString, CommandType.Text, Query);
        }



        public string checkBankItinerary(string date, string userid)
        {
            string Query = @"select COUNT(CONVERT(varchar(10),ITINERARY_DATE,120))as Date 
                             from [BANK_ASS_ITINERARY_BRANCH_BANK]
                             where ITINERARY_DATE ='" + date + "' and USER_ID='" + userid + "'";
            return Convert.ToString(SqlHelper.ExecuteScalar(strConnString, CommandType.Text, Query));
        }

        public int DeletefromItineraryBB(string Bank, string userid)
        {
            string Query = @"delete from [BANK_ASS_ITINERARY_BRANCH_BANK] where BANK_CODE='" + Bank + "' and USER_ID = '" + userid + "'";
            return SqlHelper.ExecuteNonQuery(strConnString, CommandType.Text, Query);
        }

        public DataSet fillDetailsGrid(string userID)
        {
            string Query = @"Select CONVERT(varchar(10),ITINERARY_DATE,120) as DATE,VISIT_TYPE,REMARKS,IS_APPROVED
                                from [BANK_ASS_ITINERARY] 
                                where USER_ID='" + userID + "' order by ITINERARY_DATE";
            return SqlHelper.ExecuteDataset(strConnString, CommandType.Text, Query);
        }

        public DataSet findnextholiday(string selectedDate)
        {
            string Query = "select * from calender1 where Date > '" + selectedDate + "'";
            return SqlHelper.ExecuteDataset(strConnString, CommandType.Text, Query);
        }

        public int countB_Ass_Itinerary(string selectdate, string firstday, string userid)
        {
            string Query = @"select count(USER_ID)as count_no FROM [BANK_ASS_ITINERARY] where USER_ID='" + userid + "' AND ITINERARY_DATE BETWEEN '" + selectdate + "' AND '" + firstday + "'";
            return Convert.ToInt32(SqlHelper.ExecuteScalar(strConnString, CommandType.Text, Query));

        }

        public string getLastenterdate(string user)
        {
            string Query = "select Max(CONVERT(varchar(10),ITINERARY_DATE,120)) From BANK_ASS_ITINERARY Where USER_ID = '" + user + "'";
            return Convert.ToString(SqlHelper.ExecuteScalar(strConnString, CommandType.Text, Query));
        }

        public DataSet getItinerary(string userID, string fDate, string tDate)
        {
            string Query = @"SELECT CONVERT(VARCHAR(10),[ITINERARY_DATE],120) AS ITINERARY_DATE,[VISIT_TYPE],[REMARKS],dbo.[BranchBank_format]('ITINERARY',CONVERT(VARCHAR(10),[ITINERARY_DATE],120),USER_ID) AS BANKS,[IS_APPROVED]
                            FROM [BANK_ASS_ITINERARY]
                            WHERE USER_ID='" + userID + "'  AND CONVERT(VARCHAR(10),[ITINERARY_DATE],120) BETWEEN '" + fDate + "' AND '" + tDate + "'";
            return SqlHelper.ExecuteDataset(strConnString, CommandType.Text, Query);
        }

        public string getusername (string userID)
        {
            string Query = @"select NAME from Password_New_System where EMPID='"+userID+"'";
            return Convert.ToString(SqlHelper.ExecuteScalar(strConnString, CommandType.Text, Query));
        }
       
        public string getApproverEmail()
        {
            string Query = @"select Email from Password_New_System where EMPID=(select top 1 CODE from [BANK_ASS_CODE] where TYPE = 'APPROVER')";
            return Convert.ToString(SqlHelper.ExecuteScalar(strConnString, CommandType.Text, Query));
        }
    }
}