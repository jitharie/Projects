﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using Microsoft.ApplicationBlocks.Data;
using System.Configuration;

namespace Bank_Assurance.Controller
{
    public class ActualController
    {
        string strConnString = ConfigurationManager.ConnectionStrings["dwhConnStr"].ConnectionString;
        public DataSet getSalesOfficers(string branch)
        {
            string Query = "SELECT NAME_ADD,SO_CODE FROM ACTIVE_SO WHERE SUB_OFFICE_CODE='" + branch + "'";
            return SqlHelper.ExecuteDataset(strConnString, CommandType.Text, Query);
        }

        public int insertVisit(string ac_Date, string user, string type, string remark, string cr_date, string ip)
        {
            string Query = "INSERT INTO BANK_ASS_ACTIVITY (ACTIVITY_DATE,USER_ID,VISIT_TYPE,REMARKS,CREATE_DATE,CREATE_IP)" +
                          "VALUES ('" + ac_Date + "','" + user + "','" + type + "','" + remark + "','" + cr_date + "','" + ip + "')";
            return SqlHelper.ExecuteNonQuery(strConnString, CommandType.Text, Query);
        }

        public int insertVisitAgent(string ac_Date, string user, string agentNo, string agent)
        {
            string Query = "INSERT INTO BANK_ASS_ACTIVITY_AGENT (ACTIVITY_DATE,USER_ID,AGENT_NO,AGENT_NAME)" +
                            "VALUES('" + ac_Date + "','" + user + "','" + agentNo + "','" + agent + "')";
            return SqlHelper.ExecuteNonQuery(strConnString, CommandType.Text, Query);
        }

        public int insertVisitBanks(string ac_Date, string user, string branch, string bank, string remarks)
        {
            string Query = "INSERT INTO BANK_ASS_ACTIVITY_BRANCH_BANK(ACTIVITY_DATE,USER_ID,BRANCH_CODE,BANK_CODE,REMARKS)" +
                            "VALUES('" + ac_Date + "','" + user + "','" + branch + "','" + bank + "','" + remarks + "')";
            return SqlHelper.ExecuteNonQuery(strConnString, CommandType.Text, Query);
        }

        public int insertFieldVisit(string ac_Date, string user, string cus_type, string policyNo, string cusName, string remarks)
        {
            string Query = "INSERT INTO [BANK_ASS_ACTIVITY_FIELD_VISITS]([ACTIVITY_DATE],[USER_ID]," +
                            "[CUSTOMER_TYPE],[CUSTOMER_POLICY_NO],[CUSTOMER_NAME],[REMARKS])" +
                            "VALUES('" + ac_Date + "','" + user + "','" + cus_type + "','" + policyNo + "','" + cusName + "','" + remarks + "')";
            return SqlHelper.ExecuteNonQuery(strConnString, CommandType.Text, Query);
        }

        public DataSet getInsertedActivities()
        {
            string Query = "  SELECT ACTIVITY_DATE FROM [BANK_ASS_ACTIVITY] WHERE DATEDIFF(day,ACTIVITY_DATE,GETDATE())<10";
            return SqlHelper.ExecuteDataset(strConnString, CommandType.Text, Query);
        }

        public DataSet getActivities(string userID, string fDate, string tDate)
        {
            string Query = @"SELECT CONVERT(VARCHAR(10),[ACTIVITY_DATE],120) AS ACTIVITY_DATE,[VISIT_TYPE],[REMARKS],
                            dbo.[BranchBank_format]('ACTUAL',CONVERT(VARCHAR(10),[ACTIVITY_DATE],120),USER_ID) AS BANKS
                            FROM [mis].[BANK_ASS_ACTIVITY]
                            WHERE USER_ID='" + userID + "'  AND CONVERT(VARCHAR(10),[ACTIVITY_DATE],120) BETWEEN '" + fDate + "' AND '" + tDate + "'";
            return SqlHelper.ExecuteDataset(strConnString, CommandType.Text, Query);
        }
    }
}