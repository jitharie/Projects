﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using Microsoft.ApplicationBlocks.Data;
using System.Configuration;

namespace Bank_Assurance.Controller
{
    public class LoginController
    {
        string strConnString = ConfigurationManager.ConnectionStrings["dwhConnStr"].ConnectionString;

        public DataSet getUsers(string username, string password)
        {
            string Query = @"SELECT PASSWORD_NEW_SYSTEM.EMPID,PASSWORD_NEW_SYSTEM.PID," + Environment.NewLine +
                              @"PASSWORD_NEW_SYSTEM.NAME, PASSWORD_NEW_SYSTEM.BRANCH, " + Environment.NewLine +
                              @"PASSWORD_NEW_SYSTEM.USERTYPE" + Environment.NewLine +
                              @"FROM  DBO.PASSWORD_NEW_SYSTEM " + Environment.NewLine +
                              @"WHERE ((PASSWORD_NEW_SYSTEM.EMPID = '" + username + "') OR (PASSWORD_NEW_SYSTEM.PID = '" + username + "'))" + Environment.NewLine +
                             @"AND (PASSWORD_NEW_SYSTEM.PASSWORDED = '" + password + "') AND (PASSWORD_NEW_SYSTEM.STATUS = 'ACTIVE')";

            return SqlHelper.ExecuteDataset(strConnString, CommandType.Text, Query);
        }

        public DataSet getSuperUsers(string user)
        {
            string Query = "SELECT TYPE,CODE FROM BANK_ASS_CODE WHERE  CODE='" + user + "'";
            return SqlHelper.ExecuteDataset(strConnString, CommandType.Text, Query);
        }
    }
}