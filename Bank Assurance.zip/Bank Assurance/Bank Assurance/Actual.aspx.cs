﻿using System;
using System.Data;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Bank_Assurance.Controller;
using Bank_Assurance.Other;
using System.Net;

namespace Bank_Assurance
{
    public partial class Actual : System.Web.UI.Page
    {
        PlanController control = new PlanController();
        ActualController control1 = new ActualController();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                loadVisitType();
                loadBranch();
                loadBank();

                DataTable dt = new DataTable();
                for (int i = 0; i < 5; i++)
                {
                    DataRow toInsert = dt.NewRow();
                    dt.Rows.InsertAt(toInsert, i);
                }
                visitview.DataSource = dt;
                visitview.DataBind();
            }
        }
        protected void CalendarActual_DayRender(object sender, DayRenderEventArgs e)
        {
            try
            {
                TimeSpan diff = e.Day.Date - DateTime.Today;
                double days = diff.TotalDays;

                if (e.Day.Date > DateTime.Today || days < -10)
                {
                    e.Day.IsSelectable = false;
                    e.Cell.ForeColor = System.Drawing.Color.Gray;
                }

                if (e.Day.IsOtherMonth)
                {
                    e.Cell.Text = "";
                }

                DataSet holidays = control.getHolidays();
                if (holidays.Tables[0].Rows.Count > 0)
                {
                    for (int i = 0; i < holidays.Tables[0].Rows.Count; i++)
                    {
                        string holiday = Convert.ToDateTime(holidays.Tables[0].Rows[i][0].ToString()).ToString("yyyy-MM-dd");
                        string current = Convert.ToDateTime(e.Day.Date).ToString("yyyy-MM-dd");
                        if (holiday.Equals(current))
                        {
                            e.Cell.ForeColor = System.Drawing.Color.Red;
                            e.Day.IsSelectable = false;
                        }
                    }
                }

               DataSet assignedDates = control1.getInsertedActivities();
               if (assignedDates.Tables[0].Rows.Count>0)
               {
                    for (int i = 0; i < assignedDates.Tables[0].Rows.Count; i++)
                    {
                        string activityDate = Convert.ToDateTime(assignedDates.Tables[0].Rows[i][0].ToString()).ToString("yyyy-MM-dd");
                        string current = Convert.ToDateTime(e.Day.Date).ToString("yyyy-MM-dd");
                        if (activityDate.Equals(current))
                        {
                            e.Cell.BackColor = System.Drawing.Color.Green;
                            e.Day.IsSelectable = false;
                        }
                    }
                }

            }
            catch (Exception ex)
            {
                WebMsgBox.Show(ex.Message);
            }
        }
        protected void CalendarActual_SelectionChanged(object sender, EventArgs e)
        {
            string date = CalendarActual.SelectedDate.ToString("yyyy-MM-dd");
            txtAct_Date.Text = date;
        }
        protected void ddlBranch_SelectedIndexChanged(object sender, EventArgs e)
        {
            string branch = ddlBranch.SelectedItem.ToString();
            if (!branch.Equals("--Select--"))
            {
                string branch_code = ddlBranch.SelectedItem.Value;
                loadSalesOfficers(branch_code);
            }
        }
        protected void ddlBank_SelectedIndexChanged(object sender, EventArgs e)
        {
            string branch_code = ddlBranch.SelectedItem.Value;
            string bank = ddlBank.SelectedItem.ToString();
            if (!bank.Equals("--Select--"))
            {
                string bank_code = ddlBank.SelectedItem.Value;
                addBank(branch_code, bank_code);
            }

            ddlBank.SelectedIndex = 0;
        }
        protected void ddlSalesOffi_SelectedIndexChanged(object sender, EventArgs e)
        {
            string sales = ddlSalesOffi.SelectedItem.ToString();
            if (!sales.Equals("--Select--"))
            {
                string socode = ddlSalesOffi.SelectedItem.Value;
                addSalesOfficer(socode, sales);
            }
        }
        protected void salesOfView_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            int index = Convert.ToInt32(e.RowIndex);
            DataTable dt = ViewState["CurrentTable"] as DataTable;
            dt.Rows[index].Delete();
            salesOfView.DataSource = ViewState["CurrentTable"] as DataTable;
            salesOfView.DataBind();
        }
        protected void dgvBBDetails_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            int index = Convert.ToInt32(e.RowIndex);
            DataTable dt = ViewState["CurrentTable1"] as DataTable;
            dt.Rows[index].Delete();
            dgvBBDetails.DataSource = ViewState["CurrentTable1"] as DataTable;
            dgvBBDetails.DataBind();
        }
        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            string ip = getLocalIPAddress();
            string user = Session["Log_EmpID"].ToString();
            string create_Dt = DateTime.Now.ToString("yyyy-MM-dd");
            string remark = txtRemarks.Text;
            if (CalendarActual.SelectedDate != DateTime.MinValue)
            {
                string activityDate = CalendarActual.SelectedDate.ToString("yyyy-MM-dd");
                if (ddlVisittype.SelectedItem.ToString() != "--Select--")
                {
                    string visit_type = ddlVisittype.SelectedItem.ToString();
                    int res = control1.insertVisit(activityDate, user, visit_type, remark, create_Dt, ip);
                    if (res > 0)
                    {
                        foreach (GridViewRow row in salesOfView.Rows)
                        {
                            string socode = row.Cells[0].Text;
                            string name = row.Cells[1].Text;
                            control1.insertVisitAgent(activityDate, user, socode, name);
                        }

                        foreach (GridViewRow row in dgvBBDetails.Rows)
                        {
                            string branch = row.Cells[0].Text;
                            string bank = row.Cells[1].Text;
                            TextBox txtbank = (TextBox)row.FindControl("bankRemarks");
                            string remk = txtbank.Text;
                            control1.insertVisitBanks(activityDate, user, branch, bank, remark);
                        }

                        foreach (GridViewRow row in visitview.Rows)
                        {
                            DropDownList custType = (DropDownList)row.FindControl("vistTypeList");
                            string cus_type = custType.SelectedItem.ToString();
                            TextBox tCus = (TextBox)row.FindControl("txtCustomer");
                            TextBox tRe = (TextBox)row.FindControl("txtvistRemarks");
                            if (tCus.Text.Length > 1 || tRe.Text.Length > 1)
                            {
                                string policy = "";
                                string cusName = "";
                                string remks = tRe.Text;
                                if (cus_type.Equals("New"))
                                {
                                    cusName = tCus.Text;
                                }
                                else
                                {
                                    policy = tCus.Text;
                                }

                                control1.insertFieldVisit(activityDate, user, cus_type, policy, cusName, remks);
                            }
                        }
                        WebMsgBox.Show("Successfully Inserted");
                        clear();
                    }
                    else
                    {
                        WebMsgBox.Show("Not Inserted");
                    }
                }
                else
                {
                    WebMsgBox.Show("Select the visit type ");
                }
            }
            else
            {
                WebMsgBox.Show("Select the activity date ");
            }
        }
        private void loadVisitType()
        {
            try
            {
                ddlVisittype.Items.Clear();
                DataSet visit = control.getVisitType();
                ddlVisittype.Items.Insert(0, "--Select--");
                if (visit.Tables[0].Rows.Count > 0)
                {
                    for (int i = 0; i < visit.Tables[0].Rows.Count; i++)
                    {
                        ddlVisittype.Items.Insert(i + 1, visit.Tables[0].Rows[i][0].ToString());
                    }
                }
            }
            catch (Exception ex)
            {
                WebMsgBox.Show(ex.Message);
            }
        }
        private void loadBranch()
        {
            try
            {
                ddlBranch.Items.Clear();
                DataSet branch = control.getBranch();
                ddlBranch.Items.Insert(0, "--Select--");
                if (branch.Tables[0].Rows.Count > 0)
                {
                    for (int i = 0; i < branch.Tables[0].Rows.Count; i++)
                    {
                        ddlBranch.Items.Insert(i + 1, new ListItem(branch.Tables[0].Rows[i][0].ToString(), branch.Tables[0].Rows[i][1].ToString()));
                    }
                }
            }
            catch (Exception ex)
            {
                WebMsgBox.Show(ex.Message);
            }
        }
        private void loadBank()
        {
            try
            {
                ddlBank.Items.Clear();
                DataSet bank = control.getBank();
                ddlBank.Items.Insert(0, "--Select--");
                if (bank.Tables[0].Rows.Count > 0)
                {
                    for (int i = 0; i < bank.Tables[0].Rows.Count; i++)
                    {
                        ddlBank.Items.Insert(i + 1, new ListItem(bank.Tables[0].Rows[i][0].ToString(), bank.Tables[0].Rows[i][1].ToString()));
                    }
                }
            }
            catch (Exception ex)
            {
                WebMsgBox.Show(ex.Message);
            }
        }
        private void loadSalesOfficers(string branch)
        {
            try
            {
                ddlSalesOffi.Items.Clear();
                DataSet sales = control1.getSalesOfficers(branch);
                ddlSalesOffi.Items.Insert(0, "--Select--");
                if (sales.Tables[0].Rows.Count > 0)
                {
                    for (int i = 0; i < sales.Tables[0].Rows.Count; i++)
                    {
                        ddlSalesOffi.Items.Insert(i + 1, new ListItem(sales.Tables[0].Rows[i][0].ToString(), sales.Tables[0].Rows[i][1].ToString()));
                    }
                }
            }
            catch (Exception ex)
            {
                WebMsgBox.Show(ex.Message);
            }
        }
        private void addSalesOfficer(string code, string name)
        {
            int rCount = salesOfView.Rows.Count;
            if (rCount == 0)
            {
                DataTable dt = new DataTable();
                DataRow dr = null;
                dt.Columns.Add(new DataColumn("code", typeof(string)));
                dt.Columns.Add(new DataColumn("sales", typeof(string)));

                dr = dt.NewRow();
                dr[0] = code;
                dr[1] = name;
                dt.Rows.Add(dr);

                ViewState["CurrentTable"] = dt;

                salesOfView.DataSource = dt;
                salesOfView.DataBind();
            }
            else
            {
                if (ViewState["CurrentTable"] != null)
                {
                    int rowCount = ((DataTable)ViewState["CurrentTable"]).Rows.Count;
                    DataTable dtCurrentTable = (DataTable)ViewState["CurrentTable"];
                    if (rowCount > 0)
                    {
                        bool exists = true;
                        foreach (GridViewRow row in salesOfView.Rows)
                        {

                            string scode = row.Cells[0].Text;
                            if (!code.Equals(scode))
                            {
                                exists = false;
                            }
                            else
                            {
                                exists = true;
                                break;
                            }

                        }

                        if (!exists)
                        {
                            DataRow drCurrentRow = dtCurrentTable.NewRow();
                            drCurrentRow[0] = code;
                            drCurrentRow[1] = name;

                            dtCurrentTable.Rows.Add(drCurrentRow);
                            ViewState["CurrentTable"] = dtCurrentTable;

                            salesOfView.DataSource = dtCurrentTable;
                            salesOfView.DataBind();
                            lbMsgSales.Text = "";
                        }
                        else
                        {
                            lbMsgSales.Text = name + " already Exists";
                        }
                    }

                }

            }
        }
        private void addBank(string branch, string bank)
        {
            int rCount = dgvBBDetails.Rows.Count;
            if (rCount == 0)
            {
                DataTable dt = new DataTable();
                DataRow dr = null;
                dt.Columns.Add(new DataColumn("branch", typeof(string)));
                dt.Columns.Add(new DataColumn("bank", typeof(string)));

                dr = dt.NewRow();
                dr[0] = branch;
                dr[1] = bank;
                dt.Rows.Add(dr);
                ViewState["CurrentTable1"] = dt;

                dgvBBDetails.DataSource = dt;
                dgvBBDetails.DataBind();
            }
            else
            {
                if (ViewState["CurrentTable1"] != null)
                {
                    int rowCount = ((DataTable)ViewState["CurrentTable1"]).Rows.Count;
                    DataTable dtCurrentTable = (DataTable)ViewState["CurrentTable1"];
                    if (rowCount > 0)
                    {
                        bool exists = true;
                        foreach (GridViewRow row in dgvBBDetails.Rows)
                        {
                            string t = row.Cells[0].Text + "-" + row.Cells[1].Text;
                            if (!t.Equals(branch + "-" + bank))
                            {
                                exists = false;
                            }
                            else
                            {
                                exists = true;
                                break;
                            }
                        }
                        if (!exists)
                        {
                            DataRow drCurrentRow = dtCurrentTable.NewRow();
                            drCurrentRow[0] = branch;
                            drCurrentRow[1] = bank;

                            dtCurrentTable.Rows.Add(drCurrentRow);
                            ViewState["CurrentTable1"] = dtCurrentTable;

                            dgvBBDetails.DataSource = dtCurrentTable;
                            dgvBBDetails.DataBind();
                            lbMsgSales.Text = "";
                        }
                        else
                        {
                            lbMsgbank.Text = branch + "-" + bank + " already Exists";
                        }
                    }
                }
            }
        }
        private string getLocalIPAddress()
        {
            var host = Dns.GetHostEntry(Dns.GetHostName());
            foreach (var ip in host.AddressList)
            {
                if (ip.AddressFamily == System.Net.Sockets.AddressFamily.InterNetwork)
                {
                    return ip.ToString();
                }
            }
            throw new Exception("Local IP Address Not Found!");
        }
        private void clear()
        {
            txtAct_Date.Text = "";
            ddlVisittype.SelectedIndex = 0;
            ddlBank.SelectedIndex = 0;
            ddlBranch.SelectedIndex = 0;
            ddlSalesOffi.SelectedIndex = 0;

            dgvBBDetails.DataSource = null;
            dgvBBDetails.DataBind();

            salesOfView.DataSource = null;
            salesOfView.DataBind();

            visitview.DataSource = null;
            visitview.DataBind();

            DataTable dt = new DataTable();
            for (int i = 0; i < 5; i++)
            {
                DataRow toInsert = dt.NewRow();
                dt.Rows.InsertAt(toInsert, i);
            }
            visitview.DataSource = dt;
            visitview.DataBind();

            txtRemarks.Text = "";

        }     
    }
}