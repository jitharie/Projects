﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Bank_Assurance.Controller;
using System.Data;
using Bank_Assurance.Other;

namespace Bank_Assurance
{
    public partial class ApproveForm : System.Web.UI.Page
    {
        ApprovalController Acontrol = new ApprovalController();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                getddldetails();
                if (ddluser.SelectedIndex == 0)
                {
                    visiblefalsefields();

                }
            }

        }

        public void getddldetails()
        {
            DataSet dsgetUser = Acontrol.getUsernamestoddl();
            ddluser.Items.Insert(0, "---------SELECT---------");
            for (int i = 0; i < dsgetUser.Tables[0].Rows.Count; i++)
            {
                ddluser.Items.Insert(i + 1, new ListItem(dsgetUser.Tables[0].Rows[i][0].ToString(), dsgetUser.Tables[0].Rows[i][1].ToString()));

            }
        }

        public void visiblefalsefields()
        {
            lblremarks.Visible = false;
            txtremarks.Visible = false;
            btnapprove.Visible = false;
            btnreject.Visible = false;
        }

        protected void ddluser_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(ddluser.SelectedIndex==0)
            {
                visiblefalsefields();
                dgvviewapproval.Visible = false;
            }
            else
            {
                binddatatogrid();
                lblremarks.Visible = true;
                txtremarks.Visible = true;
                btnapprove.Visible = true;
                btnreject.Visible = true;
                dgvviewapproval.Visible = true;
            }
            

        }

        public void binddatatogrid()
        {
            
            string user = ddluser.SelectedValue.ToString();
            Session["User_ID"] = user;
            DataSet dsbindDatatoGrid = Acontrol.getdetails_approval(user);
            dgvviewapproval.DataSource = dsbindDatatoGrid.Tables[0];
            dgvviewapproval.DataBind();

        }

        protected void dgvviewapproval_RowCommand(object sender, GridViewCommandEventArgs e)
        {

        }

        protected void btnapprove_Click(object sender, EventArgs e)
        {
            try
            {
                string RemarkTxt = txtremarks.Text;
                string status = "YES";
                string day, user;
                int res;

                foreach (GridViewRow row in dgvviewapproval.Rows)//Running all lines of grid
                {
                    if (row.RowType == DataControlRowType.DataRow)
                    {
                        CheckBox chkRow = (row.Cells[0].FindControl("chkRow") as CheckBox);
                        if (chkRow.Checked)
                        {
                            day = row.Cells[1].Text;
                            user = Session["User_ID"].ToString();
                            res = Acontrol.UpdateApprovedStatus(day, user, RemarkTxt, status);
                        }
                    }
                }

                txtremarks.Text = "";
                binddatatogrid();
                WebMsgBox.Show("Approved Successfully !!");

            }
            catch (Exception)
            {
                throw;
            }


        }

        protected void btnreject_Click(object sender, EventArgs e)
        {
            try
            {
                string RemarkTxt = txtremarks.Text;
                string status = "REJECTED";

                foreach (GridViewRow row in dgvviewapproval.Rows)//Running all lines of grid
                {
                    if (row.RowType == DataControlRowType.DataRow)
                    {
                        CheckBox chkRow = (row.Cells[0].FindControl("chkRow") as CheckBox);
                        if (chkRow.Checked)
                        {
                            string day = row.Cells[1].Text;
                            string user = Session["User_ID"].ToString();
                            int res = Acontrol.UpdateApprovedStatus(day, user, RemarkTxt, status);

                        }
                    }
                }

                txtremarks.Text = "";
                binddatatogrid();
                WebMsgBox.Show("Rejected Successfully !!");
            }
            catch(Exception)
            {
                throw;
            }
        }
    }
}