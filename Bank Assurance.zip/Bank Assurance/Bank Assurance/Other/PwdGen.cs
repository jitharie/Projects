﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Web;

namespace Bank_Assurance.Other
{
    public class PwdGen
    {

        static PwdGen()
        {

        }

        public static string Encrypt(string strText)
        {
            string strEncrypt = "&%#@?,:*";
            string str;
            byte[] rgbKey = new byte[20];
            byte[] rgbIV = new byte[] { 0x12, 0x34, 0x56, 120, 0x91, 0xab, 0xcd, 0xef };
            try
            {
                rgbKey = Encoding.UTF8.GetBytes(strEncrypt.Substring(0, 8));
                DESCryptoServiceProvider provider = new DESCryptoServiceProvider();
                byte[] bytes = Encoding.UTF8.GetBytes(strText);
                MemoryStream stream = new MemoryStream();
                CryptoStream stream2 = new CryptoStream(stream, provider.CreateEncryptor(rgbKey, rgbIV), CryptoStreamMode.Write);
                stream2.Write(bytes, 0, bytes.Length);
                stream2.FlushFinalBlock();
                str = Convert.ToBase64String(stream.ToArray());
            }
            catch (Exception exception)
            {
                throw exception;
            }
            return str;
        }

    }
}