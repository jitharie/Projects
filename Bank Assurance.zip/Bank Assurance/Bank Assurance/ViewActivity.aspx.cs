﻿using System;
using System.Data;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Bank_Assurance.Controller;
using Bank_Assurance.Other;

namespace Bank_Assurance
{
    public partial class ViewActivity : System.Web.UI.Page
    {
        ActualController control = new ActualController();
        ApprovalController Acontrol = new ApprovalController();
        protected void Page_Load(object sender, EventArgs e)
        {
            if(!IsPostBack)
            {
                getddldetails();
            }
           
        }

        protected void btnView_Click(object sender, EventArgs e)
        {
            try
            {
                string user = userList.SelectedValue.ToString();
                string fDate = Convert.ToDateTime(txtFDate.Text).ToString("yyyy-MM-dd");
                string tDate = Convert.ToDateTime(txtTDate.Text).ToString("yyyy-MM-dd");
                DataSet dt = control.getActivities(user, fDate, tDate);
                if (dt.Tables[0].Rows.Count > 0)
                {
                    activityView.DataSource = dt;
                    activityView.DataBind();
                }
            }
            catch (Exception ex)
            {
                WebMsgBox.Show(ex.Message);
            }
        }

        public void getddldetails()
        {
            try
            {
                userList.Items.Clear();
                DataSet dsgetUser = Acontrol.getUsernamestoddl();
                userList.Items.Insert(0, "---------SELECT---------");
                for (int i = 0; i < dsgetUser.Tables[0].Rows.Count; i++)
                {
                    userList.Items.Insert(i + 1, new ListItem(dsgetUser.Tables[0].Rows[i][0].ToString(), dsgetUser.Tables[0].Rows[i][1].ToString()));

                }
            }
            catch(Exception)
            {
                throw;
            }
            
        }
    }
}