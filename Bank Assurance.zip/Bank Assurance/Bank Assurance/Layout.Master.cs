﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Bank_Assurance.Controller;
using System.Data;

namespace Bank_Assurance
{
    public partial class Layout : System.Web.UI.MasterPage
    {
        LoginController control = new LoginController();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                //Set Username
                if (Session["Log_EmpName"] != null)
                {
                    lbUser.Text = "Welcome   " + Session["Log_EmpName"].ToString().Trim();
                    DataSet superUsers = control.getSuperUsers(Session["Log_EmpID"].ToString());
                    if (superUsers.Tables[0].Rows.Count != 0)
                    {
                        if (superUsers.Tables[0].Rows[0]["TYPE"].ToString() == "APPROVER")
                        {
                            mainTree.Nodes.RemoveAt(0);
                            mainTree.Nodes.RemoveAt(2);
                        }
                        else
                        {
                            mainTree.Nodes.RemoveAt(2);
                        }
                       
                    }
                }
                else
                {
                    Response.Write("Login.aspx");
                }

            }
        }

        protected void btnLogout(object sender, EventArgs e)
        {
            Session.Clear();
            Response.Redirect("Login.aspx");
        }
    }
}