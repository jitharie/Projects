﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using Bank_Assurance.Controller;
using System.Net;
using System.Net.Sockets;
using Bank_Assurance.Other;
using System.Net.Mail;

namespace Bank_Assurance
{
    public partial class Itinerary : System.Web.UI.Page
    {
        PlanController Control = new PlanController();
        ItineraryController IControl = new ItineraryController();
        
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                string UserID = Session["Log_EmpID"].ToString();
                getVisitType();
                getBranchType();
                getBankType();
                FillDetailsGrid();
                lblBank.Visible = false;
                lblBranch.Visible = false;
                ddlBank.Visible = false;
                ddlBranch.Visible = false;
                panelbottom.Visible = false;
                btnsave.Visible = false;
                DateTime lastgridDate;

                string lastdate = IControl.getLastenterdate(UserID);
                if(lastdate!="" && lastdate !=null )
                {
                   lastgridDate = Convert.ToDateTime(lastdate);
                }
                else
                {
                    lastgridDate = DateTime.Today.AddDays(-1);
                }

                DateTime today = DateTime.Today;
                CalendarItinerary.TodaysDate = today;
                CalendarItinerary.SelectedDate = today;

                if (lastgridDate>=today)
                {
                    CalendarItinerary.SelectedDate = lastgridDate;
                    getDatetocalander();
                }
                else
                {
                   CalendarItinerary.TodaysDate = today;
                   CalendarItinerary.SelectedDate = today;
                }                
            }

        }

        protected void getVisitType()
        {
            try
            {
                ddlVisittype.Items.Clear();

                DataSet dsgetvisittype = Control.getVisitType();
                ddlVisittype.Items.Insert(0, "--SELECT--");
                for (int i = 0; i < dsgetvisittype.Tables[0].Rows.Count; i++)
                {
                    ddlVisittype.Items.Insert((i + 1), dsgetvisittype.Tables[0].Rows[i][0].ToString());
                }

            }
            catch(Exception ex)
            {
                WebMsgBox.Show(ex.Message);
            }

        }


        protected void getBranchType()
        {
            try
            {
                ddlBranch.Items.Clear();

                DataSet dsgetBrachtype = Control.getBranch();
                ddlBranch.Items.Insert(0, "--SELECT--");
                for (int i = 0; i < dsgetBrachtype.Tables[0].Rows.Count; i++)
                {
                    ddlBranch.Items.Insert(i + 1, new ListItem(dsgetBrachtype.Tables[0].Rows[i][0].ToString(), dsgetBrachtype.Tables[0].Rows[i][1].ToString()));
                }

            }
            catch(Exception ex)
            {
                WebMsgBox.Show(ex.Message);
            }
        }

        protected void getBankType()
        {
            ddlBank.Items.Clear();

            DataSet dsgetBanktype = Control.getBank();
            ddlBank.Items.Insert(0, "--SELECT--");

            for (int i = 0; i < dsgetBanktype.Tables[0].Rows.Count; i++)
            {
                ddlBank.Items.Insert(i + 1, new ListItem(dsgetBanktype.Tables[0].Rows[i][0].ToString(), dsgetBanktype.Tables[0].Rows[i][1].ToString()));
            }

        }


        public void BBDetails()
        {
            try
            {
                string Branch = ddlBranch.SelectedValue.ToString();
                string Bank = ddlBank.SelectedValue.ToString();

                DataTable dt = new DataTable();
                DataRow dr = null;
                dt.Columns.Add(new DataColumn("Branch", typeof(string)));
                dt.Columns.Add(new DataColumn("Bank", typeof(string)));

                dr = dt.NewRow();
                dr[0] = Branch;
                dr[1] = Bank;
                dt.Rows.Add(dr);

                if (dgvBBDetails.Rows.Count == 0)
                {
                    ViewState["CurrentTable"] = dt;
                    dgvBBDetails.DataSource = dt;
                    dgvBBDetails.DataBind();
                }

                else
                {

                    DataTable dtCurrentTable = (DataTable)ViewState["CurrentTable"];
                    bool exists = true;
                    foreach (GridViewRow row in dgvBBDetails.Rows)
                    {
                        string t = row.Cells[0].Text + "-" + row.Cells[1].Text;
                        if (!t.Equals(Branch + "-" + Bank))
                        {
                            exists = false;
                        }
                        else
                        {
                            exists = true;
                            break;
                        }

                    }

                    if (!exists)
                    {
                        DataRow drCurrentRow = dtCurrentTable.NewRow();
                        drCurrentRow[0] = Branch;
                        drCurrentRow[1] = Bank;

                        dtCurrentTable.Rows.Add(drCurrentRow);
                        ViewState["CurrentTable"] = dtCurrentTable;

                        dgvBBDetails.DataSource = dtCurrentTable;
                        dgvBBDetails.DataBind();

                    }
                    else
                    {

                    }
                }
            }
          catch(Exception ex)
            {
                WebMsgBox.Show(ex.Message);
            }
        }


        protected void ddlBank_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlBranch.SelectedIndex == 0)
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(), "Message", " alert ('Select Bank') ;", true);
            }
            else
            {
                BBDetails();
                ddlBank.SelectedIndex = 0;
               
            }

        }

        protected void dgvBBDetails_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            int index = Convert.ToInt32(e.RowIndex);
            DataTable dt = ViewState["CurrentTable"] as DataTable;
            dt.Rows[index].Delete();
            dgvBBDetails.DataSource = ViewState["CurrentTable"] as DataTable;
            dgvBBDetails.DataBind();
        }

        protected void CalendarItinerary_SelectionChanged(object sender, EventArgs e)
        {

        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            try
            {
                string UserID = Session["Log_EmpID"].ToString();
                string date = CalendarItinerary.SelectedDate.Date.ToString("yyyy-MM-dd");
                if (ddlVisittype.SelectedIndex == 0)
                {
                    WebMsgBox.Show("Select Visit Type");
                }
                else
                {

                    string visitype = ddlVisittype.SelectedItem.Text;
                    string IP = lblIP.Text = GetLocalIPAddress();
                    string remark = txtremark.Text;
                    string approvedstatus = "NO";
                    IControl.InsertInineraryValues(date, UserID, visitype, remark, IP,approvedstatus);
                    FillDetailsGrid();

                    if (ddlVisittype.SelectedItem.ToString() == "Bank Visit")
                    {
                        if (ddlBranch.SelectedIndex == 0)
                        {
                            WebMsgBox.Show("Select Branch");
                        }

                        else
                        {
                            for (int i = 0; i < dgvBBDetails.Rows.Count; i++)
                            {
                                string Branch = dgvBBDetails.Rows[i].Cells[0].Text;
                                string Bank = dgvBBDetails.Rows[i].Cells[1].Text;
                                IControl.InsertInineraryBankBranch(date, UserID, Branch, Bank);

                            }

                            int countBBdetails = dgvBBDetails.Rows.Count;

                            for (int i = 0; i < countBBdetails; countBBdetails--)
                            {
                                DataTable dt = ViewState["CurrentTable"] as DataTable;
                                dt.Rows[i].Delete();
                                dgvBBDetails.DataSource = ViewState["CurrentTable"] as DataTable;
                                dgvBBDetails.DataBind();
                            }

                            txtremark.Text = "";
                            ddlVisittype.SelectedIndex = 0;
                            ddlBank.SelectedIndex = 0;
                            ddlBranch.SelectedIndex = 0;
                           // WebMsgBox.Show("Successfully Saved");
                        }

                        
                    }

                    txtremark.Text = "";
                    ddlVisittype.SelectedIndex = 0;
                    WebMsgBox.Show("Successfully Saved");
                    getDatetocalander();
                }

                btnsave.Visible = true;
            }
            catch (Exception)
            {
                WebMsgBox.Show("Select Another Date !! ");
            }

        }


        //-----Getting Local IP Address----------------
        public static string GetLocalIPAddress()
        {
            var host = Dns.GetHostEntry(Dns.GetHostName());
            foreach (var ip in host.AddressList)
            {
                if (ip.AddressFamily == AddressFamily.InterNetwork)
                {
                    return ip.ToString();
                }
            }

            throw new Exception("Local IP Address Not Found!");
        }

        public void getBBDetailGridData(string date)
        {
            string userID = Session["Log_EmpID"].ToString();
            DataSet dsgetBBDetails = IControl.getBankItineraryDetails(date,userID);
            dgvviewbbdetails.DataSource = dsgetBBDetails.Tables[0];
            dgvviewbbdetails.DataBind();
            
        }

        public void FillDetailsGrid()
        {
            string userID = Session["Log_EmpID"].ToString();
            DataSet dsfillDetails = IControl.fillDetailsGrid(userID);
            dgvBItineryDetails.DataSource = dsfillDetails.Tables[0];
            dgvBItineryDetails.DataBind();

        }

        protected void dgvviewbbdetails_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {

        }


        protected void DeleteRow(object sender, ImageClickEventArgs e)
        {
            try
            {
                ImageButton btndetails = (ImageButton)sender;
                GridViewRow gvrow = (GridViewRow)btndetails.NamingContainer;

                string Date = gvrow.Cells[0].Text.ToString();
                string Bank = gvrow.Cells[2].Text.ToString();

                lblDate.Text = Date;
                string userID = Session["Log_EmpID"].ToString();

                string dbDate = IControl.checkBankItinerary(Date, userID);


                if (dbDate == "1")
                {

                    IControl.DeletefromItineraryBB(Bank, userID);
                    IControl.DeletefromBankItinerary(Date, userID);
                    FillDetailsGrid();

                }
                else
                {
                    IControl.DeletefromItineraryBB(Bank, userID);
                }

                getBBDetailGridData(Date);

                if (dgvviewbbdetails.Rows.Count == 0)
                {
                    mp1.Hide();
                    FillDetailsGrid();
                    getBBDetailGridData(Date);
                }

            }
            catch(Exception ex)
            {
                WebMsgBox.Show(ex.Message);
            }

        }

        protected void CalendarItinerary_DayRender(object sender, System.Web.UI.WebControls.DayRenderEventArgs e)
        {
            try
            {

                string userID = Session["Log_EmpID"].ToString();
                DateTime now = DateTime.Now;
                DateTime startDate = new DateTime(now.Year, now.Month, 1);
                DateTime firstOfNextMonth = new DateTime(now.Year, now.Month, 1).AddMonths(1);
                DateTime lastOfThisMonth = firstOfNextMonth.AddDays(-1);

                string lasttdate = Convert.ToDateTime(lastOfThisMonth).ToString("yyyy-MM-dd");
                string nowdate = Convert.ToDateTime(now).ToString("yyyy-MM-dd");
                string startDay = Convert.ToDateTime(startDate).ToString("yyyy-MM-dd");

                if (e.Day.IsOtherMonth)
                {
                    e.Cell.Text = "";
                    e.Cell.BackColor = System.Drawing.Color.White;
                }
          
                if (e.Day.Date.CompareTo(DateTime.Today) < 0)
                {
                    e.Day.IsSelectable = false;
                    e.Cell.ForeColor = System.Drawing.Color.Gray;
                }

                string date = CalendarItinerary.SelectedDate.ToString("yyyy-MM-dd");
                int Icount = IControl.countB_Ass_Itinerary(date,startDay, userID);
                TimeSpan diff = e.Day.Date - DateTime.Today;
                TimeSpan diffoflastdate = e.Day.Date - lastOfThisMonth;
                double diffforlastday = diffoflastdate.TotalDays;
                double days = diff.TotalDays;

                if (Icount<20 && days > diffforlastday)
                {
                    if (days > 30)
                    {
                        e.Day.IsSelectable = false;
                        e.Cell.ForeColor = System.Drawing.Color.Gray;
                    }
                    else
                    {

                    }


                }

                else
                {
                    
                    if (days > 30)
                    {
                        e.Day.IsSelectable = false;
                        e.Cell.ForeColor = System.Drawing.Color.Gray;
                    }
                    else
                    {

                    }

                }

                

                DataSet holidays = Control.getHolidays();
                if (holidays.Tables[0].Rows.Count > 0)
                {
                    for (int i = 0; i < holidays.Tables[0].Rows.Count; i++)
                    {
                        string holiday = Convert.ToDateTime(holidays.Tables[0].Rows[i][0].ToString()).ToString("yyyy-MM-dd");
                        string current = Convert.ToDateTime(e.Day.Date).ToString("yyyy-MM-dd");
                        if (holiday.Equals(current))
                        {
                            e.Cell.ForeColor = System.Drawing.Color.Red;
                            e.Day.IsSelectable = false;
                        }
                        
                        
                    }
                }

               
            }
            catch (Exception ex)
            {
                WebMsgBox.Show(ex.Message);
            }
        }

        protected void VisitTypeChange(object sender, EventArgs e)
        {
            if (ddlVisittype.SelectedItem.ToString() == "Bank Visit")
            {
                lblBank.Visible = true;
                lblBranch.Visible = true;
                ddlBank.Visible = true;
                ddlBranch.Visible = true;
                panelbottom.Visible = true;
            }
            else
            {
                lblBank.Visible = false;
                lblBranch.Visible = false;
                ddlBank.Visible = false;
                ddlBranch.Visible = false;
                panelbottom.Visible = false;
            }
        }

        protected void dgvBItineryDetails_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        protected void dgvBItineryDetails_DataBound(object sender, GridViewRowEventArgs e)
        {


        }

        protected void dgvBItineryDetails_RowDataBound(object sender, GridViewRowEventArgs e)
        {

            string Namecolumnvalue = Convert.ToString(DataBinder.Eval(e.Row.DataItem, "VISIT_TYPE"));          
            string date =Convert.ToString((DataBinder.Eval(e.Row.DataItem, "DATE")));            
            string status = Convert.ToString((DataBinder.Eval(e.Row.DataItem, "IS_APPROVED")));
            ImageButton imgbtn = (ImageButton)e.Row.FindControl("imgbtn");
            DateTime day;
            DateTime cdate;

            if(date=="")
            {

            }

            else
            { 
                day = DateTime.Parse(date);
                cdate = DateTime.Now;
                
                if (day.Date < cdate.Date || status=="YES")
                {
                   imgbtn.Visible = false;
                }
                else
                {

                }

            }


            LinkButton lnk2 = (LinkButton)e.Row.FindControl("HyperLink1");
            

            if (Namecolumnvalue != "" && Namecolumnvalue != "Bank Visit")
            {
                lnk2.Enabled = false;
            }
            else if (Namecolumnvalue == "")
            {

            }

           
               
            

        }

        protected void Popup(object sender, EventArgs e)
        {
            LinkButton btndetails = (LinkButton)sender;
            GridViewRow gvrow = (GridViewRow)btndetails.NamingContainer;

            string Date = gvrow.Cells[0].Text.ToString();

            for (int runs = 0; runs < 1; runs++)
            {                
                getBBDetailGridData(Date);               
            }
            mp1.Show();
        }

        protected void DeleteRowmain(object sender, ImageClickEventArgs e)
        {
            ImageButton btndetails = (ImageButton)sender;
            GridViewRow gvrow = (GridViewRow)btndetails.NamingContainer;
            string userID = Session["Log_EmpID"].ToString();

            string Date = gvrow.Cells[0].Text.ToString();
 
            IControl.DeletefromBankItinerary(Date,userID);
            FillDetailsGrid();
            IControl.DeletefromBBankItinerary(Date,userID);
            getBBDetailGridData(Date);
        }

        public void getDatetocalander()
        {

            string today = Convert.ToDateTime(CalendarItinerary.SelectedDate).ToString("yyyy-MM-dd");            
            DataSet holidays = IControl.findnextholiday(today);
                  
            for (int i = 0; i < holidays.Tables[0].Rows.Count; i++)
            {
                DateTime selecteDate = CalendarItinerary.SelectedDate;
               
                //string nextday = Convert.ToDateTime(nextdate).ToString("yyyy-MM-dd");
                //string holiday = Convert.ToDateTime(holidays.Tables[0].Rows[i][0].ToString()).ToString("yyyy-MM-dd");

                if(i==0)
                {
                    DateTime nextdate = CalendarItinerary.SelectedDate.AddDays(1);
                    string  nextday = Convert.ToDateTime(nextdate).ToString("yyyy-MM-dd");
                    string holiday = Convert.ToDateTime(holidays.Tables[0].Rows[i][1].ToString()).ToString("yyyy-MM-dd");

                    if ((nextday == holiday))
                    {
                        nextdate = nextdate.AddDays(1);
                        CalendarItinerary.SelectedDate = nextdate;
                        CalendarItinerary.VisibleDate = nextdate;

                    }

                    else
                    {
                        CalendarItinerary.SelectedDate = nextdate;
                        CalendarItinerary.VisibleDate = nextdate;
                        break;
                    }

                }
                else
                {
                    DateTime selecteDt = CalendarItinerary.SelectedDate;
                    string day = Convert.ToDateTime(selecteDt).ToString("yyyy-MM-dd");
                    string holiday = Convert.ToDateTime(holidays.Tables[0].Rows[i][1].ToString()).ToString("yyyy-MM-dd");
                    if ((day == holiday))
                    {
                        DateTime nxtDate=selecteDt.AddDays(1);
                        CalendarItinerary.SelectedDate = nxtDate;
                        CalendarItinerary.VisibleDate = nxtDate;

                    }

                    else
                    {
                        CalendarItinerary.SelectedDate = selecteDt;
                        CalendarItinerary.VisibleDate = selecteDt;
                        break;
                    }
                }

                
            }     

        }

        protected void btnsave_Click(object sender, EventArgs e)
        {
            try
            {
                string userID = Session["Log_EmpID"].ToString();
                string name = IControl.getusername(userID);
                string ApproverEmail = IControl.getApproverEmail();
                string fromEmail = "System Bank-Assurance-Itinerary/sys/ceylife@CEYLIFE";
                MailMessage mm = new MailMessage(new MailAddress(fromEmail, "Bank Assurance Itinerary"), new MailAddress(ApproverEmail, " "));
                mm.Subject = "Approval for Itinerary Details - " + name;
                mm.Body = "Dear Mr Ranasighe, <br/><br/> Please approve my Itinerary  using following link. <br/><br/>" + "http://192.168.102.104/BankAssurance/";
                mm.IsBodyHtml = true;
                SmtpClient smtp = new SmtpClient();
                smtp.Host = "192.168.57.10";
                smtp.EnableSsl = false;
                NetworkCredential NetworkCred = new NetworkCredential("System", "123");
                smtp.UseDefaultCredentials = true;
                smtp.Credentials = NetworkCred;
                smtp.Port = 25;
                smtp.Send(mm);
                WebMsgBox.Show("Email sent");
            }
            catch(Exception)
            {
                WebMsgBox.Show("Email Not Sent");
            }
        }
    }
}