﻿using System;
using System.Data;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Bank_Assurance.Controller;
using Bank_Assurance.Other;

namespace Bank_Assurance
{
    public partial class Login : System.Web.UI.Page
    {
        LoginController control = new LoginController();
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void LoginButton_Click(object sender, EventArgs e)
        {
            try
            {
                if (this.IsPostBack)
                {
                    string uid = txtUserName.Text;
                    string PwdEncript = PwdGen.Encrypt(txtPassword.Text.ToString().Trim());
                    validateUser(uid, PwdEncript);
                }
            }
            catch (Exception e1)
            {
                WebMsgBox.Show("Error occurred in authentication process.Please contact the system administrator for details!");
            }

        }

        public void validateUser(string username, string password)
        {
            try
            {
                DataSet users = control.getUsers(username, password);
                if (users.Tables[0].Rows.Count != 0)
                {
                    string empID = users.Tables[0].Rows[0]["EMPID"].ToString();
                    string uBranch = users.Tables[0].Rows[0]["BRANCH"].ToString();
                    string uType = users.Tables[0].Rows[0]["USERTYPE"].ToString();

                    DataSet superUsers = control.getSuperUsers(empID);
                    if (superUsers.Tables[0].Rows.Count != 0)
                    {
                        string dcrUserType = users.Tables[0].Rows[0]["EMPID"].ToString();
                        Session["Log_EmpID"] = users.Tables[0].Rows[0]["EMPID"].ToString();
                        Session["Log_PID"] = users.Tables[0].Rows[0]["PID"].ToString();
                        Session["Log_EmpName"] = users.Tables[0].Rows[0]["NAME"].ToString();
                        Session["Log_EmpBranch"] = uBranch;

                        if (superUsers.Tables[0].Rows[0]["TYPE"].ToString()== "APPROVER")
                        {
                            Response.Redirect("~/ApproveForm.aspx");
                        }
                        else
                        {
                            Response.Redirect("~/Itinerary.aspx");
                        }
                        
                    }
                    else
                    {
                        txtError.Text = "You don't have permisssion";
                    }
                }
                else
                {
                    txtError.Text = "Incorrect Username or Password!";
                }
            }
            catch (Exception ex)
            {
                WebMsgBox.Show(ex.Message);
            }
        }
    }
}