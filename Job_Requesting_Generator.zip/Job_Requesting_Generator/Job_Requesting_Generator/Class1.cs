﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Job_Requesting_Generator
{
    public class Class1
    {
    }
}
