﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using System.Text.RegularExpressions;
using System.Configuration;
using Microsoft.ApplicationBlocks.Data;

namespace DataObjects.SqlServers
{
    public class Sql_Servers
    {
        string strConnString = ConfigurationManager.ConnectionStrings["LocalConnStr"].ConnectionString;
        string ConnString = ConfigurationManager.ConnectionStrings["dwhConnStr"].ConnectionString;

        DB _db = new DB();

        public DataSet get_UserDetails(string Userid, string Pwd)
        {
            System.Data.SqlClient.SqlParameter[] param = new System.Data.SqlClient.SqlParameter[2];

            string storedProcedure = @"SELECT [NAME],[STATUS],BRANCH,USERTYPE 
                                        FROM [192.168.100.42].dwh.dbo.password_new_system 
                                        where empid=@empid and PasswordED=@password";

            param[0] = new System.Data.SqlClient.SqlParameter("@empid", SqlDbType.VarChar);
            param[0].Value = Userid;
            param[1] = new System.Data.SqlClient.SqlParameter("@password", SqlDbType.VarChar);
            param[1].Value = Pwd;

            return _db.GetDatasSet_Advance(storedProcedure, param, "Local");
        }

        //--------- Geting inquiary details---------------------
        public DataSet get_inquiaryDetails(string value)
        {
            System.Data.SqlClient.SqlParameter[] param = new System.Data.SqlClient.SqlParameter[1];

            string storedProcedure = @"select distinct a.Job_No,b.Branch_Code,a.Submit_Date as Request_date, a.Create_user as Requested_By,
                                        b.Job_Type,b.Call_Type,b.allocate_user,a.Status 
                                        from [JOB_REQUEST_MASTER] a, [JOB_REQUEST_TRANSACTION] b
                                        where
                                        a.Job_No=b.JOB_NO and b.Branch_Code like '%" + value+"%'order by a.Submit_Date desc";

            return _db.GetDatasSet_Advance(storedProcedure, param, "Local");

        }

        //--------------Get Job details----------------------------

        public DataSet get_JobDetails(String branch)
        {
            System.Data.SqlClient.SqlParameter[] param = new System.Data.SqlClient.SqlParameter[1];

            string storedProcedure = @"select ROW_NUMBER() OVER(ORDER BY create_date ASC) as Rec_No, Branch_code,SO_CODE as Current_SO,Recovery_SO_CODE as Recovery_SO,policy_no,Customer_Name,Client_Phone,Cust_FeedBack
                                       from [JOB_REQUEST_TRANSACTION] where JOB_NO='" + branch+"'";
            return _db.GetDatasSet_Advance(storedProcedure, param, "Local");
        }
        //-----------------------------------------------------------------

        //--------------Get View letter details------------------------

        public DataSet get_viewLetter(String branch)
        {
            System.Data.SqlClient.SqlParameter[] param = new System.Data.SqlClient.SqlParameter[1];
            string storedProcedure = @"select ROW_NUMBER() OVER(ORDER BY create_date ASC) as Rec_No,Branch_code,SO_CODE as Current_SO,
                                        Recovery_SO_CODE as Recovery_SO,policy_no,Customer_Name,Client_Phone,Cust_FeedBack
                                        from [JOB_REQUEST_TRANSACTION] where
                                        Cust_FeedBack in ('Cannot contact the Customer','Invalid Contact Number','Wrong Number') 
                                        and JOB_NO='" + branch + "'";
            return _db.GetDatasSet_Advance(storedProcedure, param, "Local");
        }

        //-------------------------------------------------------------------
        public DataSet get_reqtype()
        {
            System.Data.SqlClient.SqlParameter[] param = new System.Data.SqlClient.SqlParameter[0];

            string storedProcedure = @"SELECT [DESCRIPTION] FROM JOB_SYSCODE
                                       WHERE [TYPE]='JOB_TYPE'
                                       ORDER BY CODE";

            return _db.GetDatasSet_Advance(storedProcedure, param, "Local");
        }

        public DataSet get_agent_no(string UserBranch)
        {
            System.Data.SqlClient.SqlParameter[] param = new System.Data.SqlClient.SqlParameter[1];

//            string storedProcedure = @"SELECT PID + ' - ' + Name as AgentNo,PID from [192.168.100.42].dwh.dbo.password_new_system 
//                                       where usertype not in ('user') and status='active' and branch=@branch";

            string storedProcedure = @"select AGNTNUM+ ' - ' +CLTADDR01 as AgentNo,AGNTNUM from agntdtl where dtetrm='99999999' 
                                        and agntnum not between '00050000' and '00199999' and
                                        agntnum <'00300000' and
                                        agtype not in ('PA','LG','BK') and
                                        ARACDE=@branch";

            param[0] = new System.Data.SqlClient.SqlParameter("@branch", SqlDbType.VarChar);
            param[0].Value = UserBranch;

            return _db.GetDatasSet_Advance(storedProcedure, param, "dwh");
        }

        public DataSet getall_policy_types()
        {
            System.Data.SqlClient.SqlParameter[] param = new System.Data.SqlClient.SqlParameter[0];

            string storedProcedure = @"select distinct PLAN_TYPE from PLANS";

            return _db.GetDatasSet_Advance(storedProcedure, param, "dwh");
        }

        public DataSet get_policies(int agentno, string riskdatefrom, string riskdateto, 
                                    string duedatefrom, string duedateto, string policytype, 
                                    string mcfpfrom, string mcfpto)
        {
            System.Data.SqlClient.SqlParameter[] param = new System.Data.SqlClient.SqlParameter[0];

//            string storedProcedure = @"select distinct ROW_NUMBER() over (order by COWNNUM)Sequence_no,* from(SELECT dbo.pda1.COWNNUM, 
//                                        dbo.pda1.CLTADDR01, 
//                                        dbo.pda1.AGNTNUM,
//                                        dbo.pda1.STATCODE,
//                                        dbo.pda1.PSTATCODE ,
//                                        dbo.policyholder.policy_no, 
//                                        convert(varchar(10),dbo.policyholder.date_of_risk,111)date_of_risk, 
//                                        dbo.policyholder.premium, 
//                                        dbo.policyholder.mcfp,   
//                                        dbo.policyholder.policy_type,
//                                        dbo.policyholder.mode, 
//                                        dbo.pda1.PTDATE,
//                                        dbo.policyholder.so_code,
//                                        dbo.pda1.REGISTER,
//                                        dbo.CLNTDTL.lang,
//                                        case
//                                        when (LTRIM(RTRIM(dbo.CLNTDTL.CLTPHONE02)) <> '' and LTRIM(rtrim(dbo.CLNTDTL.CLTPHONE01)) <> '') then (LTRIM(RTRIM(dbo.CLNTDTL.CLTPHONE01))+','+LTRIM(RTRIM(dbo.CLNTDTL.CLTPHONE02)))
//                                        when LTRIM(rtrim(dbo.CLNTDTL.CLTPHONE01)) <> '' then LTRIM(rtrim(dbo.CLNTDTL.CLTPHONE01))
//                                        when LTRIM(RTRIM(dbo.CLNTDTL.CLTPHONE02)) <> '' then LTRIM(RTRIM(dbo.CLNTDTL.CLTPHONE02))
//                                        end as
//                                        PhoneNumber
//                                        FROM dbo.pda1 INNER JOIN
//                                        dbo.policyholder ON dbo.pda1.CHDRNUM = dbo.policyholder.policy_no
//                                        INNER JOIN
//                                        dbo.CLNTDTL ON dbo.pda1.COWNNUM = dbo.CLNTDTL.CLNTNUM)as a 
//
//                                        
//                                        where convert(int,AGNTNUM)=" + "'" + agentno + "'" + @" 
//                                        and date_of_risk between " + riskdatefrom + @" and " + riskdateto + @" 
//                                        and PTDATE between " + duedatefrom + @" and " + duedateto + @"
//                                        and policy_type=" + policytype + @"                                           
//                                        and mcfp between " + mcfpfrom + @" and " + mcfpto + " and a.PhoneNumber is not null order by COWNNUM";

            string storedProcedure = @"select distinct ROW_NUMBER() over (order by COWNNUM)Sequence_no,* from(SELECT dbo.pda1.COWNNUM, 
                                        dbo.pda1.CLTADDR01, 
                                        dbo.pda1.AGNTNUM,
                                        dbo.pda1.STATCODE,
                                        dbo.pda1.PSTATCODE ,
                                        dbo.pda1.chdrnum as policy_no, 
                                        convert(varchar(10),cast(substring(cast (CCDATE as varchar),1,4)+ '-' + substring(cast(CCDATE as varchar),5,2)+ '-'+ substring(cast(CCDATE as varchar),7,2) as datetime ),111) date_of_risk, 
                                        dbo.pda1.SINSTAMT06 as premium, 
                                        cast((dbo.pda1.sinstamt06* cast(dbo.pda1.billfreq as int))/12 as numeric(18,2))as mcfp, dbo.plan_types.plan_type,  
                                        mode = case when dbo.pda1.billfreq='12' then 'M'
                                                   when dbo.pda1.billfreq='04' then 'Q'
                                                   when dbo.pda1.billfreq='02' then 'H'
                                                   when dbo.pda1.billfreq='01' then 'Y'
                                                   when dbo.pda1.billfreq='00' then 'S'
                                              end,  
                                        CONVERT(varchar(10),CONVERT(datetime, CONVERT(varchar(8), dbo.pda1.PTDATE), 112),111)PTDATE,
                                        dbo.pda1.REGISTER,
                                        dbo.CLNTDTL.lang,
                                        case
                                        when (LTRIM(RTRIM(dbo.CLNTDTL.CLTPHONE02)) <> '' and LTRIM(rtrim(dbo.CLNTDTL.CLTPHONE01)) <> '') then (LTRIM(RTRIM(dbo.CLNTDTL.CLTPHONE01))+','+LTRIM(RTRIM(dbo.CLNTDTL.CLTPHONE02)))
                                        when LTRIM(rtrim(dbo.CLNTDTL.CLTPHONE01)) <> '' then LTRIM(rtrim(dbo.CLNTDTL.CLTPHONE01))
                                        when LTRIM(RTRIM(dbo.CLNTDTL.CLTPHONE02)) <> '' then LTRIM(RTRIM(dbo.CLNTDTL.CLTPHONE02))
                                        end as
                                        PhoneNumber
                                        FROM dbo.pda1,dbo.plan_types,dbo.CLNTDTL,dbo.agntdtl
                                        where
                                        dbo.pda1.CNTTYPE = dbo.plan_types.Plan_code and
                                        dbo.pda1.AGNTNUM = dbo.agntdtl.AGNTNUM and
                                        dbo.pda1.COWNNUM = dbo.CLNTDTL.CLNTNUM and
                                        dbo.pda1.STATCODE in ('IF','LA')
                                        and len(pda1.CCDATE)=8 and pda1.CCDATE<>'99999999' and pda1.CCDATE is not null
										and len(pda1.PTDATE)=8 and pda1.PTDATE<>'99999999' and pda1.PTDATE is not null and
                                        len(dbo.pda1.CCDATE)=8 and dbo.agntdtl.dtetrm='99999999' and dbo.agntdtl.agntnum not between '00050000' and '00199999' and dbo.agntdtl.agntnum <'00300000' 
                                        and dbo.agntdtl.agtype not in ('PA','LG','BK') )
                                        as AB 


                                        where convert(int,AGNTNUM)=" + "'" + agentno + "'" + @" 
                                        and date_of_risk between " + riskdatefrom + @" and " + riskdateto + @" 
                                        and PTDATE between " + duedatefrom + @" and " + duedateto + @"
                                        and plan_type=" + policytype + @"                                           
                                        and mcfp between " + mcfpfrom + @" and " + mcfpto + " and AB.PhoneNumber is not null order by COWNNUM";

            return _db.GetDatasSet_Advance(storedProcedure, param, "dwh");
        }

        public DataSet getUploadedPolicyDetails(string emp_Id)
        {
//            string strQuery = @"select distinct ROW_NUMBER() over (order by COWNNUM)Sequence_no,* from(SELECT a.COWNNUM , 
//                                a.CLTADDR01, 
//                                a.AGNTNUM,
//                                a.STATCODE,
//                                a.PSTATCODE ,
//                                b.policy_no, 
//                                convert(varchar(10),b.date_of_risk,111)date_of_risk, 
//                                b.premium, 
//                                b.mcfp,   
//                                b.policy_type,
//                                b.mode, 
//                                a.PTDATE,
//                                b.so_code,
//                                a.REGISTER,
//                                c.lang,
//                                case
//                                when (LTRIM(RTRIM(c.CLTPHONE02)) <> '' and LTRIM(rtrim(c.CLTPHONE01)) <> '') then (LTRIM(RTRIM(c.CLTPHONE01))+','+LTRIM(RTRIM(c.CLTPHONE02)))
//                                when LTRIM(rtrim(c.CLTPHONE01)) <> '' then LTRIM(rtrim(c.CLTPHONE01))
//                                when LTRIM(RTRIM(c.CLTPHONE02)) <> '' then LTRIM(RTRIM(c.CLTPHONE02))
//                                end as
//                                PhoneNumber
//                                FROM [192.168.100.42].dwh.dbo.pda1 a INNER JOIN
//                                [192.168.100.42].dwh.dbo.policyholder b  ON a.CHDRNUM = b.policy_no
//                                inner join 
//                                dbo.JOB_REQUEST_POLICY_LOG on b.policy_no = dbo.JOB_REQUEST_POLICY_LOG.POLICY_NO and dbo.JOB_REQUEST_POLICY_LOG.EMP_ID = '" +emp_Id+"' INNER JOIN [192.168.100.42].dwh.dbo.CLNTDTL  c ON a.COWNNUM = c.CLNTNUM)as AB where AB.PhoneNumber is not null order by COWNNUM";


//            string strQuery = @"select distinct ROW_NUMBER() over (order by COWNNUM)Sequence_no,* from(SELECT a.COWNNUM , 
//                                a.CLTADDR01, 
//                                a.AGNTNUM,
//                                a.STATCODE,
//                                a.PSTATCODE ,
//                                b.policy_no, 
//                                convert(varchar(10),b.date_of_risk,111)date_of_risk, 
//                                b.premium, 
//                                b.mcfp,   
//                                b.policy_type,
//                                b.mode, 
//                                a.PTDATE,
//                                b.so_code,
//                                a.REGISTER,
//                                c.lang,
//                                case
//                                when (LTRIM(RTRIM(c.CLTPHONE02)) <> '' and LTRIM(rtrim(c.CLTPHONE01)) <> '') then (LTRIM(RTRIM(c.CLTPHONE01))+','+LTRIM(RTRIM(c.CLTPHONE02)))
//                                when LTRIM(rtrim(c.CLTPHONE01)) <> '' then LTRIM(rtrim(c.CLTPHONE01))
//                                when LTRIM(RTRIM(c.CLTPHONE02)) <> '' then LTRIM(RTRIM(c.CLTPHONE02))
//                                end as
//                                PhoneNumber
//                                FROM [192.168.100.42].dwh.dbo.pda1 a INNER JOIN [192.168.100.42].dwh.dbo.policyholder b ON a.CHDRNUM = b.policy_no
//                                INNER JOIN [192.168.100.42].dwh.dbo.agntdtl d ON a.AGNTNUM = d.AGNTNUM
//                                inner join dbo.JOB_REQUEST_POLICY_LOG on b.policy_no = dbo.JOB_REQUEST_POLICY_LOG.POLICY_NO and
//                                dbo.JOB_REQUEST_POLICY_LOG.EMP_ID = '" +emp_Id+"' INNER JOIN [192.168.100.42].dwh.dbo.CLNTDTL c ON a.COWNNUM = c.CLNTNUM where d.dtetrm='99999999' and d.agntnum not between '00050000' and '00199999' and d.agntnum <'00300000' and d.agtype not in ('PA','LG','BK') )as AB where AB.PhoneNumber is not null order by COWNNUM";

            string strQuery = @"select distinct ROW_NUMBER() over (order by COWNNUM)Sequence_no,* from(SELECT a.COWNNUM , 
                                a.CLTADDR01,a.AGNTNUM,a.STATCODE,a.PSTATCODE ,a.chdrnum as policy_no, 
                                convert(varchar(10),cast(substring(cast (CCDATE as varchar),1,4)+ '-' + substring(cast(CCDATE as varchar),5,2)+ '-'+ substring(cast(CCDATE as varchar),7,2) as datetime ),111) date_of_risk, 
                                a.SINSTAMT06 as premium,cast((a.sinstamt06* cast(a.billfreq as int))/12 as numeric(18,2))as mcfp ,b.plan_type,
                                mode = case when a.billfreq='12' then 'M'
                                               when a.billfreq='04' then 'Q'
                                               when a.billfreq='02' then 'H'
                                               when a.billfreq='01' then 'Y'
                                               when a.billfreq='00' then 'S'
                                          end,               
                                CONVERT(varchar(10),CONVERT(datetime, CONVERT(varchar(8), a.PTDATE), 112),111)PTDATE,a.REGISTER,c.lang,
                                case
                                when (LTRIM(RTRIM(c.CLTPHONE02)) <> '' and LTRIM(rtrim(c.CLTPHONE01)) <> '') then (LTRIM(RTRIM(c.CLTPHONE01))+','+LTRIM(RTRIM(c.CLTPHONE02)))
                                when LTRIM(rtrim(c.CLTPHONE01)) <> '' then LTRIM(rtrim(c.CLTPHONE01))
                                when LTRIM(RTRIM(c.CLTPHONE02)) <> '' then LTRIM(RTRIM(c.CLTPHONE02))
                                end as
                                PhoneNumber
                                FROM pda1 a , plan_types b, CLNTDTL c, agntdtl d,
                                JOB_REQUEST_POLICY_LOG e
                                where
                                a.CNTTYPE = b.Plan_code and
                                a.AGNTNUM = d.AGNTNUM and
                                a.COWNNUM = c.CLNTNUM and
                                a.chdrnum = e.POLICY_NO and
                                e.EMP_ID = '" + emp_Id + "' and len(a.CCDATE)=8 and d.dtetrm='99999999' and d.agntnum not between '00050000' and '00199999' and d.agntnum <'00300000' and d.agtype not in ('PA','LG','BK') )as AB where AB.PhoneNumber is not null order by COWNNUM";

            return SqlHelper.ExecuteDataset(ConnString, CommandType.Text, strQuery);
        }

        public int Save_Job_Requesting_data(string User, string submit_date, string estimated_date, string status, string Total_cost, DataTable newdatatable, string call_type, string job_type)
        {
            try
            {
                System.Data.SqlClient.SqlParameter[] param = new System.Data.SqlClient.SqlParameter[5];

                string sp_master = @"INSERT INTO JOB_REQUEST_MASTER
                                     (Create_user
                                     ,Submit_Date
                                     ,Estimate_Start_Time
                                     ,Status
                                     ,Estimated_cost)
                                  VALUES
                                     (@Create_user
                                     ,getdate()
                                     ,@Estimate_Start_Time
                                     ,@Status
                                     ,@Estimated_cost)

                              SELECT @@IDENTITY";

                param[0] = new System.Data.SqlClient.SqlParameter("@Create_user", SqlDbType.VarChar);
                param[0].Value = User;
                param[1] = new System.Data.SqlClient.SqlParameter("@Submit_Date", SqlDbType.VarChar);
                param[1].Value = submit_date;
                param[2] = new System.Data.SqlClient.SqlParameter("@Estimate_Start_Time", SqlDbType.VarChar);
                param[2].Value = estimated_date;
                param[3] = new System.Data.SqlClient.SqlParameter("@Status", SqlDbType.VarChar);
                param[3].Value = status;
                param[4] = new System.Data.SqlClient.SqlParameter("@Estimated_cost", SqlDbType.VarChar);
                param[4].Value = Total_cost;

                //return _db.Insert_Master(sp_master, param);
                //return _db.Save_Job_Requesting_data(sp_master, param, User, submit_date, estimated_date, status, Total_cost, newdatatable);
                return _db.Insert_Master(sp_master, param, User, submit_date, estimated_date, status, Total_cost, newdatatable, call_type, job_type);
            }
            catch (Exception)
            {               
                throw;
            }           
        }

        //----------------------insert Letter to master-----------------------------------
        public int insertToLetterToMaster( string user, string SubmitDate, string EstimateDate, double estimateCost, string status, string AllocateDate, string CompleteDate, double TotalCost)
        {
            string strQuery = @"INSERT INTO [JOB_REQUEST_MASTER]
                               ([CREATE_USER]
                               ,[SUBMIT_DATE]
                               ,[ESTIMATE_START_TIME]
                               ,[ESTIMATED_COST]
                               ,[STATUS]
                               ,[ALLOCATED_DATE]
                               ,[COMPLETE_DATE]
                               ,[TOTAL_COST])
                                VALUES
                               ('"+ user + "','" + SubmitDate + "','" + EstimateDate + "',"+estimateCost+",'"+ status + "','" + AllocateDate + "','"+ CompleteDate + "',"+TotalCost+")SELECT SCOPE_IDENTITY()";



          

            return SqlHelper.ExecuteNonQuery(strConnString, CommandType.Text, strQuery);
        }
        //------------------------------------------------------------------------------------

        //-------Insert Letter to Transaction----------------------------------------------
        //public int insertLetterToTransaction(int JobNo, int serialNo, string BranchCode, string SoCode,
        //                                       string ClientNo, string PolicyNo, string customerName, string clientphone,
        //                                       string duedate,string mode,
        //                                       string status,string Cstatus, string policyType,string calltype,string jobtype,string user,string RSoCode,
        //                                       double amount,string creatDate)
        //{
        //    string strQuery = @"INSERT INTO [JOB_REQUEST_TRANSACTION]
        //                       ([JOB_NO],[SERIAL_NO],[BRANCH_CODE],[SO_CODE],[CLIENT_NO],[POLICY_NO],[CUSTOMER_NAME],[CLIENT_PHONE],[DUE_DATE],[MODE],[STATUS],[POLICY_TYPE],[CALL_TYPE],[JOB_TYPE],[Recovery_SO_CODE],[RECOVER_AMOUNT],[RECOVERY_STATUS],[CREATE_DATE])
        //                        VALUES
        //                       (" + JobNo+ "," + serialNo + ",'" + BranchCode + "','" + SoCode + "','" + ClientNo + "','" + PolicyNo + "','" + customerName + "','" + clientphone + "','" + duedate + "','" + mode + "','" + Cstatus+"','"+policyType+ "','" + calltype + "','" + jobtype + "'," + RSoCode + ",'" + amount + "','"+status+ "','" + creatDate + "')";

        //    return SqlHelper.ExecuteNonQuery(strConnString, CommandType.Text, strQuery);
        //}

        //---------SP Call for Insert Letter to Transaction-----------------------------------------
        public int sp_insertLetterToTransaction(int jobNo, decimal recoverAmount, string LetterType)
        {
            SqlParameter[] param = null;
            param = new SqlParameter[3];

            param[0] = new SqlParameter("@Job_No", SqlDbType.Int);
            param[0].Value = jobNo;

            param[1] = new SqlParameter("@Recovery_amt", SqlDbType.Decimal);
            param[1].Value = recoverAmount;

            param[2] = new SqlParameter("@Letter_type", SqlDbType.VarChar);
            param[2].Value = LetterType.Trim();

            return SqlHelper.ExecuteNonQuery(strConnString, CommandType.StoredProcedure, "sp_Ins_JOB_REQUEST_TRANSACTION_Auto", param);
        }


        //****-------------SP Call for Insert Letter to customer list---------------****

        public int sp_insertLetterTocustomerlist (int jobno)
        {
            SqlParameter[] param = null;
            param = new SqlParameter[1];

            param[0] = new SqlParameter("@Job_No", SqlDbType.Int);
            param[0].Value = jobno;

            return SqlHelper.ExecuteNonQuery(strConnString, CommandType.StoredProcedure, "sp_Ins_LG_CUSTOMERLIST_Auto", param);

        }

        //--------- Receive job Number---------------------------------------------------------

        public DataSet get_jobNo()
        {
            string strQuery = @"Select MAX(Job_No) From [JOB_REQUEST_MASTER]";
            return SqlHelper.ExecuteDataset(strConnString, CommandType.Text, strQuery);
        }  

        //-----------------------------------------------------------------------------------
        public int saveJobRequestPolicyLog(string emp_Id,string policy_no)
        {
            try
            {
                string strQuery = @"INSERT INTO [JOB_REQUEST_POLICY_LOG] (EMP_ID,POLICY_NO)
                                VALUES ('" + emp_Id + "',replace(ltrim(rtrim('" + policy_no + "')),' ',''))";

                return SqlHelper.ExecuteNonQuery(ConnString, CommandType.Text, strQuery);
            }
            catch(Exception)
            {
                throw;
            }
        }

        public int removeJobRequestPolicyLog(string emp_Id)
        {
            //string strQuery = @"delete FROM [priya_LetterGenerator_Live].[dbo].[JOB_REQUEST_POLICY_LOG] where EMP_ID ='" + emp_Id + "'";
     
         //string strQuery = @"DELETE FROM [JOB_REQUEST_POLICY_LOG] WHERE EMP_ID ='" + emp_Id + "'";     
         //return SqlHelper.ExecuteNonQuery(ConnString, CommandType.Text, strQuery);
            return 1;
        }

        public int removePhoneIsNullPolicyLog(string emp_Id)
        {
            string strQuery = @"delete from JOB_REQUEST_POLICY_LOG
                                where POLICY_NO in (SELECT 
                                b.policy_no
                                FROM pda1 a INNER JOIN
                                policyholder b  ON a.CHDRNUM = b.policy_no
                                inner join 
                                JOB_REQUEST_POLICY_LOG on b.policy_no = JOB_REQUEST_POLICY_LOG.POLICY_NO and JOB_REQUEST_POLICY_LOG.EMP_ID = '" + emp_Id + "' INNER JOIN CLNTDTL c ON a.COWNNUM = c.CLNTNUM where LTRIM(RTRIM(c.CLTPHONE01)) = '' and  LTRIM(RTRIM(c.CLTPHONE02)) = '')";

            return SqlHelper.ExecuteNonQuery(ConnString, CommandType.Text, strQuery);
        }

        public DataSet getPolicyLog(string emp_Id)
        {
            string strQuery = @"select * from JOB_REQUEST_POLICY_LOG where EMP_ID = '" + emp_Id + "'";

            return SqlHelper.ExecuteDataset(ConnString, CommandType.Text, strQuery);
        }

        public DataSet getCall_time(string job_no, string serial_no,string policy_no)
        {
            string strQuery = @"select Call_Time from [JOB_REQUEST_TRANSACTION] where JOB_NO = '"+job_no+"' and SERIAL_NO = '"+serial_no+"' and Policy_No = '" + policy_no + "'";

           return SqlHelper.ExecuteDataset(strConnString, CommandType.Text, strQuery);
        }

        public DataSet getRecruitment_Call_time(string job_no, string serial_no)
        {
            string strQuery = @"select Call_Time from [JOB_REQUEST_TRANSACTION] where JOB_NO = '" + job_no + "' and SERIAL_NO = '" + serial_no + "'";

            return SqlHelper.ExecuteDataset(strConnString, CommandType.Text, strQuery);
        }

        //------------------Get Call Type-------------------------
        public DataSet get_all_calling_types()
        {
            System.Data.SqlClient.SqlParameter[] param = new System.Data.SqlClient.SqlParameter[0];

            string storedProcedure = @"SELECT [DESCRIPTION] FROM JOB_SYSCODE
                                       WHERE [TYPE]='CALL_TYPE'
                                       ORDER BY CODE";

            return _db.GetDatasSet_Advance(storedProcedure, param, "Local");
        }

        //----------------Get Letter Type------------------------

        public DataSet get_allLetterType()
        {
            System.Data.SqlClient.SqlParameter[] param = new System.Data.SqlClient.SqlParameter[0];
            string storedProcedure = @"SELECT [DESCRIPTION] ,[COST_PER_JOB] FROM JOB_SYSCODE
                                        WHERE [TYPE]='LETTER_TYPE'
                                        ORDER BY CODE;";
            return _db.GetDatasSet_Advance(storedProcedure, param, "Local");

        }

        //--------------------------------------------------------
        public DataSet get_serial_no(string callingtype)
        {
            System.Data.SqlClient.SqlParameter[] param = new System.Data.SqlClient.SqlParameter[1];

            string storedProcedure = @"SELECT [CODE],[DESCRIPTION] from [JOB_SYSCODE]
                                       WHERE [TYPE]='CALL_TYPE' and [DESCRIPTION]=@DESCRIPTION";

            param[0] = new System.Data.SqlClient.SqlParameter("@DESCRIPTION", SqlDbType.VarChar);
            param[0].Value = callingtype;

            return _db.GetDatasSet_Advance(storedProcedure, param, "Local");
        }

        public DataSet get_call_cost(string calling_type)
        {
            string strQuery = @" select COST_PER_JOB from [JOB_SYSCODE] where TYPE = 'CALL_TYPE' and DESCRIPTION = '" + calling_type + "'";

            return SqlHelper.ExecuteDataset(strConnString, CommandType.Text, strQuery);
        }

        public DataSet get_recovery_amount(string description)
        {
            System.Data.SqlClient.SqlParameter[] param = new System.Data.SqlClient.SqlParameter[1];

            string storedProcedure = @"SELECT [COST_PER_JOB] from [JOB_SYSCODE]
                                       WHERE [TYPE]='CALL_TYPE' and [DESCRIPTION]=@DESCRIPTION";

            param[0] = new System.Data.SqlClient.SqlParameter("@DESCRIPTION", SqlDbType.VarChar);
            param[0].Value = description;

            return _db.GetDatasSet_Advance(storedProcedure, param, "Local");
        }

        public DataSet get_call_agents()
        {
            string strQuery = @"select [DESCRIPTION] from [JOB_SYSCODE] where type = 'CALL_AGENT'";

            return SqlHelper.ExecuteDataset(strConnString, CommandType.Text, strQuery);
        }

        public DataSet get_call_agent_id(string call_agent_name)
        {
            string strQuery = @"select distinct [CODE] from [JOB_SYSCODE] where type = 'CALL_AGENT' and DESCRIPTION = '" + call_agent_name + "'";

            return SqlHelper.ExecuteDataset(strConnString, CommandType.Text, strQuery);
        }

        public DataSet load_gridView_Admin_View()
        {
            string strQuery = @"select b.JOB_NO,b.Branch_Code,b.Job_Type,b.Call_Type,a.Submit_date,count(*) No_Of_Clients
                                from JOB_REQUEST_MASTER a, 
                                [JOB_REQUEST_TRANSACTION] b
                                where 
                                a.job_no=b.job_no and
                                a.status='Pending' and
                                b.Allocate_user is null
                                group by b.JOB_NO,b.Branch_Code,b.Job_Type,b.Call_Type,a.Submit_date
                                order by b.JOB_NO";

            return SqlHelper.ExecuteDataset(strConnString, CommandType.Text, strQuery);
        }

        public int updateJobTransaction(string allocated_user, string job_no, string branch_code, string allocate_date)
        {
            System.Data.SqlClient.SqlParameter[] param = new System.Data.SqlClient.SqlParameter[4];

            String strQuery = @"update [JOB_REQUEST_TRANSACTION] set Allocate_user=@Allocate_user,Allocate_date=@allocate_date where job_no=@job_no and Branch_code=@Branch_code and Allocate_user is null";

            param[0] = new System.Data.SqlClient.SqlParameter("@Allocate_user", SqlDbType.VarChar);
            param[0].Value = allocated_user;
            param[1] = new System.Data.SqlClient.SqlParameter("@job_no", SqlDbType.VarChar);
            param[1].Value = job_no;
            param[2] = new System.Data.SqlClient.SqlParameter("@Branch_code", SqlDbType.VarChar);
            param[2].Value = branch_code;
            param[3] = new System.Data.SqlClient.SqlParameter("@allocate_date", SqlDbType.VarChar);
            param[3].Value = allocate_date;

            return _db.update(strQuery, param);        
        }

        public int updateJobMaster(string job_no)
        {
            System.Data.SqlClient.SqlParameter[] param = new System.Data.SqlClient.SqlParameter[1];

            String strQuery = @"update [JOB_REQUEST_MASTER] set status='Allocated',Allocated_date = getDate() where job_no=@job_no and job_no=(select distinct job_no from [JOB_REQUEST_TRANSACTION] where Allocate_user is not null and job_no=@job_no)";

            param[0] = new System.Data.SqlClient.SqlParameter("@job_no", SqlDbType.VarChar);
            param[0].Value = job_no;

            return _db.update(strQuery, param); 
        }

        public int delete(string job_no,string so_code,string branch_code)
        {
            System.Data.SqlClient.SqlParameter[] param = new System.Data.SqlClient.SqlParameter[3];

            //string Query2 = @"update JOB_REQUEST_MASTER set status='Cancelled' from JOB_REQUEST_MASTER where job_no=@job_no and job_no=(select distinct job_no from [JOB_REQUEST_TRANSACTION] where Allocate_user is not null and job_no=@job_no)";
                                
            string strQuery =  @"delete from [JOB_REQUEST_TRANSACTION] where job_no=@job_no and so_code=@so_code and Branch_code=@branch_code and Allocate_user is null";

            param[0] = new System.Data.SqlClient.SqlParameter("@job_no", SqlDbType.VarChar);
            param[0].Value = job_no;

            param[1] = new System.Data.SqlClient.SqlParameter("@so_code", SqlDbType.VarChar);
            param[1].Value = so_code;

            param[2] = new System.Data.SqlClient.SqlParameter("@branch_code", SqlDbType.VarChar);
            param[2].Value = branch_code;

            return _db.update(strQuery, param);  
        }

        public int RemoveUnwantedPolicyLog(string user_Id, string branch)
        {
            System.Data.SqlClient.SqlParameter[] param = new System.Data.SqlClient.SqlParameter[2];

            string strQuery = @"delete from JOB_REQUEST_POLICY_LOG
                                where [EMP_ID] = @user_Id and POLICY_NO NOT IN 
                                (select chdrnum from pda1 
                                where REGISTER = @branch)";

            param[0] = new System.Data.SqlClient.SqlParameter("@user_Id", SqlDbType.VarChar);
            param[0].Value = user_Id;

            param[1] = new System.Data.SqlClient.SqlParameter("@branch", SqlDbType.VarChar);
            param[1].Value = branch;

            return _db.updatedwh(strQuery, param);
        }

        public int update(string job_no)
        {
            System.Data.SqlClient.SqlParameter[] param = new System.Data.SqlClient.SqlParameter[1];

            string strQuery = @"update [JOB_REQUEST_MASTER] set status='Cancelled' where job_no=@job_no and job_no=(select distinct job_no from [JOB_REQUEST_TRANSACTION] where Allocate_user is null and job_no=@job_no)";

            param[0] = new System.Data.SqlClient.SqlParameter("@job_no", SqlDbType.VarChar);
            param[0].Value = job_no;

            return _db.update(strQuery, param);
        }

        public DataSet load_GridView_CallAgent_View(string agent_no,string branch,string user)
        {
//            string strQuery = @" select [Call_Type],[Client_No],[Policy_No],[Customer_Name],[Client_Phone] 
//                                from [priya_LetterGenerator_Live].[dbo].[JOB_REQUEST_TRANSACTION] where [Allocate_user] = '" + user + "' and Complete_Date is null";

//            string strQuery = @"select distinct ROW_NUMBER() over (order by JOB_NO,Call_Time)Sequence_no,a.Branch_Code,a.SO_CODE,a.[Call_Type],a.[Client_No],a.[Policy_No],a.[Customer_Name],a.[Client_Phone],b.lang,a.Call_Time,a.Cust_FeedBack,a.JOB_NO,a.SERIAL_NO
//                                from [priya_LetterGenerator_Live].[dbo].[JOB_REQUEST_TRANSACTION] a inner join [192.168.100.42].dwh.dbo.CLNTDTL b
//                                on a.[Client_No] = b.clntnum
//                                where [Allocate_user] = '" + user + "' and SO_CODE = '" + agent_no + "' and Branch_Code = '" + branch + "' and Call_Time < 3 and Status = 'Pending' and (Recovery_Status is null or Recovery_Status = 'NO') order by JOB_NO,Call_Time";

            string strQuery = @"select distinct ROW_NUMBER() over (order by a.JOB_NO,Call_Time)Sequence_no,a.Branch_Code,a.SO_CODE,a.[Call_Type],a.[Client_No],a.[Policy_No],a.[Customer_Name],a.[Client_Phone],b.lang,a.Call_Time,a.Cust_FeedBack,a.JOB_NO,a.SERIAL_NO
                                from [JOB_REQUEST_TRANSACTION] a inner join [192.168.100.42].dwh.dbo.CLNTDTL b
                                on a.[Client_No] = b.clntnum
                                inner join [JOB_REQUEST_MASTER] c
                                on c.Job_No = a.JOB_NO
                                where [Allocate_user] = '" + user + "' and SO_CODE = '" + agent_no + "' and Branch_Code = '" + branch + "' and a.Status = 'Pending' and (Recovery_Status is null) and c.Status = 'Allocated' order by JOB_NO,Call_Time";

            return SqlHelper.ExecuteDataset(strConnString, CommandType.Text, strQuery);
        }

        public DataSet load_GridView_CallAgent_ViewAll(string branch, string user)
        {
//            string strQuery = @"select distinct ROW_NUMBER() over (order by a.JOB_NO,Call_Time)Sequence_no,a.Branch_Code,a.SO_CODE,a.[Call_Type],a.[Client_No],a.[Policy_No],a.[Customer_Name],a.[Client_Phone],b.lang,a.Call_Time,a.Cust_FeedBack,a.JOB_NO,a.SERIAL_NO
//                                from [priya_LetterGenerator_Live].[dbo].[JOB_REQUEST_TRANSACTION] a inner join [192.168.100.42].dwh.dbo.CLNTDTL b
//                                on a.[Client_No] = b.clntnum
//                                inner join [priya_LetterGenerator_Live].[dbo].[JOB_REQUEST_MASTER] c
//                                on c.Job_No = a.JOB_NO
//                                where [Allocate_user] = '" + user + "' and Branch_Code = '" + branch + "' and a.Status = 'Pending' and Recovery_Status is null and c.Status = 'Allocated' order by JOB_NO,Call_Time";

            string strQuery = @"select distinct ROW_NUMBER() over (order by a.JOB_NO,Call_Time)Sequence_no,a.Branch_Code,a.SO_CODE,a.[Call_Type],a.[Client_No],a.[Policy_No],a.[Customer_Name],a.[Client_Phone],b.lang,a.Call_Time,a.Cust_FeedBack,a.JOB_NO,a.SERIAL_NO
                                from [JOB_REQUEST_TRANSACTION] a inner join [192.168.100.42].dwh.dbo.CLNTDTL b
                                on a.[Client_No] = b.clntnum
                                inner join [JOB_REQUEST_MASTER] c
                                on c.Job_No = a.JOB_NO
                                where [Allocate_user] = '" + user + "' and Branch_Code = '" + branch + "' and c.Status = 'Allocated' order by JOB_NO,Call_Time";

            return SqlHelper.ExecuteDataset(strConnString, CommandType.Text, strQuery);
        }

        public DataSet load_GridView_Recruitment_CallAgentView(string user)
        {
            string strQuery = @"select distinct ROW_NUMBER() over (order by a.JOB_NO)Sequence_no,branch_code,customer_name,client_phone,a.job_no,serial_no 
                                from [JOB_REQUEST_TRANSACTION] a
                                inner join [JOB_REQUEST_MASTER] b
                                on a.JOB_NO = b.Job_No
                                where call_type = 'RECRUITMENT CALLINGS' and Allocate_user = '"+user+"' and a.Status = 'Pending' and Recovery_Status is null and b.Status = 'Allocated' order by job_no";

            return SqlHelper.ExecuteDataset(strConnString, CommandType.Text, strQuery);
        }

        public DataSet load_GridView_CallAgent_View_AccordingToPolicyNo(string user,string policy_no)
        {
//            string strQuery = @"select distinct ROW_NUMBER() over (order by JOB_NO,Call_Time)Sequence_no,a.Branch_Code,a.SO_CODE,a.[Call_Type],a.[Client_No],a.[Policy_No],a.[Customer_Name],a.[Client_Phone],b.lang,a.Call_Time,a.Cust_FeedBack,a.JOB_NO,a.SERIAL_NO
//                                from [priya_LetterGenerator_Live].[dbo].[JOB_REQUEST_TRANSACTION] a inner join [192.168.100.42].dwh.dbo.CLNTDTL b
//                                on a.[Client_No] = b.clntnum
//                                where [Allocate_user] = '" + user + "' and [Policy_No] = '" + policy_no + "' and Call_Time < 3 and Status = 'Pending' and (Recovery_Status is null or Recovery_Status = 'NO') order by JOB_NO,Call_Time";

//            string strQuery = @"select distinct ROW_NUMBER() over (order by a.JOB_NO,Call_Time)Sequence_no,a.Branch_Code,a.SO_CODE,a.[Call_Type],a.[Client_No],a.[Policy_No],a.[Customer_Name],a.[Client_Phone],b.lang,a.Call_Time,a.Cust_FeedBack,a.JOB_NO,a.SERIAL_NO
//                                from [priya_LetterGenerator_Live].[dbo].[JOB_REQUEST_TRANSACTION] a inner join [192.168.100.42].dwh.dbo.CLNTDTL b
//                                on a.[Client_No] = b.clntnum
//                                inner join [priya_LetterGenerator_Live].[dbo].[JOB_REQUEST_MASTER] c
//                                on c.Job_No = a.JOB_NO
//                                where [Allocate_user] = '" + user + "' and [Policy_No] = '" + policy_no + "' and a.Status = 'Pending' and (Recovery_Status is null) and c.Status = 'Allocated' order by JOB_NO,Call_Time";

              string strQuery = @"select distinct ROW_NUMBER() over (order by a.JOB_NO,Call_Time)Sequence_no,a.Branch_Code,a.SO_CODE,a.[Call_Type],
                                a.[Client_No],a.[Policy_No],a.[Customer_Name],a.[Client_Phone],
                                b.lang,a.Call_Time,a.Cust_FeedBack,a.JOB_NO,a.SERIAL_NO
                                from [JOB_REQUEST_TRANSACTION] a inner join [192.168.100.42].dwh.dbo.CLNTDTL b
                                on a.[Client_No] = b.clntnum
                                inner join [JOB_REQUEST_MASTER] c
                                on c.Job_No = a.JOB_NO
                                where [Allocate_user] = '" + user + "' and Client_No = (select distinct Client_No from JOB_REQUEST_TRANSACTION where Policy_No = '" + policy_no + "') and c.Status = 'Allocated' order by JOB_NO,Call_Time";

            return SqlHelper.ExecuteDataset(strConnString, CommandType.Text, strQuery);
        }

        public DataSet getSyscodeRemarks(string description)
        {
            string strQuery = @"select REMARKS from [JOB_SYSCODE] where TYPE = 'FEEDBACK' and DESCRIPTION = '" + description + "'";

            return SqlHelper.ExecuteDataset(strConnString, CommandType.Text, strQuery);
        }

        public DataSet getRecruitmentSyscodeRemarks(string description)
        {
            string strQuery = @"select REMARKS from [JOB_SYSCODE] where TYPE = 'RECRUITMENT_FEEDBACK' and DESCRIPTION = '" + description + "'";

            return SqlHelper.ExecuteDataset(strConnString, CommandType.Text, strQuery);
        }

        public DataSet load_GridView_JobCompletion()
        {
            string strQuery = @"SELECT Job_no,Branch_Code,Allocated_date,Allocate_user,
                                ISNULL([Completed],0)[Completed], ISNULL([Pending],0)[Pending]
                                FROM
                                (select b.Job_no,b.Branch_Code,a.Allocated_date,b.Allocate_user,b.Status,count(*)CNT
                                from JOB_REQUEST_MASTER a, JOB_REQUEST_TRANSACTION b
                                where
                                a.job_no=b.job_no and
                                a.status='Allocated' 
                                group by b.Job_no,b.Branch_Code,a.Allocated_date,b.Allocate_user,b.Status) AS SourceTable
                                PIVOT
                                (
                                SUM(CNT)
                                FOR [Status] IN ([Completed], [Pending])
                                ) AS PivotTable
                                order by Job_no
                                ";

            return SqlHelper.ExecuteDataset(strConnString, CommandType.Text, strQuery);
        }

        public DataSet loadDropDownBranch(string user)
        {
            //string strQuery = @"select distinct Branch_Code from [priya_LetterGenerator_Live].[dbo].[JOB_REQUEST_TRANSACTION]  where Allocate_user = '" + user + "' and call_time <3 and (Recovery_Status is null or Recovery_Status = 'NO')";

            string strQuery = @"select distinct Branch_Code from [JOB_REQUEST_TRANSACTION] a 
                                inner join [JOB_REQUEST_MASTER] b
                                on a.JOB_NO = b.Job_No
                                where Allocate_user = '" + user + "' and call_time <3 and (Recovery_Status is null or Recovery_Status = 'NO') and b.Status = 'Allocated'";

            return SqlHelper.ExecuteDataset(strConnString, CommandType.Text, strQuery);
        }

        public DataSet getcscBranch(string userBranch)
        {
            string strQuery = @"select DESCITEM from cscsuboffice where SHORTDESC = '" + userBranch + "'";

            return SqlHelper.ExecuteDataset(ConnString, CommandType.Text, strQuery);
        }

        public DataSet getBranchCode()
        {
            string strQuery = @"select DESCITEM,LONGDESC from cscsuboffice where DESCITEM in 
                                (
                                select distinct ARACDE from agntdtl where dtetrm='99999999' 
                                and agntnum not between '00050000' and '00199999' and
                                agntnum <'00300000' and
                                agtype not in ('PA','LG','BK')
                                ) order by LONGDESC asc
                                ";

            return SqlHelper.ExecuteDataset(ConnString, CommandType.Text, strQuery);
        }

        public DataSet loadDropdownAgentNo(string branch,string user)
        {
            //string strQuery = @"select distinct SO_CODE from [priya_LetterGenerator_Live].[dbo].[JOB_REQUEST_TRANSACTION] where Allocate_user = '" + user + "' and Branch_Code = '" + branch + "' and call_time <3 and (Recovery_Status is null or Recovery_Status = 'NO')";

            string strQuery = @"select distinct SO_CODE from [JOB_REQUEST_TRANSACTION] a
                                inner join [JOB_REQUEST_MASTER] b
                                on a.JOB_NO = b.Job_No
                                where Allocate_user = '" + user + "' and Branch_Code = '" + branch + "' and call_time <3 and (Recovery_Status is null or Recovery_Status = 'NO') and b.Status = 'Allocated'";

            return SqlHelper.ExecuteDataset(strConnString, CommandType.Text, strQuery);
        }

        public DataSet loadFeedback()
        {
            string strQuery = @"select DESCRIPTION from [JOB_SYSCODE] where TYPE = 'FEEDBACK'";

            return SqlHelper.ExecuteDataset(strConnString, CommandType.Text, strQuery);
        }

        public DataSet loadRecruitmentFeedback()
        {
            string strQuery = @"select DESCRIPTION from [JOB_SYSCODE] where TYPE = 'RECRUITMENT_FEEDBACK'";

            return SqlHelper.ExecuteDataset(strConnString, CommandType.Text, strQuery);
        }

        public int updateTransaction(string userId, string cust_feedback, string remarks, string Recovery_Status, string policy_no, string job_no, string serial_no, int call_time, string Status)
        {
            System.Data.SqlClient.SqlParameter[] param = new System.Data.SqlClient.SqlParameter[9];

            string strQuery = @"update [JOB_REQUEST_TRANSACTION]
                                set Complete_Date = getdate(),Cust_FeedBack = @cust_feedback,Remarks = @remarks,Recovery_Status =@Recovery_Status,Call_Time =@call_time,Status = @Status
                                where Policy_No = @policy_no and JOB_NO =@JOB_NO and SERIAL_NO =@SERIAL_NO and Allocate_user = @userId";

            param[0] = new System.Data.SqlClient.SqlParameter("@userId", SqlDbType.VarChar);
            param[0].Value = userId;

            param[1] = new System.Data.SqlClient.SqlParameter("@cust_feedback", SqlDbType.VarChar);
            param[1].Value = cust_feedback;

            param[2] = new System.Data.SqlClient.SqlParameter("@remarks", SqlDbType.VarChar);
            param[2].Value = remarks;

            param[3] = new System.Data.SqlClient.SqlParameter("@Recovery_Status", SqlDbType.VarChar);
            param[3].Value = Recovery_Status;

            param[4] = new System.Data.SqlClient.SqlParameter("@Call_Time", SqlDbType.VarChar);
            param[4].Value = call_time;

            param[5] = new System.Data.SqlClient.SqlParameter("@policy_no", SqlDbType.VarChar);
            param[5].Value = policy_no;

            param[6] = new System.Data.SqlClient.SqlParameter("@JOB_NO", SqlDbType.VarChar);
            param[6].Value = job_no;

            param[7] = new System.Data.SqlClient.SqlParameter("@SERIAL_NO", SqlDbType.VarChar);
            param[7].Value = serial_no;

            param[8] = new System.Data.SqlClient.SqlParameter("@Status", SqlDbType.VarChar);
            param[8].Value = Status;

            return _db.update(strQuery, param);
        }

        public DataSet SendMail(string msg, string EmailAddress, string subject)
        {
            SqlParameter[] param = null;
            param = new SqlParameter[3];

            param[0] = new SqlParameter("@MESSAGE", SqlDbType.VarChar);
            param[0].Value = msg.Trim();

            param[1] = new SqlParameter("@MAIL_ADD", SqlDbType.VarChar);
            param[1].Value = EmailAddress.Trim();

            param[2] = new SqlParameter("@subject", SqlDbType.VarChar);
            param[2].Value = subject.Trim();

            return SqlHelper.ExecuteDataset(strConnString, CommandType.StoredProcedure, "usp_SEND_MAILS", param);
        }

        public int updateCreateDate(string userId, string cust_feedback, string remarks, string policy_no, string job_no, string serial_no)
        {
            System.Data.SqlClient.SqlParameter[] param = new System.Data.SqlClient.SqlParameter[6];

            string strQuery = @"update [JOB_REQUEST_TRANSACTION]
                                set Create_date = getdate()
                                where Policy_No = @policy_no and JOB_NO =@JOB_NO and SERIAL_NO =@SERIAL_NO and Allocate_user = @userId";

            param[0] = new System.Data.SqlClient.SqlParameter("@userId", SqlDbType.VarChar);
            param[0].Value = userId;

            param[1] = new System.Data.SqlClient.SqlParameter("@cust_feedback", SqlDbType.VarChar);
            param[1].Value = cust_feedback;

            param[2] = new System.Data.SqlClient.SqlParameter("@remarks", SqlDbType.VarChar);
            param[2].Value = remarks;

            param[3] = new System.Data.SqlClient.SqlParameter("@policy_no", SqlDbType.VarChar);
            param[3].Value = policy_no;

            param[4] = new System.Data.SqlClient.SqlParameter("@JOB_NO", SqlDbType.VarChar);
            param[4].Value = job_no;

            param[5] = new System.Data.SqlClient.SqlParameter("@SERIAL_NO", SqlDbType.VarChar);
            param[5].Value = serial_no;

            return _db.update(strQuery, param);
        }

        public DataSet checkHoliday(string date)
        {
            string strQuery = @"select * from calender1 where Date = '" + date + "'";

            return SqlHelper.ExecuteDataset(ConnString, CommandType.Text, strQuery);
        }

        public DataSet loadGdvJobReallocation(string allocateUser_Id)
        {
//            string strQuery = @"select distinct a.job_no,a.Allocate_user from [priya_LetterGenerator_Live].[dbo].[JOB_REQUEST_TRANSACTION] a
//                                inner join [priya_LetterGenerator_Live].[dbo].[JOB_REQUEST_MASTER] b on a.JOB_NO = b.Job_No
//                                where b.Status = 'Pending'";

            string strQuery = @"select  a.job_no,count([SERIAL_NO])[count],a.Branch_Code from [JOB_REQUEST_TRANSACTION] a
                                inner join [JOB_REQUEST_MASTER] b on a.JOB_NO = b.Job_No
                                where b.status <> 'Completed' and Allocate_user = '"+allocateUser_Id+"' and Recovery_Status is null group by a.job_no,a.Branch_Code";

            return SqlHelper.ExecuteDataset(strConnString, CommandType.Text, strQuery);
        }

        public int update_JobComplete(string job_no)
        {
            System.Data.SqlClient.SqlParameter[] param = new System.Data.SqlClient.SqlParameter[1];

//            string strQuery = @"update JOB_REQUEST_MASTER set
//                                status='Completed',
//                                Complete_date=getdate(),
//                                Total_cost=(select sum(Recover_Amount) from JOB_REQUEST_TRANSACTION where Job_no=@job_no and Recovery_Status='YES') where Job_no=@job_no";

            string strQuery = @"update JOB_REQUEST_MASTER set
                                status='Completed',
                                Complete_date=getdate(),
                                Total_cost=(select sum(Recover_Amount) from JOB_REQUEST_TRANSACTION where Job_no=@job_no) where Job_no=@job_no";

            param[0] = new System.Data.SqlClient.SqlParameter("@job_no", SqlDbType.VarChar);
            param[0].Value = job_no;

            return _db.update(strQuery, param);
        }

        public DataSet getMailAttachment(string job_no)
        {
            string strQuery = @"select Recovery_SO_CODE,sum(Recover_Amount) as Recovery_amount
                                from JOB_REQUEST_TRANSACTION
                                where 
                                Job_no='"+job_no+"' and Recovery_Status='YES' group by Recovery_SO_CODE";

            return SqlHelper.ExecuteDataset(strConnString, CommandType.Text, strQuery);
        }

        public DataSet sendMailAttachments(string job_no)
        {
            SqlParameter[] param = null;
            param = new SqlParameter[1];

            param[0] = new SqlParameter("@JOB_NO", SqlDbType.VarChar);
            param[0].Value = job_no.Trim();

            return SqlHelper.ExecuteDataset(strConnString, CommandType.StoredProcedure, "usp_Send_MailAttachments", param);
        }

        public DataSet loadGridView_PendingJobs()
        {
            string strQuery = @"select Allocate_user,[DESCRIPTION],Job_Type,count([SERIAL_NO])[count] from [JOB_REQUEST_TRANSACTION] a
                                inner join [JOB_REQUEST_MASTER] b
                                on a.JOB_NO = b.Job_No 
                                inner join [JOB_SYSCODE] c
                                on a.Allocate_user = c.CODE
                                where b.status = 'Allocated' and c.TYPE = 'CALL_AGENT' and a.Status = 'Pending' and Recovery_Status is null
                                group by Allocate_user,[DESCRIPTION],Job_Type";

            return SqlHelper.ExecuteDataset(strConnString, CommandType.Text, strQuery);
        }

        public DataSet loadDDL_Agent(string allocateUser_Id)
        {
            string strQuery = @"select [DESCRIPTION] from [JOB_SYSCODE] where [TYPE] = 'CALL_AGENT' and CODE <> '"+allocateUser_Id+"'";

            return SqlHelper.ExecuteDataset(strConnString, CommandType.Text, strQuery);
        }

        public int updateTransactionAllocateUser(string job_no,string branch_code,string ReAllocated_user)
        {
            System.Data.SqlClient.SqlParameter[] param = new System.Data.SqlClient.SqlParameter[3];

            string strQuery = @"update [JOB_REQUEST_TRANSACTION]
                                set Allocate_user = @Allocate_user
                                where JOB_NO =@JOB_NO and Branch_Code = @Branch_Code and status = 'Pending' and Recovery_Status is null";

            param[0] = new System.Data.SqlClient.SqlParameter("@Allocate_user", SqlDbType.VarChar);
            param[0].Value = ReAllocated_user.Trim();

            param[1] = new System.Data.SqlClient.SqlParameter("@JOB_NO", SqlDbType.VarChar);
            param[1].Value = job_no.Trim();

            param[2] = new System.Data.SqlClient.SqlParameter("@Branch_Code", SqlDbType.VarChar);
            param[2].Value = branch_code.Trim();

            return _db.update(strQuery, param);
        }

        public DataSet getUserId(string user)
        {
            string strQuery = @"select [CODE] from [JOB_SYSCODE] where [TYPE] = 'CALL_AGENT' and [DESCRIPTION] = '" + user + "'";

            return SqlHelper.ExecuteDataset(strConnString, CommandType.Text, strQuery);
        }

        public DataSet loadGridView_DownloadData()
        {
            string strQuery = @"SELECT Branch_Code,(recovery_so_code)as [Employee Number],null as [Employee Name],convert(numeric(18,2),sum(recover_amount)) as Amount,job_no FROM [JOB_REQUEST_TRANSACTION] where status='Completed' and recovery_status='YES' and download_status is null and job_no in (SELECT  [Job_No]  FROM [JOB_REQUEST_MASTER]  where status='Completed')group by Branch_Code,recovery_so_code,job_no order by Branch_Code,recovery_so_code";

            return SqlHelper.ExecuteDataset(strConnString, CommandType.Text, strQuery);
        }

        public int updateDownloadStatus(string user, string job_no, string recovery_socode)
        {
            System.Data.SqlClient.SqlParameter[] param = new System.Data.SqlClient.SqlParameter[3];

            string strQuery = @"update [JOB_REQUEST_TRANSACTION] 
                              set Download_status = 'YES',Download_date = getdate(),Download_user = @user
                              where Recovery_Status = 'YES' and JOB_NO = @job_no and Recovery_SO_CODE = @recovery_socode";

            param[0] = new System.Data.SqlClient.SqlParameter("@user", SqlDbType.VarChar);
            param[0].Value = user.Trim();

            param[1] = new System.Data.SqlClient.SqlParameter("@job_no", SqlDbType.VarChar);
            param[1].Value = job_no.Trim();

            param[2] = new System.Data.SqlClient.SqlParameter("@recovery_socode", SqlDbType.VarChar);
            param[2].Value = recovery_socode.Trim();

            return _db.update(strQuery, param);
        }

        public int insertToUserChangeLog(string job_no, string branch_code, string existing_user, string new_user, string create_user, string create_ip)
        {
            string strQuery = @"INSERT INTO [USER_CHANGE_LOG]
                               ([JOB_NO]
                               ,[BRANCH_CODE]
                               ,[EXISTING_USER]
                               ,[NEW_USER]
                               ,[CREATE_DATE]
                               ,[CREATE_USER]
                               ,[CREATE_IP])
                         VALUES
                               ('"+job_no+"','"+branch_code+"','"+existing_user+"','"+new_user+"',getdate(),'"+create_user+"','"+create_ip+"')";

            return SqlHelper.ExecuteNonQuery(strConnString, CommandType.Text, strQuery);
        }

      

        public DataSet getJobDetails(string jobString)
        {
//            string strQuery = @"select ltrim(rtrim(Policy_No+', '+Customer_Name+', '+Client_Phone))
//                                from [priya_LetterGenerator_Live].[dbo].[JOB_REQUEST_TRANSACTION]
//                                where job_no in ("+jobString+") and Client_Phone like '07%' and (LEN(ltrim(rtrim(Client_Phone))))=10";

            string strQuery = @"select phone from (select ltrim(rtrim(policy_no))+', '+ltrim(rtrim(replace(Customer_Name,',','')))+', '+ltrim(rtrim(dbo.ufn_GetNumber(client_phone))) 
                                as phone from dbo.JOB_REQUEST_TRANSACTION where job_no in (" +jobString+")) A where phone is not null";

            return SqlHelper.ExecuteDataset(strConnString, CommandType.Text, strQuery);
        }

        public DataSet getModelPopupPolicyDetails(string job_no, string serial_no, string policy_no)
        {
            string strQuery = @"select convert(varchar(10),Due_Date,111)Due_Date,convert(varchar(10),Risk_Date,111)Risk_Date,Premium,Mode,Policy_Type,Client_Phone from [JOB_REQUEST_TRANSACTION] 
                                where JOB_NO = '" + job_no + "' and SERIAL_NO = '" + serial_no + "' and Policy_No = '" + policy_no + "'";

            return SqlHelper.ExecuteDataset(strConnString, CommandType.Text, strQuery);
        }

        public DataSet loadJobCompletedBranch(string user)
        {
            string strQuery = @"select distinct Branch_Code from [JOB_REQUEST_TRANSACTION] a
                                 inner join [JOB_REQUEST_MASTER] b on b.Job_No = a.JOB_NO
                                 where Allocate_user = '" + user + "' and a.Status = 'Completed' and b.Status = 'Completed'";

            return SqlHelper.ExecuteDataset(strConnString, CommandType.Text, strQuery);
        }

        public DataSet loadGridView_Completed_jobs(string user,string branch)
        {
//            string strQuery = @"select distinct ROW_NUMBER() over (order by a.JOB_NO,Call_Time)Sequence_no,a.Branch_Code,a.SO_CODE,a.[Call_Type],a.[Client_No],a.[Policy_No],a.[Customer_Name],a.[Client_Phone],b.lang,a.Call_Time,a.Cust_FeedBack,a.Remarks,a.JOB_NO,a.SERIAL_NO
//                                from [priya_LetterGenerator_Live].[dbo].[JOB_REQUEST_TRANSACTION] a inner join [192.168.100.42].dwh.dbo.CLNTDTL b
//                                on a.[Client_No] = b.clntnum
//                                inner join [priya_LetterGenerator_Live].[dbo].[JOB_REQUEST_MASTER] c
//                                on c.Job_No = a.JOB_NO
//                                where [Allocate_user] = '" + user + "' and Branch_Code = '" + branch + "' and a.Status = 'Completed' and c.Status = 'Completed' order by JOB_NO,Call_Time";

            string strQuery = @"select distinct ROW_NUMBER() over (order by a.JOB_NO,Call_Time)Sequence_no,a.Branch_Code,a.SO_CODE,a.[Call_Type],
                                a.[Client_No],a.[Policy_No],a.[Customer_Name],a.[Client_Phone],b.lang,a.Call_Time,a.Cust_FeedBack,a.Remarks,a.JOB_NO,
                                a.SERIAL_NO
                                from [JOB_REQUEST_TRANSACTION] a inner join [192.168.100.42].dwh.dbo.CLNTDTL b
                                on a.[Client_No] = b.clntnum
                                inner join [JOB_REQUEST_MASTER] c
                                on c.Job_No = a.JOB_NO
                                where [Allocate_user] = '" + user + "' and Branch_Code = '" + branch + "' and a.Status = 'Completed' and c.Status = 'Completed' union all select distinct ROW_NUMBER() over (order by a.JOB_NO,Call_Time)Sequence_no,a.Branch_Code,a.SO_CODE,a.[Call_Type],a.[Client_No],a.[Policy_No],a.[Customer_Name],a.[Client_Phone],'' as lang,a.Call_Time,a.Cust_FeedBack,a.Remarks,a.JOB_NO,a.SERIAL_NO from [JOB_REQUEST_TRANSACTION] a inner join [JOB_REQUEST_MASTER] b on b.Job_No = a.JOB_NO where [Allocate_user] = '" + user + "' and Branch_Code = '" + branch + "' and a.Status = 'Completed' and Call_Type = 'RECRUITMENT CALLINGS' order by JOB_NO,Call_Time";

            return SqlHelper.ExecuteDataset(strConnString, CommandType.Text, strQuery);
        }

        public DataSet getExtraPolicyDetails(string policy_no)
        {
//            string strQuery = @"select a.REGISTER,a.BALANCE,a.CNTTYPE,a.BILLFREQ,a.AGNTNUM,convert(varchar(10),CONVERT(DATETIME, CONVERT(CHAR(8), b.CLTDOB), 112),111)as CLTDOB,b.SECUITYNO,(isnull(replace(replace(ltrim(RTRIM(b.CLTADDR03)),' ',''),'..',''),0)+ (isnull(replace(replace(ltrim(RTRIM(b.CLTADDR04)),' ',''),'..',''),0))) as ADDRESS,c.CLTADDR01,b.lang from pda1 a inner join CLNTDTL b on a.COWNNUM = b.CLNTNUM
//                                inner join agntdtl c on a.AGNTNUM = c.AGNTNUM 
//                                where a.CHDRNUM = '" + policy_no + "'";

            string strQuery = @"select a.REGISTER,a.BALANCE,a.CNTTYPE,a.BILLFREQ,a.AGNTNUM,substring(cast(a.PTDATE as varchar),1,4)+'/'+substring(cast(a.PTDATE as varchar),5,2)+'/'+substring(cast(a.PTDATE as varchar),7,2)PTDATE, 
                                CLTDOB=case when  len(b.CLTDOB)=8 then
                                substring(cast(b.CLTDOB as varchar),1,4)+'/'+substring(cast(b.CLTDOB as varchar),5,2)+'/'+substring(cast(b.CLTDOB as varchar),7,2) 
                                else '' end,b.SECUITYNO,(isnull(replace(replace(ltrim(RTRIM(b.CLTADDR03)),' ',''),'..',''),0)+ 
                                (isnull(replace(replace(ltrim(RTRIM(b.CLTADDR04)),' ',''),'..',''),0))) as ADDRESS,c.CLTADDR01,b.lang from pda1 
                                a inner join CLNTDTL b on a.COWNNUM = b.CLNTNUM
                                inner join agntdtl c on a.AGNTNUM = c.AGNTNUM  
                                where a.CHDRNUM = '" + policy_no + "'";

            return SqlHelper.ExecuteDataset(ConnString, CommandType.Text, strQuery);
        }

        public int removeWelcomeCallsPolicyLog(string emp_Id)
        {
            string strQuery = @"delete FROM [JOB_REQUEST_WELCOME_CALLS_POLICY_LOG] where EMP_ID ='" + emp_Id + "'";

            return SqlHelper.ExecuteNonQuery(strConnString, CommandType.Text, strQuery);
        }

        public int saveWelcomeCallsPolicyLog(string emp_Id, string policy_no)
        {
            string strQuery = @"INSERT INTO [JOB_REQUEST_WELCOME_CALLS_POLICY_LOG] (EMP_ID,POLICY_NO)
                                VALUES ('" + emp_Id + "',replace(ltrim(rtrim('" + policy_no + "')),' ',''))";

            return SqlHelper.ExecuteNonQuery(strConnString, CommandType.Text, strQuery);
        }

        public DataSet getUploadedWelcomePolicyDetails(string emp_Id)
        {
            string strQuery = @"select distinct * from (select ltrim(rtrim(CHDRNUM))+', '+(case when ltrim(rtrim(a.CLTADDR01)) like '%,' then substring(ltrim(rtrim(a.CLTADDR01)), 1, len(ltrim(rtrim(a.CLTADDR01))) -1) 
                                else ltrim(rtrim(a.CLTADDR01)) end)+', '+
                                dbo.ufn_GetNumber(case
                                when (LTRIM(RTRIM(CLTPHONE02)) <> '' and LTRIM(rtrim(CLTPHONE01)) <> '') then (LTRIM(RTRIM(CLTPHONE01))+','+LTRIM(RTRIM(CLTPHONE02)))
                                when LTRIM(rtrim(CLTPHONE01)) <> '' then LTRIM(rtrim(CLTPHONE01))
                                when LTRIM(RTRIM(CLTPHONE02)) <> '' then LTRIM(RTRIM(CLTPHONE02))
                                end)PhoneNumber
                                from [192.168.100.42].dwh.dbo.pda1 a 
                                inner join [192.168.100.42].dwh.dbo.clntdtl b on a.COWNNUM = b.CLNTNUM
                                inner join [JOB_REQUEST_WELCOME_CALLS_POLICY_LOG] c on a.CHDRNUM = c.POLICY_NO and c.emp_id = '" +emp_Id+"') ab where ab.PhoneNumber is not null";

            return SqlHelper.ExecuteDataset(strConnString, CommandType.Text, strQuery);
        }

        public int removeJobRequestRecruitmentLog(string emp_Id)
        {
            string strQuery = @"delete FROM [JOB_REQUEST_RECRUITMENT_LOG] where EMP_ID ='" + emp_Id + "'";

            return SqlHelper.ExecuteNonQuery(strConnString, CommandType.Text, strQuery);
        }

        public int saveJobRequestRecruitmentLog(string emp_Id, string cus_name, string client_phone)
        {
            try
            {
                string strQuery = @"INSERT INTO [JOB_REQUEST_RECRUITMENT_LOG]
                                   ([EMP_ID]
                                   ,[CUS_NAME]
                                   ,[CLIENT_PHONE])
                             VALUES
                                   ('" + emp_Id + "','" + cus_name + "','" + client_phone + "')";

                return SqlHelper.ExecuteNonQuery(strConnString, CommandType.Text, strQuery);
            }
            catch (Exception)
            {
                throw;
            }
        }

        public DataSet getRecruitmentPolicyLog(string jobString)
        {
//            string strQuery = @"select cus_name+', '+ltrim(rtrim(replace(replace(client_phone,'-',''),'','')))outbound from [priya_LetterGenerator_Live].[dbo].[JOB_REQUEST_RECRUITMENT_LOG]
//                                where EMP_ID = '" + emp_Id + "' and LEN(ltrim(rtrim(replace(replace(client_phone,'-',''),'',''))))=10";

            string strQuery = @"select Customer_Name+', '+ltrim(rtrim(replace(replace(client_phone,'-',''),'','')))outbound from [JOB_REQUEST_TRANSACTION]
                                where job_no in (" + jobString + ") and LEN(ltrim(rtrim(replace(replace(client_phone,'-',''),'',''))))=10";

            return SqlHelper.ExecuteDataset(strConnString, CommandType.Text, strQuery);
        }

        public DataSet getRecruitmentDetails(string emp_Id)
        {
            string strQuery = @"select cus_name,ltrim(rtrim(replace(replace(client_phone,'-',''),'','')))client_phone 
                                from [JOB_REQUEST_RECRUITMENT_LOG]
                                where EMP_ID = '" + emp_Id + "' and LEN(ltrim(rtrim(replace(replace(client_phone,'-',''),'',''))))=10";

            return SqlHelper.ExecuteDataset(strConnString, CommandType.Text, strQuery);
        }

        public DataSet getMissingRecords(string user, string branch)
        {
//            string strQuery = @"(select policy_no from [priya_LetterGenerator_Live].[dbo].[JOB_REQUEST_POLICY_LOG]
//                                where [EMP_ID] = '"+user+"' and POLICY_NO NOT IN (select chdrnum from [192.168.100.42].dwh.dbo.pda1 where REGISTER = '"+branch+"') UNION select policy_no from [priya_LetterGenerator_Live].[dbo].[JOB_REQUEST_POLICY_LOG] where POLICY_NO in (SELECT b.policy_no FROM [192.168.100.42].dwh.dbo.pda1 a INNER JOIN [192.168.100.42].dwh.dbo.policyholder b  ON a.CHDRNUM = b.policy_no inner join dbo.JOB_REQUEST_POLICY_LOG on b.policy_no = dbo.JOB_REQUEST_POLICY_LOG.POLICY_NO and dbo.JOB_REQUEST_POLICY_LOG.EMP_ID = '"+user+"' INNER JOIN [192.168.100.42].dwh.dbo.CLNTDTL c ON a.COWNNUM = c.CLNTNUM where LTRIM(RTRIM(c.CLTPHONE01)) = '' and  LTRIM(RTRIM(c.CLTPHONE02)) = '')) UNION (SELECT POLICY_NO FROM [dbo].[JOB_REQUEST_POLICY_LOG] where EMP_ID = '"+user+"' EXCEPT (SELECT b.policy_no FROM [192.168.100.42].dwh.dbo.pda1 a INNER JOIN [192.168.100.42].dwh.dbo.policyholder b  ON a.CHDRNUM = b.policy_no inner join dbo.JOB_REQUEST_POLICY_LOG on b.policy_no = dbo.JOB_REQUEST_POLICY_LOG.POLICY_NO and dbo.JOB_REQUEST_POLICY_LOG.EMP_ID = '"+user+"' INNER JOIN [192.168.100.42].dwh.dbo.CLNTDTL  c ON a.COWNNUM = c.CLNTNUM INNER JOIN [192.168.100.42].dwh.dbo.agntdtl d ON a.AGNTNUM = d.AGNTNUM where d.dtetrm='99999999' and d.agntnum not between '00050000' and '00199999' and d.agntnum <'00300000' and d.agtype not in ('PA','LG','BK')))";

            string strQuery = @"(select policy_no from JOB_REQUEST_POLICY_LOG 
                                where [EMP_ID] = '" + user + "' and POLICY_NO NOT IN (select chdrnum from dwh.dbo.pda1 where REGISTER = '" + branch + "')UNION select policy_no from JOB_REQUEST_POLICY_LOG where POLICY_NO in (SELECT b.policy_no FROM pda1 a INNER JOIN policyholder b  ON a.CHDRNUM = b.policy_no inner join JOB_REQUEST_POLICY_LOG on b.policy_no = JOB_REQUEST_POLICY_LOG.POLICY_NO and JOB_REQUEST_POLICY_LOG.EMP_ID = '" + user + "' INNER JOIN CLNTDTL c ON a.COWNNUM = c.CLNTNUM where LTRIM(RTRIM(c.CLTPHONE01)) = '' and  LTRIM(RTRIM(c.CLTPHONE02)) = ''))UNION (SELECT POLICY_NO FROM JOB_REQUEST_POLICY_LOG where EMP_ID = '" + user + "' EXCEPT (select distinct policy_no from(SELECT a.chdrnum as policy_no, case when (LTRIM(RTRIM(c.CLTPHONE02)) <> '' and LTRIM(rtrim(c.CLTPHONE01)) <> '') then (LTRIM(RTRIM(c.CLTPHONE01))+','+LTRIM(RTRIM(c.CLTPHONE02))) when LTRIM(rtrim(c.CLTPHONE01)) <> '' then LTRIM(rtrim(c.CLTPHONE01)) when LTRIM(RTRIM(c.CLTPHONE02)) <> '' then LTRIM(RTRIM(c.CLTPHONE02)) end as PhoneNumber FROM pda1 a ,CLNTDTL c, agntdtl d,JOB_REQUEST_POLICY_LOG e where a.AGNTNUM = d.AGNTNUM and a.COWNNUM = c.CLNTNUM and a.chdrnum = e.POLICY_NO and e.EMP_ID = '"+user+"' and len(a.CCDATE)=8 and d.dtetrm='99999999' and d.agntnum not between '00050000' and '00199999' and d.agntnum <'00300000' and d.agtype not in ('PA','LG','BK')) as AB where AB.PhoneNumber is not null))";

            return SqlHelper.ExecuteDataset(ConnString, CommandType.Text, strQuery);
        }

        public DataSet getCall_Type(string job_no)
        {
            string strQuery = @"select distinct call_type from [JOB_REQUEST_TRANSACTION] where job_no = '" + job_no + "'";

            return SqlHelper.ExecuteDataset(strConnString, CommandType.Text, strQuery);
        }

        public DataSet getMissingWelcomeNumbers(string emp_Id)
        {
            string strQuery = @"select distinct Policy_no from (select ltrim(rtrim(CHDRNUM))Policy_no,
                                dbo.ufn_GetNumber(case
                                when (LTRIM(RTRIM(CLTPHONE02)) <> '' and LTRIM(rtrim(CLTPHONE01)) <> '') then (LTRIM(RTRIM(CLTPHONE01))+','+LTRIM(RTRIM(CLTPHONE02)))
                                when LTRIM(rtrim(CLTPHONE01)) <> '' then LTRIM(rtrim(CLTPHONE01))
                                when LTRIM(RTRIM(CLTPHONE02)) <> '' then LTRIM(RTRIM(CLTPHONE02))
                                end)PhoneNumber
                                from [192.168.100.42].dwh.dbo.pda1 a 
                                inner join [192.168.100.42].dwh.dbo.clntdtl b on a.COWNNUM = b.CLNTNUM
                                inner join [JOB_REQUEST_WELCOME_CALLS_POLICY_LOG] c on a.CHDRNUM = c.POLICY_NO
                                and c.emp_id = '" + emp_Id + "') ab where ab.PhoneNumber is  null";

            return SqlHelper.ExecuteDataset(strConnString, CommandType.Text, strQuery);
        }
    }
}
