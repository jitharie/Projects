﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using System.Data.Odbc;

namespace DataObjects
{
    public class DB
    {
        #region .. Get Dataset - Advance ...
        public DataSet GetDatasSet_Advance(string sql, System.Data.SqlClient.SqlParameter[] sp_params, string _connType)
        {
            DataSet ds = new DataSet();
            // _RecNo = 0;
            using (SqlConnection connection = new SqlConnection())
            {

                if (_connType == "Local")
                    connection.ConnectionString = ConnectionStringClass.LocalConnectionString;
                else if (_connType == "dwh")
                    connection.ConnectionString = ConnectionStringClass.DwhConnectionString;
                else if (_connType == "Hrs")
                    connection.ConnectionString = ConnectionStringClass.HrConnectionString;


                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.CommandType = CommandType.Text;
                    cmd.Connection = connection;
                    cmd.CommandText = sql;
                    cmd.CommandTimeout = 0;

                    // set cmd parameters 
                    foreach (SqlParameter p in sp_params)
                    {
                        if (p != null)
                        {
                            cmd.Parameters.Add(p);
                        }
                    }

                    // set dataTable columns
                    DataTable dt = new DataTable();

                    connection.Open();
                    SqlDataReader dr = cmd.ExecuteReader();
                    bool HeaderNotCreated = true;

                    while (dr.Read())
                    {
                        if (HeaderNotCreated)
                        {
                            for (int fc = 0; fc < dr.FieldCount; fc++)
                            {
                                dt.Columns.Add(dr.GetName(fc));
                            }
                        }
                        HeaderNotCreated = false;

                        //_RecNo++;
                        //_Nrecno++;
                        DataRow tempRow = dt.NewRow();
                        for (int i = 0; i < dr.FieldCount; i++)
                        {
                            string pp = dr.GetDataTypeName(i).ToString();
                            string tt = dr[i].ToString();

                            if ((dr[i].ToString() != "NULL") && (dr[i].ToString() != ""))
                            {
                                if (dr.GetDataTypeName(i).ToString() == "varchar")
                                { tempRow[i] = dr[i].ToString(); }
                                else if (dr.GetDataTypeName(i).ToString() == "int")
                                { tempRow[i] = int.Parse(dr[i].ToString()); }
                                else if (dr.GetDataTypeName(i).ToString() == "decimal")
                                { tempRow[i] = decimal.Parse(dr[i].ToString()); }
                                else
                                { tempRow[i] = dr[i].ToString(); }
                            }
                        }
                        dt.Rows.Add(tempRow);
                    }
                    dr.Close();
                    ds.Tables.Add(dt);
                    connection.Close();

                    return ds;
                }
            }
        }
        #endregion

        #region .. New insert Update ..
        public int NewInsert_Update(string sp_name, System.Data.SqlClient.SqlParameter[] sp_params)
        {
            string _mes = "Saved.";
            try
            {
                using (SqlConnection connection = new SqlConnection())
                {
                    connection.ConnectionString = ConnectionStringClass.LocalConnectionString;

                    using (SqlCommand cmd = new SqlCommand())
                    {
                        cmd.Connection = connection;
                        cmd.CommandType = CommandType.Text;
                        cmd.CommandText = sp_name;
                        foreach (SqlParameter p in sp_params)
                        {
                            if (p != null)
                            {
                                cmd.Parameters.Add(p);
                            }
                        }
                        connection.Open();
                        return cmd.ExecuteNonQuery();
                    }
                }
            }
            catch (Exception ex)
            {
                _mes = ex.ToString();
                return 0;
            }
        }
        #endregion

        #region .. Insert to Master..
        public int Insert_Master(string sp_master, SqlParameter[] param, string User, string submit_date, string estimated_date, string status, string Total_cost, DataTable newdatatable, string call_type, string job_type)
        {
            using (SqlConnection connection = new SqlConnection())
            {
                connection.ConnectionString = ConnectionStringClass.LocalConnectionString;
                connection.Open();
                SqlTransaction transactions = connection.BeginTransaction();
                try
                {
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        cmd.Connection = connection;
                        cmd.CommandType = CommandType.Text;
                        cmd.CommandText = sp_master;
                        cmd.Transaction = transactions;

                        foreach (SqlParameter p in param)
                        {
                            if (p != null)
                            {
                                cmd.Parameters.Add(p);
                            }
                        }

                        cmd.ExecuteNonQuery();

                        cmd.Parameters.Clear();
                        cmd.CommandText = "SELECT @@IDENTITY";

                        int _identity = Convert.ToInt32(cmd.ExecuteScalar());

                        cmd.CommandText = @"INSERT INTO JOB_REQUEST_TRANSACTION
                                            (JOB_NO
                                            ,SERIAL_NO
                                            ,Client_No
                                            ,Policy_No
                                            ,Customer_Name
                                            ,Client_Phone
                                            ,Due_Date
                                            ,Risk_Date
                                            ,Premium
                                            ,Mode
                                            ,Status
                                            ,Policy_Type
                                            ,Call_Type
                                            ,Job_Type
                                            ,SO_CODE
                                            ,Branch_Code
                                            ,Create_date
                                            ,Recovery_SO_CODE
                                            ,Recover_Amount)
                                        VALUES
                                           (@JOB_NO
                                           ,@SERIAL_NO 
                                           ,@Client_No 
                                           ,@Policy_No 
                                           ,@Customer_Name
                                           ,@Client_Phone
                                           ,@Due_Date 
                                           ,@Risk_Date
                                           ,@Premium 
                                           ,@Mode 
                                           ,@Status 
                                           ,@Policy_Type 
                                           ,@Call_Type
                                           ,@Job_Type
                                           ,@SO_CODE
                                           ,@Branch_Code
                                           ,getDate()
                                           ,@Recovery_SO_CODE
                                           ,@Recover_Amount)";

                        //,@Allocate_user,@Allocate_Date

                        for (int i = 0; i < newdatatable.Rows.Count; i++)
                        {
                            if (i == 0)
                            {
                                cmd.Parameters.Add("@JOB_NO", SqlDbType.Int).Value = _identity;
                                cmd.Parameters.Add("@SERIAL_NO", SqlDbType.Int).Value = (i+1).ToString();
                                cmd.Parameters.Add("@Client_No", SqlDbType.VarChar).Value = newdatatable.Rows[i]["Client_No"].ToString();
                                cmd.Parameters.Add("@Policy_No", SqlDbType.VarChar).Value = newdatatable.Rows[i]["Policy_No"].ToString();
                                cmd.Parameters.Add("@Customer_Name", SqlDbType.VarChar).Value = newdatatable.Rows[i]["Customer_Name"].ToString();
                                cmd.Parameters.Add("@Client_Phone", SqlDbType.VarChar).Value = newdatatable.Rows[i]["PhoneNumber"].ToString();
                                cmd.Parameters.Add("@Due_Date", SqlDbType.VarChar).Value = newdatatable.Rows[i]["Due_Date"].ToString();
                                cmd.Parameters.Add("@Risk_Date", SqlDbType.VarChar).Value = newdatatable.Rows[i]["Risk_Date"].ToString();
                                cmd.Parameters.Add("@Premium", SqlDbType.VarChar).Value = newdatatable.Rows[i]["Premium"].ToString();
                                cmd.Parameters.Add("@Mode", SqlDbType.VarChar).Value = newdatatable.Rows[i]["Mode"].ToString();
                                cmd.Parameters.Add("@Status", SqlDbType.VarChar).Value = status;
                                cmd.Parameters.Add("@Policy_Type", SqlDbType.VarChar).Value = newdatatable.Rows[i]["Policy_Type"].ToString();
                                cmd.Parameters.Add("@Call_Type", SqlDbType.VarChar).Value = call_type;
                                cmd.Parameters.Add("@Job_Type", SqlDbType.VarChar).Value = job_type;
                                //cmd.Parameters.Add("@Allocate_user", SqlDbType.VarChar).Value = newdatatable.Rows[i]["cost_agent_no"].ToString();
                                //cmd.Parameters.Add("@Allocate_Date", SqlDbType.VarChar).Value = DateTime.Now; 
                                //cmd.Parameters.Add("@Cust_FeedBack", SqlDbType.VarChar).Value = newdatatable.Rows[i]["Remark"].ToString();
                                //cmd.Parameters.Add("@Remarks", SqlDbType.VarChar).Value = newdatatable.Rows[i]["Remark"].ToString();
                                cmd.Parameters.Add("SO_CODE", SqlDbType.VarChar).Value = newdatatable.Rows[i]["SO_CODE"].ToString();
                                cmd.Parameters.Add("@Branch_Code", SqlDbType.VarChar).Value = newdatatable.Rows[i]["Branch_Code"].ToString();
                                cmd.Parameters.Add("@Recovery_SO_CODE", SqlDbType.VarChar).Value = newdatatable.Rows[i]["cost_agent_no"].ToString();
                                cmd.Parameters.Add("@Recover_Amount", SqlDbType.VarChar).Value = newdatatable.Rows[i]["COST_PER_JOB"].ToString();
                               
                            }
                            else
                            {
                                cmd.Parameters["@JOB_NO"].Value = _identity;
                                cmd.Parameters["@SERIAL_NO"].Value = (i+1).ToString();
                                cmd.Parameters["@Client_No"].Value = newdatatable.Rows[i]["Client_No"].ToString().Trim();
                                cmd.Parameters["@Policy_No"].Value = newdatatable.Rows[i]["Policy_No"].ToString().Trim();
                                cmd.Parameters["@Customer_Name"].Value = newdatatable.Rows[i]["Customer_Name"].ToString().Trim();
                                cmd.Parameters["@Client_Phone"].Value = newdatatable.Rows[i]["PhoneNumber"].ToString();
                                cmd.Parameters["@Due_Date"].Value = newdatatable.Rows[i]["Due_Date"].ToString();
                                cmd.Parameters["@Risk_Date"].Value = newdatatable.Rows[i]["Risk_Date"].ToString();
                                cmd.Parameters["@Premium"].Value = newdatatable.Rows[i]["Premium"].ToString();
                                cmd.Parameters["@Mode"].Value = newdatatable.Rows[i]["Mode"].ToString();
                                cmd.Parameters["@Status"].Value = status;
                                cmd.Parameters["@Policy_Type"].Value = newdatatable.Rows[i]["Policy_Type"].ToString();
                                cmd.Parameters["@Call_Type"].Value = call_type;
                                cmd.Parameters["@Job_Type"].Value = job_type;
                                //cmd.Parameters["@Allocate_user"].Value = newdatatable.Rows[i]["cost_agent_no"].ToString();
                                //cmd.Parameters["@Allocate_Date"].Value = DateTime.Now;
                                //cmd.Parameters["@Cust_FeedBack"].Value = newdatatable.Rows[i]["Remark"].ToString();
                                //cmd.Parameters["@Remarks"].Value = newdatatable.Rows[i]["Remark"].ToString();
                                cmd.Parameters["SO_CODE"].Value = newdatatable.Rows[i]["SO_CODE"].ToString();
                                cmd.Parameters["@Recovery_SO_CODE"].Value = newdatatable.Rows[i]["cost_agent_no"].ToString();
                                cmd.Parameters["@Recover_Amount"].Value = newdatatable.Rows[i]["COST_PER_JOB"].ToString();
                               
                            }
                            cmd.ExecuteNonQuery();
                        }

                        //cmd.Parameters.Clear();
                        transactions.Commit();
                        connection.Close();
                    }
                    return 1;

                }
                catch (Exception ex)
                {
                    return 0;
                }
            }
        }
        #endregion
    
        //        internal int Save_Job_Requesting_data(string sp_master, SqlParameter[] param, string User, string submit_date, string estimated_date,string status, string Total_cost, DataTable newdatatable)
        //        {
        //            string sp_master_Transaction = @"INSERT INTO JOB_REQUEST_TRANSACTION
        //                                            (JOB_NO
        //                                            ,SERIAL_NO
        //                                            ,Client_No
        //                                            ,Policy_No
        //                                            ,Customer_Name
        //                                            ,Due_Date
        //                                            ,Risk_Date
        //                                            ,Premium
        //                                            ,Mode
        //                                            ,Status
        //                                            ,Allocate_user
        //                                            ,Allocate_Date
        //                                            ,Cust_FeedBack
        //                                            ,Remarks)
        //                                        VALUES
        //                                           (@JOB_NO
        //                                           ,@SERIAL_NO 
        //                                           ,@Client_No 
        //                                           ,@Policy_No 
        //                                           ,@Customer_Name
        //                                           ,@Due_Date 
        //                                           ,@Risk_Date
        //                                           ,@Premium 
        //                                           ,@Mode 
        //                                           ,@Status 
        //                                           ,@Allocate_user 
        //                                           ,@Allocate_Date 
        //                                           ,@Cust_FeedBack
        //                                           ,@Remarks)";

        //            using (SqlConnection conn = new SqlConnection())
        //            {
        //                conn.ConnectionString = ConnectionStringClass.LocalConnectionString;
        //                conn.Open();
        //                SqlTransaction transactions = conn.BeginTransaction();
        //                {
        //                    try
        //                    {
        //                        using (SqlCommand cmd = new SqlCommand())
        //                        {
        //                            cmd.Connection = conn;
        //                            cmd.CommandType = CommandType.Text;
        //                            cmd.CommandText = sp_master_Transaction;
        //                            cmd.Transaction = transactions;
        //                            foreach (SqlParameter p in param)
        //                            {
        //                                if (p != null)
        //                                {
        //                                    cmd.Parameters.Add(p);
        //                                }
        //                            }

        //                            cmd.Parameters.Clear();

        //                            int _identity = (int)cmd.ExecuteScalar();

        //                            cmd.CommandText = sp_master_Transaction;
        //                            cmd.Parameters.Clear();

        //                            for (int i = 0; i < newdatatable.Rows.Count; i++)
        //                            {
        //                                cmd.Parameters.Add("@JOB_NO", SqlDbType.Int).Value = _identity;
        //                                cmd.Parameters.Add("@SERIAL_NO", SqlDbType.Int).Value = newdatatable.Rows[i]["serial_No"].ToString();
        //                                cmd.Parameters.Add("@Client_No", SqlDbType.VarChar).Value = newdatatable.Rows[i]["Client_No"].ToString();
        //                                cmd.Parameters.Add("@Policy_No", SqlDbType.VarChar).Value = newdatatable.Rows[i]["Policy_No"].ToString();
        //                                cmd.Parameters.Add("@Customer_Name", SqlDbType.VarChar).Value = newdatatable.Rows[i]["Customer_Name"].ToString();
        //                                cmd.Parameters.Add("@Due_Date", SqlDbType.DateTime).Value = newdatatable.Rows[i]["Due_Date"].ToString();
        //                                cmd.Parameters.Add("@Risk_Date", SqlDbType.DateTime).Value = newdatatable.Rows[i]["Risk_Date"].ToString();
        //                                cmd.Parameters.Add("@Premium", SqlDbType.VarChar).Value = newdatatable.Rows[i]["Premium"].ToString();
        //                                cmd.Parameters.Add("@Mode", SqlDbType.VarChar).Value = newdatatable.Rows[i]["Mode"].ToString();
        //                                cmd.Parameters.Add("@Status", SqlDbType.VarChar).Value = status;
        //                                cmd.Parameters.Add("@Allocate_user", SqlDbType.VarChar).Value = newdatatable.Rows[i]["cost_agent_no"].ToString();
        //                                cmd.Parameters.Add("@Allocate_Date", SqlDbType.DateTime).Value = DateTime.Now; 
        //                                cmd.Parameters.Add("@Cust_FeedBack", SqlDbType.VarChar).Value = newdatatable.Rows[i]["Remark"].ToString();
        //                                cmd.Parameters.Add("@Remarks", SqlDbType.VarChar).Value = newdatatable.Rows[i]["Remark"].ToString();
        //                                cmd.ExecuteNonQuery();
        //                                cmd.Parameters.Clear();
        //                            }
        //                            transactions.Commit();
        //                            conn.Close();
        //                            return 1;

        //                        }// using sql command 
        //                    }
        //                    catch (Exception ex)
        //                    {
        //                        transactions.Rollback();
        //                        return 0;
        //                    }
        //                }
        //            }
        //        }


        internal int update(string strQuery, SqlParameter[] param)
           {
            try
            {
                using (SqlConnection connection = new SqlConnection())
                {
                    connection.ConnectionString = ConnectionStringClass.LocalConnectionString;

                    using (SqlCommand cmd = new SqlCommand())
                    {
                        cmd.Connection = connection;
                        cmd.CommandType = CommandType.Text;
                        cmd.CommandText = strQuery;

                         foreach (SqlParameter p in param)
                        {
                            if (p != null)
                            {
                                cmd.Parameters.Add(p);
                            }
                        }
                        connection.Open();
                        cmd.ExecuteNonQuery();
                    }
                    return 1;
                }
            }
            catch (Exception ex)
            {
                return 0;
            }
        }

       

        internal int updatedwh(string strQuery, SqlParameter[] param)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection())
                {
                    connection.ConnectionString = ConnectionStringClass.DwhConnectionString;

                    using (SqlCommand cmd = new SqlCommand())
                    {
                        cmd.Connection = connection;
                        cmd.CommandType = CommandType.Text;
                        cmd.CommandText = strQuery;

                        foreach (SqlParameter p in param)
                        {
                            if (p != null)
                            {
                                cmd.Parameters.Add(p);
                            }
                        }
                        connection.Open();
                        cmd.ExecuteNonQuery();
                    }
                    return 1;
                }
            }
            catch (Exception ex)
            {
                return 0;
            }
        }
    }
}
