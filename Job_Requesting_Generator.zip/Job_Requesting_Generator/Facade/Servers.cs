﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using DataObjects.SqlServers;

namespace Facade
{
    public static class  Servers
    {

        static Sql_Servers _sql = new Sql_Servers(); 
        static PasswordED _pwrdED = new PasswordED();

        public static DataSet get_Userdetails(string Userid, string Pwd)
        {
            return _sql.get_UserDetails(Userid, _pwrdED.encryptPassword(Pwd));
        }

        public static DataSet get_reqtype()
        {
            return _sql.get_reqtype();
        }

        public static DataSet get_agentno(string UserBranch)
        {
            return _sql.get_agent_no(UserBranch);
        }

        public static DataSet getcscBranch(string UserBranch)
        {
            return _sql.getcscBranch(UserBranch);
        }

        public static DataSet getBranchCode()
        {
            return _sql.getBranchCode();
        }

        public static DataSet getMailAttachment(string job_no)
        {
            return _sql.getMailAttachment(job_no);
        }

        public static DataSet SendMail(string msg, string EmailAddress, string subject)
        {
            return _sql.SendMail(msg,EmailAddress,subject);
        }

        public static DataSet sendMailAttachments(string job_no)
        {
            return _sql.sendMailAttachments(job_no);
        }

        public static DataSet getUploadedPolicyDetails(string emp_Id)
        {
            return _sql.getUploadedPolicyDetails(emp_Id);
        }

        public static DataSet getCall_time(string job_no, string serial_no, string policy_no)
        {
            return _sql.getCall_time(job_no, serial_no, policy_no);
        }

        public static DataSet getRecruitment_Call_time(string job_no, string serial_no)
        {
            return _sql.getRecruitment_Call_time(job_no, serial_no);
        }

        public static DataSet getall_policy_types()
        {
            return _sql.getall_policy_types();
        }

        public static DataSet get_policies(int agentno, string riskdatefrom, string riskdateto, 
                                                string duedatefrom, string duedateto, string policytype, string mcfpfrom, 
                                                    string mcfpto)
        {
            return _sql.get_policies(agentno, riskdatefrom, riskdateto, duedatefrom, duedateto, policytype, mcfpfrom, mcfpto);
        }

        public static int Save_Job_Requesting_data(string User, string submit_date, string estimated_date, string status, string Total_cost, DataTable newdatatable, string call_type, string job_type)
        {
            return _sql.Save_Job_Requesting_data(User, submit_date, estimated_date, status, Total_cost, newdatatable, call_type, job_type);
        }

        public static DataSet checkHoliday(string date)
        {
            return _sql.checkHoliday(date);
        }

        public static DataSet getall_Calling_types()
        {
            return _sql.get_all_calling_types();
        }

        public static DataSet getall_Letter_types()
        {
            return _sql.get_allLetterType();
        }
        public static DataSet get_serial_no(string callingtype)
        {
            return _sql.get_serial_no(callingtype);
        }

        public static DataSet get_call_cost(string calling_type)
        {
            return _sql.get_call_cost(calling_type);
        }

        public static DataSet get_recovery_amount(string description)
        {
            return _sql.get_recovery_amount(description);
        }

    

        public static DataSet get_call_agent()
        {
            return _sql.get_call_agents();
        }

        public static DataSet get_call_agent_id(string call_agent_name)
        {
            return _sql.get_call_agent_id(call_agent_name);
        }

        public static DataSet load_gridView_Admin_View()
        {
            return _sql.load_gridView_Admin_View();
        }

        public static DataSet load_GridView_CallAgent_View(string agent_no, string branch, string user)
        {
            return _sql.load_GridView_CallAgent_View(agent_no, branch,user);
        }

        public static DataSet load_GridView_CallAgent_ViewAll(string branch, string user)
        {
            return _sql.load_GridView_CallAgent_ViewAll(branch, user);
        }

        public static DataSet load_GridView_Recruitment_CallAgentView(string user)
        {
            return _sql.load_GridView_Recruitment_CallAgentView(user);
        }

        public static DataSet load_GridView_CallAgent_View_AccordingToPolicyNo(string user,string policy_no)
        {
            return _sql.load_GridView_CallAgent_View_AccordingToPolicyNo(user, policy_no);
        }

        public static DataSet loadGridView_PendingJobs()
        {
            return _sql.loadGridView_PendingJobs();
        }

        public static DataSet getSyscodeRemarks(string description)
        {
            return _sql.getSyscodeRemarks(description);
        }

        public static DataSet getRecruitmentSyscodeRemarks(string description)
        {
            return _sql.getRecruitmentSyscodeRemarks(description);
        }

        public static DataSet load_GridView_JobCompletion()
        {
            return _sql.load_GridView_JobCompletion();
        }

        public static DataSet loadDropdownBranch(string user)
        {
            return _sql.loadDropDownBranch(user);
        }

        public static int update_JobComplete(string job_no)
        {
            return _sql.update_JobComplete(job_no);
        }

        public static DataSet getCall_Type(string job_no)
        {
            return _sql.getCall_Type(job_no);
        }

        public static DataSet loadDropdownAgentNo(string branch,string user)
        {
            return _sql.loadDropdownAgentNo(branch,user);
        }

        public static DataSet loadFeedback()
        {
            return _sql.loadFeedback();
        }

        public static DataSet loadRecruitmentFeedback()
        {
            return _sql.loadRecruitmentFeedback();
        }

        public static int updateTransaction(string userId, string cust_feedback, string remarks, string Recovery_Status, string policy_no, string job_no, string serial_no, int call_time, string Status)
        {
            return _sql.updateTransaction(userId, cust_feedback, remarks, Recovery_Status, policy_no, job_no, serial_no, call_time, Status);
        }

        public static int updateCreateDate(string userId, string cust_feedback, string remarks, string policy_no, string job_no, string serial_no)
        {
            return _sql.updateCreateDate(userId, cust_feedback, remarks, policy_no, job_no, serial_no);
        }

        public static int updateJobTransaction(string allocated_user, string job_no, string branch_code, string allocate_date)
        {
            return _sql.updateJobTransaction(allocated_user, job_no, branch_code, allocate_date);
        }

        public static int updateJobMaster(string job_no)
        {
            return _sql.updateJobMaster(job_no);
        }

        public static int delete(string job_no, string so_code, string branch_code)
        {
            return _sql.delete(job_no, so_code, branch_code);
        }

        public static int RemoveUnwantedPolicyLog(string user_Id,string branch)
        {
            return _sql.RemoveUnwantedPolicyLog( user_Id, branch);
        }

        public static int update(string job_no)
        {
            return _sql.update(job_no);
        }

        public static int saveJobRequestPolicyLog(string emp_Id,string policy_no)
        {
            return _sql.saveJobRequestPolicyLog(emp_Id,policy_no);
        }

        public static int saveJobRequestRecruitmentLog(string emp_Id, string cus_name,string client_phone)
        {
            return _sql.saveJobRequestRecruitmentLog(emp_Id, cus_name, client_phone);
        }

        public static int removeJobRequestPolicyLog(string emp_Id)
        {
            return _sql.removeJobRequestPolicyLog(emp_Id);
        }

        public static int removeJobRequestRecruitmentLog(string emp_Id)
        {
            return _sql.removeJobRequestRecruitmentLog(emp_Id);
        }

        public static int removePhoneIsNullPolicyLog(string emp_Id)
        {
            return _sql.removePhoneIsNullPolicyLog(emp_Id);
        }

        public static DataSet getPolicyLog(string emp_Id)
        {
            return _sql.getPolicyLog(emp_Id);
        }

        public static DataSet getRecruitmentPolicyLog(string emp_Id)
        {
            return _sql.getRecruitmentPolicyLog(emp_Id);
        }

        public static DataSet getRecruitmentDetails(string emp_Id)
        {
            return _sql.getRecruitmentDetails(emp_Id);
        }

        public static DataSet loadGdvJobReallocation(string allocateUser_Id)
        {
            return _sql.loadGdvJobReallocation(allocateUser_Id);
        }

        public static DataSet loadDDL_Agent(string allocateUser_Id)
        {
            return _sql.loadDDL_Agent(allocateUser_Id);
        }

        public static DataSet getUserId(string user)
        {
            return _sql.getUserId(user);
        }

        public static DataSet getMissingRecords(string user,string branch)
        {
            return _sql.getMissingRecords(user, branch);
        }

        public static int updateTransactionAllocateUser(string job_no,string branch_code,string ReAllocatedUser)
        {
            return _sql.updateTransactionAllocateUser(job_no,branch_code,ReAllocatedUser);
        }

        public static DataSet loadGridView_DownloadData()
        {
            return _sql.loadGridView_DownloadData();
        }

        public static int updateDownloadStatus(string user,string job_no,string recovery_socode)
        {
            return _sql.updateDownloadStatus(user, job_no, recovery_socode);
        }

        public static int insertToUserChangeLog(string job_no,string branch_code,string existing_user,string new_user,string create_user,string create_ip)
        {
            return _sql.insertToUserChangeLog(job_no, branch_code, existing_user, new_user, create_user, create_ip);
        }

        public static DataSet getJobDetails(string jobString)
        {
            return _sql.getJobDetails(jobString);
        }

        public static DataSet getModelPopupPolicyDetails(string job_no,string serial_no,string policy_no)
        {
            return _sql.getModelPopupPolicyDetails(job_no, serial_no, policy_no);
        }

        public static DataSet getExtraPolicyDetails(string policy_no)
        {
            return _sql.getExtraPolicyDetails(policy_no);
        }

        public static DataSet loadJobCompletedBranch(string user)
        {
            return _sql.loadJobCompletedBranch(user);
        }

        public static DataSet loadGridView_Completed_jobs(string user,string branch)
        {
            return _sql.loadGridView_Completed_jobs(user, branch);
        }

        public static int saveWelcomeCallsPolicyLog(string emp_Id, string policy_no)
        {
            return _sql.saveWelcomeCallsPolicyLog(emp_Id, policy_no);
        }

        public static int removeWelcomeCallsPolicyLog(string emp_Id)
        {
            return _sql.removeWelcomeCallsPolicyLog(emp_Id);
        }

        public static DataSet getUploadedWelcomePolicyDetails(string emp_Id)
        {
            return _sql.getUploadedWelcomePolicyDetails(emp_Id);
        }

        public static DataSet getMissingWelcomeNumbers(string emp_Id)
        {
            return _sql.getMissingWelcomeNumbers(emp_Id);
        }
    }
}
