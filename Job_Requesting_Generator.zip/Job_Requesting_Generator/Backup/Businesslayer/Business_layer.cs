﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Businesslayer
{
    public class Business_layer
    {
    }
}
