﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Configuration;

namespace DataObjects
{
    public class ConnectionStringClass
    {
        public static readonly string _connectionString = ConfigurationSettings.AppSettings["LocalConnectionString"];
        public static readonly string _connectionStringOnly = ConfigurationSettings.AppSettings["DwhConnectionString"];
        public static readonly string _hrconnectionStringOnly = ConfigurationSettings.AppSettings["HrsConnectionString"];

        public static string LocalConnectionString
        {
            get { return _connectionString; }
        }

        public static string DwhConnectionString
        {
            get { return _connectionStringOnly; }
        }

        public static string HrConnectionString
        {
            get { return _hrconnectionStringOnly; }
        }


        public static string Dynamic_Connection(string _server, string _username, string _password, string _db)
        {
            return "Data Source=" + _server + ";Initial Catalog=" + _db + ";User ID=" + _username + "; password=" + _password;

        }
    }
}
