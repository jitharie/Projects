﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
using System.IO;

public partial class DownloadFile : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (!this.IsPostBack)
            {
                loadGridView_DownloadData();
            }
        }
        catch (Exception)
        {
            throw;
        }
    }

    public void loadGridView_DownloadData()
    {
        DataSet dsData = new DataSet();

        dsData = Facade.Servers.loadGridView_DownloadData();

        if(dsData.Tables[0].Rows.Count >0)
        {
            GridView_DownloadData.DataSource = dsData.Tables[0];
            GridView_DownloadData.DataBind();
        }
        else
        {
            btnDownload.Visible = false;
            ScriptManager.RegisterStartupScript(this, this.GetType(), "Message", " alert ('No records found!!') ;", true);
        }  
    }

    protected void btnDownload_Click(object sender, EventArgs e)
    {
        //GridView_DownloadData.DataSource = null;
        //GridView_DownloadData.DataBind();
        
        string strConnString = ConfigurationManager.ConnectionStrings["LocalConnStr"].ConnectionString;

        //using (SqlConnection con = new SqlConnection(strConnString))
        //{
        //    using (SqlCommand cmd = new SqlCommand("SELECT recovery_so_code,sum(recover_amount) as Total_recovery_amount FROM [JOB_REQUEST_TRANSACTION] where status='Completed' and recovery_status='YES' and download_status is null and job_no in (SELECT  [Job_No]  FROM [JOB_REQUEST_MASTER]  where status='Completed')group by recovery_so_code"))
        //    {
        //        using (SqlDataAdapter sda = new SqlDataAdapter())
        //        {
        //            cmd.Connection = con;
        //            sda.SelectCommand = cmd;
        //            using (DataTable dt = new DataTable())
        //            {
        //                sda.Fill(dt);

        //                //Build the Text file data.
        //                string txt = string.Empty;

        //                foreach (DataColumn column in dt.Columns)
        //                {
        //                    //Add the Header row for Text file.
        //                    txt += column.ColumnName + "\t\t";
        //                }

        //                //Add new line.
        //                txt += "\r\n";

        //                foreach (DataRow row in dt.Rows)
        //                {
        //                    foreach (DataColumn column in dt.Columns)
        //                    {
        //                        //Add the Data rows.
        //                        txt += row[column.ColumnName].ToString() + "\t\t";
        //                    }

        //                    //Add new line.
        //                    txt += "\r\n";
        //                }

        //                //Download the Text file.
        //                Response.Clear();
        //                Response.Buffer = true;
        //                Response.AddHeader("content-disposition", "attachment;filename=SqlExport.txt");
        //                Response.Charset = "";
        //                Response.ContentType = "application/text";
        //                Response.Output.Write(txt);
        //                Response.Flush();
        //                Response.End();
        //            }
        //        }
        //    }
        //}

        using (SqlConnection con = new SqlConnection(strConnString))
        {
            using (SqlCommand cmd = new SqlCommand("SELECT RIGHT(recovery_so_code, 6)as [Employee Number],null as [Employee Name],convert(numeric(18,2),sum(recover_amount)) as Amount FROM [JOB_REQUEST_TRANSACTION] where status='Completed' and recovery_status='YES' and download_status is null and job_no in (SELECT  [Job_No]  FROM [JOB_REQUEST_MASTER]  where status='Completed')group by recovery_so_code"))
            {
                using (SqlDataAdapter sda = new SqlDataAdapter())
                {
                    cmd.Connection = con;
                    sda.SelectCommand = cmd;
                    using (DataTable dt = new DataTable())
                    {
                        sda.Fill(dt);

                        //Create a dummy GridView
                        GridView GridView1 = new GridView();
                        GridView1.AllowPaging = false;
                        GridView1.DataSource = dt;
                        GridView1.DataBind();

                        Response.Clear();
                        Response.Buffer = true;
                        Response.AddHeader("content-disposition",
                         "attachment;filename=DataTable.xls");
                        Response.Charset = "";
                        Response.ContentType = "application/ms-excel";
                        StringWriter sw = new StringWriter();
                        HtmlTextWriter hw = new HtmlTextWriter(sw);

                        for (int i = 0; i < GridView1.Rows.Count; i++)
                        {
                            //Apply text style to each Row
                            GridView1.Rows[i].Attributes.Add("class", "textmode");
                        }
                        GridView1.RenderControl(hw);

                        //style to format numbers to string
                        string style = @"<style> .textmode { mso-number-format:\@; } </style>";
                        Response.Write(style);
                        Response.Output.Write(sw.ToString());
                        updateDownloadStatus();
                        
                        Response.Flush();
                        Response.End();
                    }
                }
            }
        }
    }

    public void updateDownloadStatus()
    {
        foreach (GridViewRow rw in GridView_DownloadData.Rows)
        {
            HiddenField hiddenField1 = (HiddenField)rw.FindControl("HiddenField1");
            string job_no = hiddenField1.Value.Trim();
            string recovery_socode = rw.Cells[1].Text.ToString();
            string user = Session["LoginId"].ToString();

            Facade.Servers.updateDownloadStatus(user, job_no, recovery_socode);
        }    
    }
}
