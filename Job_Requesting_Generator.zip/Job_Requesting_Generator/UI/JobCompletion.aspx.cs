﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class JobCompletion : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (!this.IsPostBack)
            {
                load_GridView_JobCompletion();
            }
        }
        catch (Exception)
        {
            throw;
        }
    }

    private void load_GridView_JobCompletion()
    {
        DataSet dsData = new DataSet();
        dsData = Facade.Servers.load_GridView_JobCompletion();

        GridView_JobCompletion.DataSource = dsData.Tables[0];
        GridView_JobCompletion.DataBind();
    }

    protected void LinkButtonUpdate_Click(object sender, EventArgs e)
    {
        LinkButton btndetails = (LinkButton)sender;
        GridViewRow gvrow = (GridViewRow)btndetails.NamingContainer;

        string job_no = gvrow.Cells[0].Text.ToString();
        Session["job_no"] = job_no;

        DataSet dsData = Facade.Servers.getCall_Type(job_no);
        string call_type = dsData.Tables[0].Rows[0]["call_type"].ToString();

        int i = Facade.Servers.update_JobComplete(job_no);

        if(i == 1)
        {
            if (call_type != "RECRUITMENT CALLINGS")
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(), "Message", " alert ('Successfully Updated!!');", true);
                load_GridView_JobCompletion();
                send_Mail();
            }
            else
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(), "Message", " alert ('Successfully Updated!!');", true);
                load_GridView_JobCompletion();
            }        
        }
        else
        {
            ScriptManager.RegisterStartupScript(this, this.GetType(), "Message", " alert ('Error!!') ;", true);
        }
    }

    protected void send_Mail()
    {
        DataSet dsMail = new DataSet();
        DataSet dsData = new DataSet();

        string job_no = Session["job_no"].ToString();

        //dsData = Facade.Servers.getMailAttachment(job_no);
        //string Recovery_soCode = dsData.Tables[0].Rows[0]["Recovery_SO_CODE"].ToString();
        //string Recovery_amount = dsData.Tables[0].Rows[0]["Recovery_amount"].ToString();

        //string msg = "testing";
        //string EmailAddress = "systemt@sys.ceylife.lk";
        //string subject = "Job Completed";
        dsMail = Facade.Servers.sendMailAttachments(job_no);
    }
}
