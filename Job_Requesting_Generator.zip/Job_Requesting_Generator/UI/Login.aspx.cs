﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.IO;
using System.Data;
using Facade;
using DataObjects;

public partial class Login : System.Web.UI.Page
{
    
    String Userid;
    String Pwd;
    DataSet dsUser;
    
    protected void Page_Load(object sender, EventArgs e)
    {       
        lblDate.Text = DateTime.Now.ToLongDateString();      
    }
    protected void btnlogin_Click(object sender, EventArgs e)
    {
        try
        {    
            Userid = txtUserName.Text.ToString().Trim();
            Session["LoginId"] = Userid;
            Pwd = txtPassword.Text.ToString().Trim();
            Validate_user(Userid, Pwd);
        }
        catch (Exception)
        {
            throw;
        }
    }

    private void Validate_user(string Userid, string Pwd)
    {
        try
        {
            dsUser = Facade.Servers.get_Userdetails(Userid, Pwd);
            if (dsUser.Tables[0].Rows.Count > 0)
            {
                string Usertype = dsUser.Tables[0].Rows[0]["USERTYPE"].ToString();
                string UserBranch = dsUser.Tables[0].Rows[0]["BRANCH"].ToString();
                string UserStatus = dsUser.Tables[0].Rows[0]["STATUS"].ToString();
                string UserName = dsUser.Tables[0].Rows[0]["NAME"].ToString();

                if (Usertype == "HOB")
                {
                    Session["EMPID"] = Userid;
                    Session["UserName"] = UserName;
                    Session["branchCode"] = UserBranch;
                    Session["UserType"] = Usertype;
                    Session["status"] = UserStatus;
                    Session["UserStatus"] = "Valid";
                    Session["isRestrict"] = "YES";

                    Response.Redirect("~/RequestForm.aspx", false);
                    
                    return;
                }
                else if ((UserBranch == "HO01") )//&& (Usertype == "USER")
                {
                    Session["EMPID"] = Userid;
                    Session["UserName"] = UserName;
                    Session["branchCode"] = UserBranch;
                    Session["UserType"] = Usertype;
                    Session["status"] = UserStatus;
                    Session["UserStatus"] = "Valid";
                    Session["isRestrict"] = "YES";

                    Response.Redirect("~/AdminRequestForm.aspx", false);

                    return;
                }
                else
                {
                    lblMsg.Text = "You do not have permission!";
                    return;
                }
            }
            else
            {
                lblMsg.Text = "Invalid User Id or Password,Please try again!";
                return;
            }
        }
        catch (Exception)
        {
            throw;
        }
    }
}
