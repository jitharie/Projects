﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Configuration;
using System.Data.SqlClient;
using System.IO;

public partial class _Default : System.Web.UI.Page
{
    DataSet dsData = new DataSet();
    int i;
    int j;

    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (!this.IsPostBack)
            { 
                load_gridView_Admin_View();
            }
        }
        catch (Exception)
        {
            throw;
        }
    }

    private void loadCallAgent()
    {
        DataSet dsCallAgents = Facade.Servers.get_call_agent();
        DDL_Agent.DataSource = dsCallAgents.Tables[0];
        DDL_Agent.DataTextField = "DESCRIPTION";
        DDL_Agent.DataValueField = "DESCRIPTION";
        DDL_Agent.DataBind();
        DDL_Agent.Items.Insert(0, "--SELECT--");
    }

    private void load_gridView_Admin_View()
    {
        dsData = Facade.Servers.load_gridView_Admin_View();

        if(dsData.Tables[0].Rows.Count > 0)
        {
            loadCallAgent();
            GridView_Admin_View.DataSource = dsData.Tables[0];
            GridView_Admin_View.DataBind();
        }
        else
        {
            Label3.Visible = false;
            DDL_Agent.Visible = false;
            btnAllocate.Visible = false;
            ScriptManager.RegisterStartupScript(this, this.GetType(), "Message", " alert ('No records found!!') ;", true);
        }
    }

    protected void btnAllocate_Click(object sender, EventArgs e)
    {
        try
        {
            string job_no = null;
            string call_type = null;

            foreach (GridViewRow rw in GridView_Admin_View.Rows)
            {
                CheckBox chkbx = (CheckBox)rw.FindControl("chkStatus");
                if (((CheckBox)rw.FindControl("chkStatus")).Checked)
                {
                    job_no = rw.Cells[1].Text.ToString();
                    call_type = rw.Cells[4].Text.ToString();
                    string branch_code = rw.Cells[2].Text.ToString();
                    //string so_code = rw.Cells[3].Text.ToString();
                    string call_agent_name = DDL_Agent.SelectedItem.Text.ToString();
                    dsData =  Facade.Servers.get_call_agent_id(call_agent_name);
                    string call_agent_id = dsData.Tables[0].Rows[0]["CODE"].ToString();
                    string allocate_date = DateTime.Now.Date.ToString("yyyy-MM-dd");

                    i = Facade.Servers.updateJobTransaction(call_agent_id, job_no, branch_code, allocate_date);
                    j = Facade.Servers.updateJobMaster(job_no);
                }
            }

            string JobString = "";
            foreach (GridViewRow rw in GridView_Admin_View.Rows)
            {
                CheckBox chkbx = (CheckBox)rw.FindControl("chkStatus");
                if (((CheckBox)rw.FindControl("chkStatus")).Checked)
                {
                    JobString += "'" + rw.Cells[1].Text.ToString() + "',";
                }             
            }
            
            JobString= JobString.TrimEnd(',');

            if (call_type == "RECRUITMENT CALLINGS")
            {
                DataSet dsData = new DataSet();
                dsData = Facade.Servers.getRecruitmentPolicyLog(JobString);

                if (dsData.Tables[0].Rows.Count > 0)
                {
                    DataTable dtnew = dsData.Tables[0];

                    //Build the Text file data.
                    string txt = string.Empty;

                    //foreach (DataColumn column in dt.Columns)
                    //{
                    //    //Add the Header row for Text file.
                    //    txt += column.ColumnName + "\t\t";
                    //}

                    //Add new line.
                    //txt += "\r\n";

                    foreach (DataRow row in dtnew.Rows)
                    {
                        foreach (DataColumn column in dtnew.Columns)
                        {
                            //Add the Data rows.
                            txt += row[column.ColumnName].ToString() + "\t\t";
                        }

                        //Add new line.
                        txt += "\r\n";
                    }

                    //Download the Text file.
                    Response.Clear();
                    Response.Buffer = true;
                    Response.AddHeader("content-disposition", "attachment;filename=SqlExport.txt");
                    Response.Charset = "";
                    Response.ContentType = "application/text";
                    Response.Output.Write(txt);

                    Response.Flush();
                    Response.End();
                }
                else
                {
                    ScriptManager.RegisterStartupScript(this, this.GetType(), "Message", " alert ('No records found!!');", true);
                }
            }
            else
            {
                DataSet dsJobDetails = new DataSet();
                dsJobDetails = Facade.Servers.getJobDetails(JobString);

                if (dsJobDetails.Tables[0].Rows.Count > 0)
                {
                    DataTable dt = dsJobDetails.Tables[0];

                    //Build the Text file data.
                    string txt = string.Empty;

                    //foreach (DataColumn column in dt.Columns)
                    //{
                    //    //Add the Header row for Text file.
                    //    txt += column.ColumnName + "\t\t";
                    //}

                    //Add new line.
                    //txt += "\r\n";

                    foreach (DataRow row in dt.Rows)
                    {
                        foreach (DataColumn column in dt.Columns)
                        {
                            //Add the Data rows.
                            txt += row[column.ColumnName].ToString() + "\t\t";
                        }

                        //Add new line.
                        txt += "\r\n";
                    }

                    //Download the Text file.
                    Response.Clear();
                    Response.Buffer = true;
                    Response.AddHeader("content-disposition", "attachment;filename=SqlExport.txt");
                    Response.Charset = "";
                    Response.ContentType = "application/text";
                    Response.Output.Write(txt);

                    Response.Flush();
                    Response.End();
                }
                else
                {
                    ScriptManager.RegisterStartupScript(this, this.GetType(), "Message", " alert ('No records found!!');", true);
                }
            }
             
            if ((i == 1) && (j == 1))
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(), "Message", " alert ('Successfully Updated!!');", true);
                load_gridView_Admin_View();
            }
            else
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(), "Message", " alert ('Error!!') ;", true);
                return;
            }    
        }
        catch(Exception)
        {
            throw;
        }
    }

    protected void exportToText()
    {
        string constr = ConfigurationManager.ConnectionStrings["LocalConnStr"].ConnectionString;
        using (SqlConnection con = new SqlConnection(constr))
        {
            using (SqlCommand cmd = new SqlCommand("SELECT * FROM Customers"))
            {
                using (SqlDataAdapter sda = new SqlDataAdapter())
                {
                    cmd.Connection = con;
                    sda.SelectCommand = cmd;
                    using (DataTable dt = new DataTable())
                    {
                        sda.Fill(dt);

                        //Build the Text file data.
                        string txt = string.Empty;

                        foreach (DataColumn column in dt.Columns)
                        {
                            //Add the Header row for Text file.
                            txt += column.ColumnName + "\t\t";
                        }

                        //Add new line.
                        txt += "\r\n";

                        foreach (DataRow row in dt.Rows)
                        {
                            foreach (DataColumn column in dt.Columns)
                            {
                                //Add the Data rows.
                                txt += row[column.ColumnName].ToString() + "\t\t";
                            }

                            //Add new line.
                            txt += "\r\n";
                        }

                        //Download the Text file.
                        Response.Clear();
                        Response.Buffer = true;
                        Response.AddHeader("content-disposition", "attachment;filename=SqlExport.txt");
                        Response.Charset = "";
                        Response.ContentType = "application/text";
                        Response.Output.Write(txt);
                        Response.Flush();
                        Response.End();
                    }
                }
            }
        }
    }

    protected void LinkButtonCancel_Click(object sender, EventArgs e)
    {
        try
        {
            LinkButton btndetails = (LinkButton)sender;
            GridViewRow gvrow = (GridViewRow)btndetails.NamingContainer;
            LinkButton l = new LinkButton();
            l = (LinkButton)gvrow.FindControl("LinkButtonCancel");

            string job_no = gvrow.Cells[1].Text.ToString();
            Session["job_no"] = job_no;
            string branch_code = gvrow.Cells[2].Text.ToString();
            string so_code = gvrow.Cells[3].Text.ToString();

            Facade.Servers.update(job_no);
            Facade.Servers.delete(job_no, so_code, branch_code);                
            
            ScriptManager.RegisterStartupScript(this, this.GetType(), "Message", " alert ('Done!!');", true);
        }
        catch(Exception)
        {
            throw;
        }
    }
    protected void GridView_Admin_View_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
    {
        load_gridView_Admin_View();
    }

}
