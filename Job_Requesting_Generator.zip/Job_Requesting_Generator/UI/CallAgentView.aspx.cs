﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Windows.Forms;
using System.Web.Services;

public partial class CallAgentView : System.Web.UI.Page
{
    DataSet dsData = new DataSet();

    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (!this.IsPostBack)
            {
                loadDropdownBranch();
            }
        }
        catch (Exception)
        {
            throw;
        }
    }

    private void load_GridView_CallAgent_View()
    {
        string user = Session["LoginId"].ToString();
        string agent_no = ddlAgentNo.SelectedItem.Text.ToString();
        string branch = Session["Branch_Code"].ToString();

        if(agent_no == "--All--")
        {
            dsData = Facade.Servers.load_GridView_CallAgent_ViewAll(branch, user);

            GridView_CallAgent_View.DataSource = dsData.Tables[0];
            GridView_CallAgent_View.DataBind();
        }
        else
        {
            dsData = Facade.Servers.load_GridView_CallAgent_View(agent_no, branch, user);

            GridView_CallAgent_View.DataSource = dsData.Tables[0];
            GridView_CallAgent_View.DataBind();
        }      
    }

    private void loadFeedback()
    {
        dsData = Facade.Servers.loadFeedback();

        ddlCustFeedback.DataSource = dsData.Tables[0];
        ddlCustFeedback.DataValueField = "DESCRIPTION";
        ddlCustFeedback.DataTextField = "DESCRIPTION";
        ddlCustFeedback.DataBind();
        ddlCustFeedback.Items.Insert(0, "--Select--");
    }

    public void loadDropdownBranch()
    {
        string user = Session["LoginId"].ToString();

        dsData = Facade.Servers.loadDropdownBranch(user);

        if (dsData.Tables[0].Rows.Count > 0)
        {
            lblMessage.Text = "";
            ddlBranch.DataSource = dsData.Tables[0];
            ddlBranch.DataValueField = "Branch_Code";
            ddlBranch.DataTextField = "Branch_Code";
            ddlBranch.DataBind();
            ddlBranch.Items.Insert(0, "--Select--");
        }
        else
        {
            lblMessage.Text = "No records found!!";
        }
    }

    protected void LinkButtonCustomer_Name_Click(object sender, EventArgs e)
    {
        try
        {
            LinkButton btndetails = (LinkButton)sender;
            GridViewRow gvrow = (GridViewRow)btndetails.NamingContainer;
            LinkButton l = new LinkButton();
            l = (LinkButton)gvrow.FindControl("linkCustomer_Name");
            string customer_name = l.CommandArgument;
            Session["Customer_name"] = customer_name.Trim();

            string policy_no = gvrow.Cells[3].Text.ToString();
            Session["policy_no"] = policy_no;
            //string client_no = gvrow.Cells[1].Text.ToString();
            //Session["client_no"] = client_no;

            HiddenField hiddenField1 = (HiddenField)gvrow.FindControl("HiddenField1");
            string job_no = hiddenField1.Value.Trim();
            Session["job_no"] = job_no;

            HiddenField hiddenField2 = (HiddenField)gvrow.FindControl("HiddenField2");
            string serial_no = hiddenField2.Value.Trim();
            Session["serial_no"] = serial_no;

            DataSet dsData = Facade.Servers.getModelPopupPolicyDetails(job_no, serial_no, policy_no);
            DataSet dsExraData = Facade.Servers.getExtraPolicyDetails(policy_no);

            lblPolicyNo.Text = policy_no;
            lblCusName.Text = Session["Customer_name"].ToString();
            lblDueDate.Text = dsExraData.Tables[0].Rows[0]["PTDATE"].ToString();
            lblRiskDate.Text = dsData.Tables[0].Rows[0]["Risk_Date"].ToString();
            lblPremium.Text = dsData.Tables[0].Rows[0]["Premium"].ToString();
            //lblMode.Text = dsData.Tables[0].Rows[0]["Mode"].ToString();
            lblPolicyType.Text = dsData.Tables[0].Rows[0]["Policy_Type"].ToString();
            lblPhoneNumber.Text = dsData.Tables[0].Rows[0]["Client_Phone"].ToString();
            lblAddress.Text = dsExraData.Tables[0].Rows[0]["ADDRESS"].ToString();
            lblLanguage.Text = dsExraData.Tables[0].Rows[0]["lang"].ToString();
            lblDOB.Text = dsExraData.Tables[0].Rows[0]["CLTDOB"].ToString();
            lblNIC.Text = dsExraData.Tables[0].Rows[0]["SECUITYNO"].ToString();
            lblAgentNo.Text = dsExraData.Tables[0].Rows[0]["AGNTNUM"].ToString();
            lblAgentName.Text = dsExraData.Tables[0].Rows[0]["CLTADDR01"].ToString();
            lblBranch.Text = dsExraData.Tables[0].Rows[0]["REGISTER"].ToString();
            lblSundryBalance.Text = dsExraData.Tables[0].Rows[0]["BALANCE"].ToString();
            lblMode.Text = dsExraData.Tables[0].Rows[0]["BILLFREQ"].ToString();
            lblPlanNo.Text = dsExraData.Tables[0].Rows[0]["CNTTYPE"].ToString();

            this.ModalPopupExtender1.Show();
            loadFeedback();
        }
        catch (Exception)
        {
            throw;
        }
    }

    protected void btnClose_Click(object sender, EventArgs e)
    {
        ModalPopupExtender1.Hide();
    }
    
    protected void btnSave_Click(object sender, EventArgs e)
    {
        if (ddlCustFeedback.SelectedItem.Text != "--Select--")
        {
            string custFeedback = ddlCustFeedback.SelectedItem.Text.ToString();
            string remarks = txtRemarks.Text.ToString();

            string userId = Session["LoginId"].ToString();
            string policy_no =  Session["policy_no"].ToString();
            //string client_no = Session["client_no"].ToString();
            string cust_name = Session["Customer_name"].ToString();
            string job_no = Session["job_no"].ToString();
            string serial_no = Session["serial_no"].ToString();
            string Status = null;

            DataSet dsCall_Time = new DataSet();
            dsCall_Time = Facade.Servers.getCall_time(job_no, serial_no, policy_no);
            string noOfCallTimes = dsCall_Time.Tables[0].Rows[0]["Call_Time"].ToString();

            int call_time = int.Parse(noOfCallTimes) + 1;

            dsData = Facade.Servers.getSyscodeRemarks(custFeedback.Trim());
            
            string Recovery_Status = dsData.Tables[0].Rows[0]["REMARKS"].ToString();
            //if (Recovery_Status == "YES")
            //{
                Status = "Completed";
            //}
            //else if (Recovery_Status == "NO")
            //{
            //    Status = "Pending";
            //}

            int i = Facade.Servers.updateTransaction(userId, custFeedback, remarks, Recovery_Status, policy_no, job_no, serial_no, call_time, Status);

            if (i == 1)
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(), "Message", " alert ('Successfully Saved!!');", true);
                ModalPopupExtender1.Hide();
                txtRemarks.Text = "";
                //load_GridView_CallAgent_View();
                GridView_CallAgent_View.DataSource = null;
                GridView_CallAgent_View.DataBind();
            }
            else
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(), "Message", " alert ('Error!!') ;", true);
            }
            

            //else if (dsData.Tables[0].Rows[0]["REMARKS"].ToString() == "NO")
            //{
            //    ScriptManager.RegisterStartupScript(this,GetType(),"key","confirm('Are you sure you want to delete?');",true);
                
                
                //ScriptManager.RegisterStartupScript(this, GetType(), "Confirm", "Confirm();", true);

                //string confirmValue = Request.Form["confirm_value"];
                //if (confirmValue == "Yes")
                //{
                //    int i = Facade.Servers.updateCreateDate(userId, custFeedback, remarks, policy_no, job_no, serial_no);

                //    if (i == 1)
                //    {
                //        ScriptManager.RegisterStartupScript(this, this.GetType(), "Message", " alert ('Successfully Saved!!');", true);
                //        ModalPopupExtender1.Hide();
                //        load_GridView_CallAgent_View();
                //    }
                //    else
                //    {
                //        ScriptManager.RegisterStartupScript(this, this.GetType(), "Message", " alert ('Error!!') ;", true);
                //    }
                //}
                //else
                //{
                //    string Recovery_Status = dsData.Tables[0].Rows[0]["REMARKS"].ToString();
                //    int i = Facade.Servers.updateTransaction(userId, custFeedback, remarks, Recovery_Status, policy_no, job_no, serial_no);

                //    if (i == 1)
                //    {
                //        ScriptManager.RegisterStartupScript(this, this.GetType(), "Message", " alert ('Successfully Saved!!');", true);
                //        ModalPopupExtender1.Hide();
                //        load_GridView_CallAgent_View();
                //    }
                //    else
                //    {
                //        ScriptManager.RegisterStartupScript(this, this.GetType(), "Message", " alert ('Error!!') ;", true);
                //    }
                //}



                //DialogResult result = MessageBox.Show("Do you want to retry?", "Confirmation", MessageBoxButtons.YesNoCancel);
                //if (result == DialogResult.Yes)
                //{

                //}
                //else if (result == DialogResult.No)
                //{

                //}
            //}    
        }
        else
        {
            ScriptManager.RegisterStartupScript(this, this.GetType(), "Message", " alert ('Please select a feedback!!') ;", true);
        }
    }


    [WebMethod]
    public static void ConfirmVal()
    {
        
    }

    protected void ddlBranch_SelectedIndexChanged(object sender, EventArgs e)
    {
        GridView_CallAgent_View.DataSource = null;
        GridView_CallAgent_View.DataBind();
        loadDropdownAgentNo();
    }

    public void loadDropdownAgentNo()
    {
        string user = Session["LoginId"].ToString();
        string branch = ddlBranch.SelectedItem.Text.ToString();
        Session["Branch_Code"] = branch;

        dsData = Facade.Servers.loadDropdownAgentNo(branch,user);

        if (dsData.Tables[0].Rows.Count > 0)
        {
            ddlAgentNo.DataSource = dsData.Tables[0];
            ddlAgentNo.DataValueField = "SO_CODE";
            ddlAgentNo.DataTextField = "SO_CODE";
            ddlAgentNo.DataBind();
            //ddlAgentNo.Items.Insert(0, "--Select--");
            ddlAgentNo.Items.Insert(0, "--All--");
        }
        else
        {
            ScriptManager.RegisterStartupScript(this, this.GetType(), "Message", " alert ('No records found!!') ;", true);
        }      
    }

    protected void btnCancel_Click(object sender, EventArgs e)
    {
        ModalPopupExtender1.Hide();
    }

    protected void btnSearch_Click(object sender, EventArgs e)
    { 
        string user = Session["LoginId"].ToString();
        string policy_no = txtPolicy_No.Text.ToString();

        dsData = Facade.Servers.load_GridView_CallAgent_View_AccordingToPolicyNo(user, policy_no);

        if (dsData.Tables[0].Rows.Count > 0)
        {
            GridView_CallAgent_View.DataSource = dsData.Tables[0];
            GridView_CallAgent_View.DataBind();
        }
        else
        {
            ScriptManager.RegisterStartupScript(this, this.GetType(), "Message", " alert ('No records found!!') ;", true);
        }        
    }

    protected void btnSearch1_Click(object sender, EventArgs e)
    {
        load_GridView_CallAgent_View();
    }

    protected void btnRefresh_Click(object sender, EventArgs e)
    {
        loadDropdownBranch();
        txtPolicy_No.Text = "";
        ddlAgentNo.Items.Clear();
        GridView_CallAgent_View.DataSource = null;
        GridView_CallAgent_View.DataBind();
    }
}
