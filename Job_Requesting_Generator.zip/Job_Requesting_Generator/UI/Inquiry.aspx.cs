﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Configuration;
using System.Data.SqlClient;
using DataObjects.SqlServers;

public partial class Inquiry : System.Web.UI.Page
{
    Sql_Servers server = new Sql_Servers();
    DataSet dsbranchDetails = new DataSet();
    
    
    
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack) {
            btn_AddLetter.Enabled = true;
        }

        
    }


    protected void btnsearch_Click(object sender, EventArgs e)
    {

        DataSet dsinquiryDetails = new DataSet();
        dsinquiryDetails = server.get_inquiaryDetails(txtbranch.Text);

        if (dsinquiryDetails.Tables[0].Rows.Count > 0)
        {
            if(txtbranch.Text == "")
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(), "Message", " alert ('Enter the Branch Number!!') ;", true);
            }

            else
            {
                dgvviewdetails.DataSource = dsinquiryDetails.Tables[0];
                dgvviewdetails.DataBind();
                lblLetterType.Visible = false;
                cmb_LetterType.Visible = false;
                chk_viewLetter.Visible = false;
                chk_viewLetter.Checked = false;
                dgv_jobDetails.Visible = false;
                btn_AddLetter.Visible = false;
            }
           
        }
        else
        {
            ScriptManager.RegisterStartupScript(this, this.GetType(), "Message", " alert ('No records found!!') ;", true);
        }

       
    }

    protected void View_Click(object sender, EventArgs e)
    {
       
        LinkButton btndetails = (LinkButton)sender;
        GridViewRow gvrow = (GridViewRow)btndetails.NamingContainer;

        string Branch_no = gvrow.Cells[0].Text.ToString();

        for (int runs = 0; runs < 1; runs++)
        {
            Label1.Text = Branch_no;
        }

        dsbranchDetails = server.get_JobDetails(Branch_no);
        chk_viewLetter.Visible = true;
        dgv_jobDetails.Visible = true;

        if (dsbranchDetails .Tables[0].Rows.Count > 0)
        {
            if(chk_viewLetter.Checked)
            {
                dsbranchDetails = server.get_viewLetter(Branch_no);
                dgv_jobDetails.DataSource = dsbranchDetails.Tables[0];
                dgv_jobDetails.DataBind();
               
            }

            else
            {
                dgv_jobDetails.DataSource = dsbranchDetails.Tables[0];
                dgv_jobDetails.DataBind();
            }
           
        }
        else
        {
            ScriptManager.RegisterStartupScript(this, this.GetType(), "Message", " alert ('No records found!!') ;", true);
        }
    }

    

    protected void chk_viewLetter_CheckedChanged(object sender, EventArgs e)
    {

        string value = Label1.Text;
        dsbranchDetails = server.get_JobDetails(value);
        
        getLetterType();


        if (chk_viewLetter.Checked)
        {
            

            if (dsbranchDetails.Tables[0].Rows.Count > 0)
            {

                dsbranchDetails = server.get_viewLetter(value);
                dgv_jobDetails.DataSource = dsbranchDetails.Tables[0];
                dgv_jobDetails.DataBind();
                cmb_LetterType.Visible = true;
                btn_AddLetter.Visible = true;
                lblLetterType.Visible = true;
            }

            
        }
        else
        {
            dsbranchDetails = server.get_JobDetails(value);
            dgv_jobDetails.DataSource = dsbranchDetails.Tables[0];
            dgv_jobDetails.DataBind();
            cmb_LetterType.Visible = false;
            btn_AddLetter.Visible = false;
            lblLetterType.Visible = false;
        }



    }




    protected void getLetterType()
    {
        cmb_LetterType.Items.Clear();

        DataSet dsgetLettertype = Facade.Servers.getall_Letter_types();
        cmb_LetterType.Items.Insert(0, "--SELECT--");
        for (int i=0;i<dsgetLettertype.Tables[0].Rows.Count;i++)
        {
            cmb_LetterType.Items.Insert(i+1, new ListItem(dsgetLettertype.Tables[0].Rows[i][0].ToString(), (i+1)+"."+dsgetLettertype.Tables[0].Rows[i][1].ToString()));
        }
      
    }

 
protected void btn_AddLetter_Click(object sender, EventArgs e)
    {
        try
        {
            string emp_Id = Session["LoginId"].ToString();
            string letter_Type = cmb_LetterType.SelectedItem.Text;
            /*-----------------Save Letter To Master table--------------------------*/

            string User = emp_Id;
            DateTime date = DateTime.Now;
            string submit_date = Convert.ToDateTime(date.AddDays(0)).ToString("yyyy-MM-dd HH:mm:ss");
            string estimated_date = Convert.ToDateTime(date.AddDays(0)).ToString("yyyy-MM-dd HH:mm:ss");
            string status = "Completed";
            string allocated_date = Convert.ToDateTime(date.AddDays(0)).ToString("yyyy-MM-dd HH:mm:ss");
            string complete_date = Convert.ToDateTime(date.AddDays(0)).ToString("yyyy-MM-dd HH:mm:ss");


            int grid_count = dgv_jobDetails.Rows.Count;
            if (cmb_LetterType.SelectedIndex == 0)
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(), "Message", " alert ('Select Letter Type') ;", true);

            }

            else
            {
                string val = cmb_LetterType.SelectedValue;
                string[] values = val.Split('.');
                
                Decimal amount = Convert.ToDecimal(values[1]);
                double total = Convert.ToDouble(amount) * grid_count;
                server.insertToLetterToMaster(User, submit_date, estimated_date, total, status, allocated_date, complete_date, total);

                //***---------------------Insert Letter to tansaction and customerList--------------------------***
                int res = 0;
                int res1 = 0;
                int job_no = Convert.ToInt32(Label1.Text);
                
                res = server.sp_insertLetterToTransaction(job_no, amount, letter_Type);
                res1 = server.sp_insertLetterTocustomerlist(job_no);

                if (res > 0 && res1 > 0)
                {
                    ScriptManager.RegisterStartupScript(this, this.GetType(), "Message", " alert ('Saved Successfully') ;", true);
                    btn_AddLetter.Enabled = false;
                    getLetterType();

                }
                else
                {
                    getLetterType();
                    ScriptManager.RegisterStartupScript(this, this.GetType(), "Message", " alert ('Not Saved') ;", true);

                }

            }

        }

        catch (Exception)
        {
            ScriptManager.RegisterStartupScript(this, this.GetType(), "Message", " alert ('No Record found') ;", true);
        }
    }

}