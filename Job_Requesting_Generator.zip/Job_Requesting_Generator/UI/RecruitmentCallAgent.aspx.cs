﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class RecruitmentCallAgent : System.Web.UI.Page
{
    DataSet dsData = new DataSet();

    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (!this.IsPostBack)
            {
                load_GridView_Recruitment_CallAgent_View();
            }
        }
        catch (Exception)
        {
            throw;
        }
    }

    private void load_GridView_Recruitment_CallAgent_View()
    { 
        string user = Session["LoginId"].ToString();
        DataSet dsData = new DataSet();

        dsData = Facade.Servers.load_GridView_Recruitment_CallAgentView(user);

        if (dsData.Tables[0].Rows.Count > 0)
        {
            GridView_Recruitment_CallAgent_View.DataSource = dsData.Tables[0];
            GridView_Recruitment_CallAgent_View.DataBind();
        }
        else
        {
            //ScriptManager.RegisterStartupScript(this, this.GetType(), "Message", "alert ('No records found!!');", true);
            lblMessage.Text = "No records found!!";
        }
    }

    protected void LinkButtonCustomer_Name_Click(object sender, EventArgs e)
    {
        try
        {
            LinkButton btndetails = (LinkButton)sender;
            GridViewRow gvrow = (GridViewRow)btndetails.NamingContainer;
            LinkButton l = new LinkButton();
            l = (LinkButton)gvrow.FindControl("linkCustomer_Name");
            string customer_name = l.CommandArgument;
            Session["Customer_name"] = customer_name.Trim();

            HiddenField hiddenField1 = (HiddenField)gvrow.FindControl("HiddenField1");
            string job_no = hiddenField1.Value.Trim();
            Session["job_no"] = job_no;

            HiddenField hiddenField2 = (HiddenField)gvrow.FindControl("HiddenField2");
            string serial_no = hiddenField2.Value.Trim();
            Session["serial_no"] = serial_no;

            string client_phone = gvrow.Cells[3].Text.ToString();
            string branch_code = gvrow.Cells[1].Text.ToString();

            this.ModalPopupExtender1.Show();
            loadRecruitmentFeedback();
            lblCusName.Text = customer_name;
            lblPhoneNumber.Text = client_phone;
            //lblBranch.Text = branch_code;
        }
        catch(Exception)
        {
            throw;
        }
    }

    protected void btnClose_Click(object sender, EventArgs e)
    {
        ModalPopupExtender1.Hide();
    }

    private void loadRecruitmentFeedback()
    {
        dsData = Facade.Servers.loadRecruitmentFeedback();

        ddlCustFeedback.DataSource = dsData.Tables[0];
        ddlCustFeedback.DataValueField = "DESCRIPTION";
        ddlCustFeedback.DataTextField = "DESCRIPTION";
        ddlCustFeedback.DataBind();
        ddlCustFeedback.Items.Insert(0, "--Select--");
    }

    protected void btnSave_Click(object sender, EventArgs e)
    {
        if (ddlCustFeedback.SelectedItem.Text != "--Select--")
        {
            string custFeedback = ddlCustFeedback.SelectedItem.Text.ToString();
            string remarks = txtRemarks.Text.ToString();
            string userId = Session["LoginId"].ToString();
            string policy_no = "";
            string cust_name = Session["Customer_name"].ToString();
            string job_no = Session["job_no"].ToString();
            string serial_no = Session["serial_no"].ToString();
            string Status = null;

            DataSet dsCall_Time = new DataSet();
            dsCall_Time = Facade.Servers.getRecruitment_Call_time(job_no, serial_no);
            string noOfCallTimes = dsCall_Time.Tables[0].Rows[0]["Call_Time"].ToString();

            int call_time = int.Parse(noOfCallTimes) + 1;

            dsData = Facade.Servers.getRecruitmentSyscodeRemarks(custFeedback.Trim());
            
            string Recovery_Status = dsData.Tables[0].Rows[0]["REMARKS"].ToString();
            //if (Recovery_Status == "YES")
            //{
                Status = "Completed";
            //}
            //else if (Recovery_Status == "NO")
            //{
            //    Status = "Pending";
            //}

            int i = Facade.Servers.updateTransaction(userId, custFeedback, remarks, Recovery_Status, policy_no, job_no, serial_no, call_time, Status);

            if (i == 1)
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(), "Message", " alert ('Successfully Saved!!');", true);
                ModalPopupExtender1.Hide();
                txtRemarks.Text = "";
                //load_GridView_CallAgent_View();
                GridView_Recruitment_CallAgent_View.DataSource = null;
                GridView_Recruitment_CallAgent_View.DataBind();
            }
            else
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(), "Message", " alert ('Error!!') ;", true);
            }
        }
        else
        {
            ScriptManager.RegisterStartupScript(this, this.GetType(), "Message", " alert ('Please select a feedback!!') ;", true);
        }
    }
}
