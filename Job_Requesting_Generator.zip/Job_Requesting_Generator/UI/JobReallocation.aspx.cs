﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class JobReallocation : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (!this.IsPostBack)
            {
                loadGdvReallocation();
            }
        }
        catch (Exception)
        {
            throw;
        }       
    }

    public void loadGdvReallocation()
    {
        DataSet dsData = new DataSet();
        string allocateUser_Id = Session["allocateUser_Id"].ToString();
        dsData = Facade.Servers.loadGdvJobReallocation(allocateUser_Id);

        if (dsData.Tables[0].Rows.Count > 0)
        {
            GridView_JobReallocation.DataSource = dsData.Tables[0];
            GridView_JobReallocation.DataBind();

            loadDDL_Agent();
        }
        else
        {
            ScriptManager.RegisterStartupScript(this, this.GetType(), "Message", " alert ('No records found!!');", true);
        }       
    }

    public void loadDDL_Agent()
    {
        string allocateUser_Id = Session["allocateUser_Id"].ToString();

        DataSet dsData = new DataSet();
        dsData = Facade.Servers.loadDDL_Agent(allocateUser_Id);

        ddl_Call_Agent.DataSource = dsData.Tables[0];
        ddl_Call_Agent.DataTextField = "DESCRIPTION";
        ddl_Call_Agent.DataValueField = "DESCRIPTION";
        ddl_Call_Agent.DataBind();
        //ddl_Call_Agent.Items.Insert(0, "--SELECT--");
        
    }

    protected void btnAllocate_Click(object sender, EventArgs e)
    {      
        try
        { 
            foreach (GridViewRow rw in GridView_JobReallocation.Rows)
            {
                CheckBox chkBx = (CheckBox)rw.FindControl("chkStatus");
                if (((CheckBox)rw.FindControl("chkStatus")).Checked)
                {
                    string ReAllocatedUser = ddl_Call_Agent.SelectedValue.ToString();
                    string job_no = rw.Cells[1].Text.ToString();
                    string branch_code = rw.Cells[2].Text.ToString();

                    DataSet dsData = new DataSet();
                    dsData = Facade.Servers.getUserId(ReAllocatedUser);

                    string userId = dsData.Tables[0].Rows[0]["CODE"].ToString();
                    string existing_user = Session["allocateUser_Id"].ToString();
                    String clientDtl = "";
                    try
                    {
                        System.Net.IPHostEntry host = new System.Net.IPHostEntry();
                        host = System.Net.Dns.GetHostByAddress(Request.ServerVariables["REMOTE_HOST"]);
                        clientDtl = host.AddressList[0].ToString();
                    }
                    catch (Exception)
                    {

                    }

                    string create_ip = clientDtl.ToString();
                    string create_user = Session["LoginId"].ToString();

                    Facade.Servers.updateTransactionAllocateUser(job_no, branch_code, userId);
                    Facade.Servers.insertToUserChangeLog(job_no, branch_code, existing_user, userId, create_user, create_ip);
                }
            } 

            DataSet dsUserData = new DataSet();
            string allocateUser_Id = Session["allocateUser_Id"].ToString();
            dsUserData = Facade.Servers.loadGdvJobReallocation(allocateUser_Id);
            
            GridView_JobReallocation.DataSource = dsUserData.Tables[0];
            GridView_JobReallocation.DataBind();

            loadDDL_Agent();
            ScriptManager.RegisterStartupScript(this, this.GetType(), "Message", " alert ('Successfully Updated') ;", true);            
        }            
        catch(Exception)
        {
            throw;
        }
    }
}
