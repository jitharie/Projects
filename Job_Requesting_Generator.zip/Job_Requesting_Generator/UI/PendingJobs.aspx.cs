﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class PendingJobs : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        loadGridView_PendingJobs();
    }

    public void loadGridView_PendingJobs()
    {
        DataSet dsData = new DataSet();
        dsData = Facade.Servers.loadGridView_PendingJobs();

        GridView_PendingJobs.DataSource = dsData.Tables[0];
        GridView_PendingJobs.DataBind();
    }

    protected void linkCall_Agent_click(object sender, EventArgs e)
    {
        try
        {
            LinkButton btndetails = (LinkButton)sender;
            GridViewRow gvrow = (GridViewRow)btndetails.NamingContainer;
            LinkButton l = new LinkButton();
            l = (LinkButton)gvrow.FindControl("linkCall_Agent");
            string Call_Agent = l.CommandArgument;
            Session["Call_Agent"] = Call_Agent.Trim();

            HiddenField hiddenField1 = (HiddenField)gvrow.FindControl("HiddenField1");
            string allocateUser_Id = hiddenField1.Value.Trim();
            Session["allocateUser_Id"] = allocateUser_Id;

            Response.Redirect("~/JobReallocation.aspx", false);
        }
        catch(Exception)
        {
            throw;
        }       
    }
}
