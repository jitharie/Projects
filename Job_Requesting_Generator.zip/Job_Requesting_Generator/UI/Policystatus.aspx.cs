﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Globalization;

public partial class Policystatus : System.Web.UI.Page
{
    DataSet policydetails;
    DataTable dt = new DataTable();
    DataTable dtcostagentno = new DataTable();

    protected void Page_Load(object sender, EventArgs e)
    {
        if (IsPostBack == false)
        {
            if (Session["checkedRadioButton"].ToString() == "radio1")
            {
                LinkButton1.Visible = true;
            }
            else if (Session["checkedRadioButton"].ToString() == "radio2")
            {
                LinkButton1.Visible = false;
            }
            policydetails = (DataSet)Session["newdspolicies"];
            GridView_policydata.DataSource = policydetails;
            GridView_policydata.DataBind();
        }
        
        dt.Columns.Add("Client_No");
        dt.Columns.Add("Policy_No");
        dt.Columns.Add("Customer_Name");
        dt.Columns.Add("PhoneNumber"); 
        dt.Columns.Add("Due_Date");
        dt.Columns.Add("Risk_Date");
        dt.Columns.Add("Premium");
        dt.Columns.Add("Mode");
        dt.Columns.Add("cost_agent_no");
        dt.Columns.Add("serial_No");
        dt.Columns.Add("Policy_Type");
        dt.Columns.Add("Description");
        dt.Columns.Add("SO_CODE");
        dt.Columns.Add("Branch_Code");
        dt.Columns.Add("COST_PER_JOB");


        dtcostagentno.Columns.Add("Cost_agent_no");      
    }

    //protected void Button1_Click(object sender, EventArgs e)
    //{
    //    try
    //    {           
    //        foreach (GridViewRow rw in GridView_policydata.Rows)
    //        {
    //            CheckBox chkBx = (CheckBox)rw.FindControl("chkStatus");
    //            if (((CheckBox)rw.FindControl("chkStatus")).Checked)
    //            {
    //                string Createuser = Session["Cerate_User"].ToString();
    //                string Cost_agentnum = Session["Agent_no"].ToString();
    //                string serialno = Session["serial_no"].ToString();
    //                string description = Session["des"].ToString();

    //                HiddenField hiddenField = (HiddenField)rw.FindControl("HiddenField3");
    //                string so_code = hiddenField.Value.Trim();

    //                HiddenField hiddenField1 = (HiddenField)rw.FindControl("HiddenField2");
    //                string branch_code = hiddenField1.Value.Trim();

    //                HiddenField hiddenField2 = (HiddenField)rw.FindControl("HiddenField4");
    //                string phone_number = hiddenField2.Value.Trim();

    //                if (Session["AllPolicyDtl"] == null)
    //                {
    //                    DataRow tempRow = dt.NewRow();
    //                    tempRow["Client_No"] = rw.Cells[1].Text.ToString();
    //                    tempRow["Policy_No"] = rw.Cells[2].Text.ToString();
    //                    tempRow["Customer_Name"] = rw.Cells[3].Text.ToString();
    //                    tempRow["PhoneNumber"] = phone_number;
    //                    tempRow["Due_Date"] = rw.Cells[5].Text.ToString();
    //                    tempRow["Risk_Date"] =rw.Cells[4].Text.ToString();
    //                    tempRow["Premium"] = rw.Cells[6].Text.ToString();
    //                    tempRow["Mode"] = rw.Cells[8].Text.ToString();
    //                    tempRow["cost_agent_no"] = Cost_agentnum;
    //                    tempRow["Policy_Type"] = rw.Cells[7].Text.ToString();
    //                    tempRow["serial_No"] = serialno;
    //                    tempRow["Description"] = description;
    //                    tempRow["SO_CODE"] = so_code;
    //                    tempRow["Branch_Code"] = branch_code;

    //                    dt.Rows.Add(tempRow);

    //                    Session["AllPolicyDtl"] = dt;
    //                }
    //                else
    //                {
    //                    DataRow tempRow = dt.NewRow();
    //                    tempRow["Client_No"] = rw.Cells[1].Text.ToString();
    //                    tempRow["Policy_No"] = rw.Cells[2].Text.ToString();
    //                    tempRow["Customer_Name"] = rw.Cells[3].Text.ToString();
    //                    tempRow["PhoneNumber"] = phone_number;
    //                    tempRow["Due_Date"] = rw.Cells[5].Text.ToString();
    //                    tempRow["Risk_Date"] = rw.Cells[4].Text.ToString();
    //                    tempRow["Premium"] = rw.Cells[6].Text.ToString();
    //                    tempRow["Mode"] = rw.Cells[8].Text.ToString();
    //                    tempRow["cost_agent_no"] = Cost_agentnum;
    //                    tempRow["Policy_Type"] = rw.Cells[7].Text.ToString();
    //                    tempRow["serial_No"] = serialno;
    //                    tempRow["Description"] = description;
    //                    tempRow["SO_CODE"] = so_code;
    //                    tempRow["Branch_Code"] = branch_code;

    //                    dt.Rows.Add(tempRow);

    //                    DataTable dt_1 = (DataTable)Session["AllPolicyDtl"];

    //                    dt.Merge(dt_1);

    //                    Session["AllPolicyDtl"] = dt;
    //                }
    //                }
    //                else
    //                {
    //                    ScriptManager.RegisterStartupScript(this, this.GetType(), "Message", " alert ('Please Select!!!') ;", true);
    //                }                
    //            }
            
    //        string Cost_agent_no = Session["Agent_no"].ToString();

    //        if (Session["recovery_agent"] != null)
    //        {
    //            DataTable dtcostagentno = (DataTable)Session["recovery_agent"];

    //            for (int k = 0; k < dtcostagentno.Rows.Count; k++)
    //            {
    //                if (Cost_agent_no != dtcostagentno.Rows[k]["Cost_agent_no"].ToString())
    //                {
    //                    DataRow temprowagent = dtcostagentno.NewRow();
    //                    temprowagent["Cost_agent_no"] = Cost_agent_no;
    //                    dtcostagentno.Rows.Add(temprowagent);

    //                    DataTable recovery_Agent = (DataTable)Session["recovery_agent"];
    //                    dtcostagentno.Merge(recovery_Agent);
    //                    Session["recovery_agent"] = dtcostagentno;
    //                }
    //            }
    //        }
    //        else
    //        {
    //            DataRow temprowagent = dtcostagentno.NewRow();
    //            temprowagent["Cost_agent_no"] = Cost_agent_no;
    //            dtcostagentno.Rows.Add(temprowagent);

    //            Session["recovery_agent"] = dtcostagentno;
    //        }

    //        //Session["newdatable"] = dt;
    //        Response.Redirect("~/RequestForm.aspx", false);          
    //    }
    //    catch (Exception e1)
    //    {
    //        string error;
    //        error = new ApplicationException(" Error Occured.. Try Again!!!!", e1).Message;
    //    }
    //}

    protected void RadioButton_SelectAll_CheckedChanged(object sender, EventArgs e)
    {
        if (RadioButton_SelectAll.Checked == true)
        {
            for (int i = 0; i < GridView_policydata.Rows.Count; i++)
            {
                CheckBox chk = (CheckBox)GridView_policydata.Rows[i].Cells[0].FindControl("chkStatus");
                chk.Checked = true;
                RadioButton_Deselect.Checked = false;
            }
        }
    }

    protected void RadioButton_Deselect_CheckedChanged(object sender, EventArgs e)
    {
        if (RadioButton_Deselect.Checked == true)
        {
        for (int i = 0; i < GridView_policydata.Rows.Count; i++)
          {
                CheckBox chk = (CheckBox)GridView_policydata.Rows[i].Cells[0].FindControl("chkStatus");
                chk.Checked = false;
                RadioButton_SelectAll.Checked = false;
                RadioButton_Deselect.Checked = false;
          }
        }
    }

    protected void Button2_Click(object sender, EventArgs e)
    {
        //Session["newdatable"] = dt;
        try
        {
            foreach (GridViewRow rw in GridView_policydata.Rows)
            {
                //if (rw.RowType == DataControlRowType.DataRow)
                //{
                    CheckBox chkBx = (CheckBox)rw.FindControl("chkStatus");
                    if (((CheckBox)rw.FindControl("chkStatus")).Checked)
                    {
                        
                        //string serialno = Session["serial_no"].ToString();
                        string description = Session["des"].ToString();

                        HiddenField hiddenField = (HiddenField)rw.FindControl("HiddenField3");
                        string Agent_no = hiddenField.Value.Trim();

                        HiddenField hiddenField1 = (HiddenField)rw.FindControl("HiddenField2");
                        string branch_code = hiddenField1.Value.Trim();

                        string call_type = Session["call_type"].ToString();
                        DataSet dsCallCost = new DataSet();

                        dsCallCost = Facade.Servers.get_call_cost(call_type);
                        string call_cost = dsCallCost.Tables[0].Rows[0]["COST_PER_JOB"].ToString();

                        if (Session["AllPolicyDtl"] == null)
                        {
                            DataRow tempRow = dt.NewRow();
                            tempRow["Client_No"] = rw.Cells[2].Text.ToString();
                            tempRow["Policy_No"] = rw.Cells[3].Text.ToString();
                            tempRow["Customer_Name"] = rw.Cells[4].Text.ToString();
                            tempRow["PhoneNumber"] = rw.Cells[12].Text.ToString();
                            tempRow["Due_Date"] = rw.Cells[6].Text.ToString();
                            tempRow["Risk_Date"] = rw.Cells[5].Text.ToString();
                            tempRow["Premium"] = rw.Cells[7].Text.ToString();
                            tempRow["Mode"] = rw.Cells[9].Text.ToString();
                            if (Session["Agent_no"].ToString() == "POLICY OWN AGENT")
                            {
                                tempRow["cost_agent_no"] = Agent_no;
                            }
                            else
                            {
                                string Recovery_Cost_agent_no = Session["Agent_no"].ToString();
                                tempRow["cost_agent_no"] = Recovery_Cost_agent_no;
                            }                       
                            tempRow["Policy_Type"] = rw.Cells[8].Text.ToString();
                            //tempRow["serial_No"] = serialno;
                            tempRow["Description"] = description;
                            tempRow["SO_CODE"] = Agent_no;
                            tempRow["Branch_Code"] = branch_code;
                            tempRow["COST_PER_JOB"] = call_cost;
                            //tempRow["SO_CODE"] = policydetails.Tables[0].Rows[0]["so_code"].ToString();
                            //tempRow["Branch_Code"] = policydetails.Tables[0].Rows[0]["REGISTER"].ToString();

                            dt.Rows.Add(tempRow);
                            Session["AllPolicyDtl"] = dt;
                        }
                        else
                        {
                            DataRow tempRow = dt.NewRow();
                            tempRow["Client_No"] = rw.Cells[2].Text.ToString();
                            tempRow["Policy_No"] = rw.Cells[3].Text.ToString();
                            tempRow["Customer_Name"] = rw.Cells[4].Text.ToString();
                            tempRow["PhoneNumber"] = rw.Cells[12].Text.ToString();
                            tempRow["Due_Date"] = rw.Cells[6].Text.ToString();
                            tempRow["Risk_Date"] = rw.Cells[5].Text.ToString();
                            tempRow["Premium"] = rw.Cells[7].Text.ToString();
                            tempRow["Mode"] = rw.Cells[9].Text.ToString();
                            if (Session["Agent_no"].ToString() == "POLICY OWN AGENT")
                            {
                                tempRow["cost_agent_no"] = Agent_no;
                            }
                            else
                            {
                                string Recovery_Cost_agent_no = Session["Agent_no"].ToString();
                                tempRow["cost_agent_no"] = Recovery_Cost_agent_no;
                            }    
                            //tempRow["cost_agent_no"] = Cost_agent_no;
                            tempRow["Policy_Type"] = rw.Cells[8].Text.ToString();
                            //tempRow["serial_No"] = serialno;
                            tempRow["Description"] = description;
                            tempRow["SO_CODE"] = Agent_no;
                            tempRow["Branch_Code"] = branch_code;
                            tempRow["COST_PER_JOB"] = call_cost;

                            dt.Rows.Add(tempRow);

                            DataTable dt_2 = (DataTable)Session["AllPolicyDtl"];
                            dt.Merge(dt_2);

                            Session["AllPolicyDtl"] = dt;
                        }
                    }
                    //else
                    //{
                    //    ScriptManager.RegisterStartupScript(this, this.GetType(), "Message", " alert ('Please Select!!!') ;", true);
                    //}
                }
            
            string Cost_agent_num = Session["Agent_no"].ToString();

            //if (Session["recovery_agent"] !=null)
            //{
            //    DataTable dtcostagentno = (DataTable)Session["recovery_agent"];

            //    for (int k = 0; k < dtcostagentno.Rows.Count; k++)
            //    {
            //        if (Cost_agent_num != dtcostagentno.Rows[k]["Cost_agent_no"].ToString())
            //        {
            //            DataRow temprowagent = dtcostagentno.NewRow();
            //            temprowagent["Cost_agent_no"] = Cost_agent_num;
            //            dtcostagentno.Rows.Add(temprowagent);

            //            DataTable recovery_Agent = (DataTable)Session["recovery_agent"];
            //            dtcostagentno.Merge(recovery_Agent);

            //            Session["recovery_agent"] = dtcostagentno;                  
            //        }
            //    }
            //}
            //else
            //{
                if (Cost_agent_num == "POLICY OWN AGENT")
                {
                    //foreach (DataRow row in dt.Rows)
                    //{
                        //DataRow newRow = dtcostagentno.NewRow();
                        //newRow["cost_agent_no"] = row["cost_agent_no"];
                        //dtcostagentno.Rows.Add(newRow);

                        DataView view = new DataView(dt);
                        dtcostagentno = view.ToTable(true, "cost_agent_no");
                    //}
                    Session["recovery_agent"] = dtcostagentno;               
                }
                else
                {
                    DataRow temprowagent = dtcostagentno.NewRow();
                    temprowagent["Cost_agent_no"] = Cost_agent_num;
                    dtcostagentno.Rows.Add(temprowagent);

                    Session["recovery_agent"] = dtcostagentno;
                } 
            //}

            string Createuser = Session["Cerate_User"].ToString();
            Session["user"] = Createuser;

           // Session["newdatable"] = dt;

            DataTable dtnew =(DataTable)Session["recovery_agent"];

            Session["cost_agent"] = dtnew;
            Response.Redirect("~/SummaryOfRecoveries.aspx", false);
        }
        catch (Exception e1)
        {
            string error;
            error = new ApplicationException(" Error Occured.. Try Again!!!!", e1).Message;
        }
    }

    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        DataSet dsData = (DataSet)Session["newdsMissingpolicies"];
        DataTable dtnew = dsData.Tables[0]; 

        string txt = string.Empty;

        foreach (DataRow row in dtnew.Rows)
        {
            foreach (DataColumn column in dtnew.Columns)
            {
                //Add the Data rows.
                txt += row[column.ColumnName].ToString() + "\t\t";
            }

            //Add new line.
            txt += "\r\n";
        }

        //Download the Text file.
        Response.Clear();
        Response.Buffer = true;
        Response.AddHeader("content-disposition", "attachment;filename=SqlExport.txt");
        Response.Charset = "";
        Response.ContentType = "application/text";
        Response.Output.Write(txt);

        Response.Flush();
        Response.End();
    }

    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Session.Remove("newdsMissingpolicies");

        if (Session["UserType"].ToString().Equals(("USER")))
        {
            Response.Redirect("~/AdminRequestForm.aspx", false);
        }
        else if (Session["UserType"].ToString().Equals(("HOB")))
        {
            Response.Redirect("~/RequestForm.aspx", false);
        }        
    }
}
