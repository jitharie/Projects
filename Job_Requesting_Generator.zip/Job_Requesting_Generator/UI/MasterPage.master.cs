﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class MasterPage : System.Web.UI.MasterPage
{
    protected void Page_Load(object sender, EventArgs e)
    {
        string Username = Session["UserName"].ToString();
        Lbl_username.Text = Username;

        if ((Session["UserStatus"] != "Valid"))
        {
            Response.Redirect("~\\Login.aspx", true);
            return;
        }
        if (!IsPostBack)
        {
           

            if ((Session["UserStatus"] == "Valid"))
            {
                if (Session["UserType"].ToString().Equals(("USER")))
                {
                    this.TreeView.Nodes.RemoveAt(0);
                }
                else if (Session["UserType"].ToString().Equals(("HOB")))
                {
                    this.TreeView.Visible = false;
                    this.TreeView1.Visible = true;
                } 
            }
        }

        Response.Expires = 0;
        Response.Cache.SetNoStore();
    }
    //protected void TreeView_HO_Admin_SelectedNodeChanged(object sender, EventArgs e)
    //{
    //    try
    //    {
    //        Session["UserStatus"] = "InValid";
    //        Session["EMPID"] = "";
    //        Session["isRestrict"] = "yes";
    //        Response.Redirect("~\\Login.aspx", false);
    //    }
    //    catch (Exception)
    //    {
    //        throw;
    //    }
    //}
    //protected void TreeView_Hob_SelectedNodeChanged(object sender, EventArgs e)
    //{
    //    try
    //    {
    //        Session["UserStatus"] = "InValid";
    //        Session["EMPID"] = "";
    //        Session["isRestrict"] = "yes";
    //        Response.Redirect("~\\Login.aspx", false);
    //    }
    //    catch (Exception)
    //    {
    //        throw;
    //    }
    //}
    //protected void TreeView_Call_Agent_SelectedNodeChanged(object sender, EventArgs e)
    //{
    //    try
    //    {
    //        Session["UserStatus"] = "InValid";
    //        Session["EMPID"] = "";
    //        Session["isRestrict"] = "yes";
    //        Response.Redirect("~\\Login.aspx", false);
    //    }
    //    catch (Exception)
    //    {
    //        throw;
    //    }
    //}

    protected void TreeView_SelectedNodeChanged(object sender, EventArgs e)
    {
        try
        {
            Session["UserStatus"] = "InValid";
            Session["EMPID"] = "";
            Session["isRestrict"] = "yes";
            Response.Redirect("~\\Login.aspx", false);
        }
        catch (Exception)
        {
            throw;
        }
    }
}
