﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class SummaryOfRecoveries : System.Web.UI.Page
{
    DataTable newdatatable = new DataTable();
    DataTable newcostagent = new DataTable();

    DataSet dsData = new DataSet();

    DataTable summaryrecoveries = new DataTable();

   int amount=0;

    protected void Page_Load(object sender, EventArgs e)
   {
       //try
       //{
           //if (!this.IsPostBack)
           //{
               newdatatable = (DataTable)Session["AllPolicyDtl"];
               newcostagent = (DataTable)Session["cost_agent"];

               summaryrecoveries.Columns.Add("cost_agent");
               summaryrecoveries.Columns.Add("No_of_client");
               summaryrecoveries.Columns.Add("recovery_amount");

               get_summary();
       //    }
       //}
       //catch (Exception)
       //{
       //    throw;
       //}  
    }

    private void get_summary()
    {
        try
        {
            for (int i = 0; i < newcostagent.Rows.Count; i++)
            {
                int client_cnt = 0;
                for (int j = 0; j < newdatatable.Rows.Count; j++)
                {
                    string description = newdatatable.Rows[j]["Description"].ToString();
                    DataSet recovery_amount = Facade.Servers.get_recovery_amount(description);
                    string ss = recovery_amount.Tables[0].Rows[0][0].ToString();
                    amount = Convert.ToInt32(Convert.ToDouble(ss));

                    if (newcostagent.Rows[i]["Cost_agent_no"].ToString() == newdatatable.Rows[j]["Cost_agent_no"].ToString())
                    {
                        client_cnt++;
                    }
                }

                int sum_recovery = amount * client_cnt;
                DataRow tempRow = summaryrecoveries.NewRow();
                tempRow["cost_agent"] = newcostagent.Rows[i]["Cost_agent_no"].ToString();
                tempRow["No_of_client"] = client_cnt;
                tempRow["recovery_amount"] = sum_recovery;
                summaryrecoveries.Rows.Add(tempRow);
            }

            GridView_summary.DataSource= summaryrecoveries;
            GridView_summary.DataBind();

            //----calculate total amount-------
            int fulltotal = 0;
            int No_of_customers = 0;
            int No_Agent = 1;

            for (int m = 0; m < summaryrecoveries.Rows.Count; m++)
            {
                int sum = int.Parse(summaryrecoveries.Rows[m]["recovery_amount"].ToString());
                int Cust_tot = int.Parse(summaryrecoveries.Rows[m]["No_of_client"].ToString());
                fulltotal = fulltotal + sum;
                No_of_customers = No_of_customers + Cust_tot;                
            }
    
            Txtfullamount.Text = Convert.ToString(fulltotal);

            //end 

            //----calculate start time-------------------

            float per_call = 3;
            int No_of_cus_oneagent = No_of_customers / No_Agent;
            float total_time = (float)No_of_cus_oneagent * per_call;
            float working_hrs = 7 * 60;
            float days = total_time/working_hrs;
            int no_of_days = (int)Math.Ceiling(days);

            DateTime today = DateTime.Now;
            DateTime estimated_date = today.AddDays(no_of_days);
            string holiday_date = Convert.ToDateTime(estimated_date).ToString("yyyy-MM-dd");
            dsData =  Facade.Servers.checkHoliday(holiday_date);

            if (dsData.Tables[0].Rows.Count > 0)
            {
                while (dsData.Tables[0].Rows.Count > 0)
                {
                    estimated_date = estimated_date.AddDays(1);
                    holiday_date = Convert.ToDateTime(estimated_date).ToString("yyyy-MM-dd");
                    dsData = Facade.Servers.checkHoliday(holiday_date);
                }
                string date = Convert.ToDateTime(estimated_date).ToString("yyyy/MM/dd HH:mm:ss");
                TxtEstimate_Date.Text = Convert.ToString(date);
            }
            else
            {
                string date = Convert.ToDateTime(estimated_date).ToString("yyyy/MM/dd HH:mm:ss");
                TxtEstimate_Date.Text = Convert.ToString(date);
            }
        } 
        catch
        {              
            throw;
        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        try
        {
           string User =Session["user"].ToString();
           string submit_date = DateTime.Now.Date.ToString("yyyy-MM-dd");
           string estimated_date = TxtEstimate_Date.Text;
           string status = "Pending";
           string Total_cost = Txtfullamount.Text;
           //string policy_type = Session["PolicyType"].ToString();
           string call_type = Session["call_type"].ToString();
           string job_type = Session["job_type"].ToString();

           int i = Facade.Servers.Save_Job_Requesting_data(User, submit_date, estimated_date, status, Total_cost, newdatatable,call_type,job_type);
           if (i == 1)
           {
               ScriptManager.RegisterStartupScript(this, this.GetType(), "Message", " alert ('Successfully Saved!!') ;window.location='RequestForm.aspx';", true);

               DataSet dsMail = new DataSet();
               string msg = "testing";
               //string EmailAddress = "asangaw@sys.ceylife.lk";
               string EmailAddress = "ranushikal@cct.ceylife.lk";
               string subject = "Request sent";
               dsMail = Facade.Servers.SendMail(msg, EmailAddress, subject);
           }
           else
           {
               ScriptManager.RegisterStartupScript(this, this.GetType(), "Message", " alert ('Error!!') ;", true);
           }
           Session.Remove("AllPolicyDtl");
           newcostagent.Clear();
           Session.Remove("cost_agent");
           Session.Remove("recovery_agent");
           summaryrecoveries.Clear();        
        }
        catch
        {
            throw;
        }
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        Session.Remove("AllPolicyDtl");
        newcostagent.Clear();
        Session.Remove("cost_agent");
        Session.Remove("recovery_agent");
        summaryrecoveries.Clear();

        if (Session["UserType"].ToString().Equals(("USER")))
        {
            Response.Redirect("~/AdminRequestForm.aspx", false);
        }
        else if (Session["UserType"].ToString().Equals(("HOB")))
        {
            Response.Redirect("~/RequestForm.aspx", false);
        }  
    }
}
