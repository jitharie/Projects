﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using DataObjects.SqlServers;

namespace Facade
{
    public static class  Servers
    {

        static Sql_Servers _sql = new Sql_Servers(); 
        static PasswordED _pwrdED = new PasswordED();

        public static DataSet get_Userdetails(string Userid, string Pwd)
        {
            return _sql.get_UserDetails(Userid, _pwrdED.encryptPassword(Pwd));
        }

        public static DataSet get_reqtype()
        {
            return _sql.get_reqtype();
        }

        public static DataSet get_agentno(string UserBranch)
        {
            return _sql.get_agent_no(UserBranch);
        }

        public static DataSet getall_policy_types()
        {
            return _sql.getall_policy_types();
        }

        public static DataSet get_policies(int agentno, string riskdatefrom, string riskdateto, 
                                                string duedatefrom, string duedateto, string policytype, string mcfpfrom, 
                                                    string mcfpto)
        {
            return _sql.get_policies(agentno, riskdatefrom, riskdateto, duedatefrom, duedateto, policytype, mcfpfrom, mcfpto);
        }

        public static int Save_Job_Requesting_data(string User, string submit_date, string estimated_date, string status, string Total_cost, DataTable newdatatable,string call_type,string job_type)
        {
            return _sql.Save_Job_Requesting_data(User, submit_date, estimated_date, status, Total_cost, newdatatable,call_type, job_type);
        }

        public static DataSet getall_Calling_types()
        {
            return _sql.get_all_calling_types();
        }

        public static DataSet get_serial_no(string callingtype)
        {
            return _sql.get_serial_no(callingtype);
        }

        public static DataSet get_recovery_amount(string description)
        {
            return _sql.get_recovery_amount(description);
        }

        public static DataSet get_call_agent()
        {
            return _sql.get_call_agents();
        }

        public static DataSet load_gridView_Admin_View()
        {
            return _sql.load_gridView_Admin_View();
        }
    }
}
