﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using System.Data.OleDb;
using System.Data;

public partial class wellcomeCalls : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (!this.IsPostBack)
            {
                
            }
        }
        catch (Exception)
        {
            throw;
        }
    }
    protected void ViewPolicy2_Click(object sender, EventArgs e)
    {
        string emp_Id = Session["LoginId"].ToString();
        Facade.Servers.removeWelcomeCallsPolicyLog(emp_Id);

        if (fuattach.HasFile)
        {
            try
            {
                string strFilepPath;

                FileInfo fi = new FileInfo(fuattach.PostedFile.FileName);
                string ext = fi.Extension;
                string connString = "";

                string filename = Path.GetFullPath(fuattach.PostedFile.FileName);

                string DirectoryPath = Server.MapPath("~/files//");
                strFilepPath = DirectoryPath + fuattach.FileName;
                Directory.CreateDirectory(DirectoryPath);
                fuattach.SaveAs(strFilepPath);

                if (ext == ".txt")
                {
                    if (!File.Exists(strFilepPath))
                    {
                        ScriptManager.RegisterStartupScript(this, this.GetType(), "Message", " alert ('File does not exist!!');", true);
                    }
                    else
                    {
                        if (new FileInfo(strFilepPath).Length == 0)
                        {
                            ScriptManager.RegisterStartupScript(this, this.GetType(), "Message", " alert ('File is empty!!');", true);
                        }
                        else
                        {
                            string strConnString = "Driver={Microsoft Text Driver (*.txt; *.csv)};Dbq=" + strFilepPath + "; Extensions=asc,csv,tab,txt; Persist Security Info=False";

                            DataTable dt = new DataTable();
                            DataColumn col = new DataColumn("policy_no");
                            col.DataType = System.Type.GetType("System.String");
                            dt.Columns.Add(col);

                            string[] aa = File.ReadAllLines(strFilepPath);
                            foreach (var item in aa)
                            {
                                DataRow dr = dt.NewRow();
                                dr[0] = item.ToString();
                                dt.Rows.Add(dr);
                            }
                            DataSet dsNew = new DataSet();
                            dsNew.Tables.Add(dt);

                            for (int i = 0; i < dsNew.Tables[0].Rows.Count; i++)
                            {
                                Facade.Servers.saveWelcomeCallsPolicyLog(emp_Id, dsNew.Tables[0].Rows[i]["policy_no"].ToString());
                            }

                            File.Delete(strFilepPath);

                            DataSet dsPolicyDetails = Facade.Servers.getUploadedWelcomePolicyDetails(emp_Id);

                            DataTable dt1 = dsPolicyDetails.Tables[0];

                            //Build the Text file data.
                            string txt = string.Empty;

                            foreach (DataRow row in dt1.Rows)
                            {
                                foreach (DataColumn column in dt1.Columns)
                                {
                                    //Add the Data rows.
                                    txt += row[column.ColumnName].ToString() + "\t\t";
                                }

                                //Add new line.
                                txt += "\r\n";
                            }

                            //Download the Text file.
                            Response.Clear();
                            Response.Buffer = true;
                            Response.AddHeader("content-disposition", "attachment;filename=SqlExport.txt");
                            Response.Charset = "";
                            Response.ContentType = "application/text";
                            Response.Output.Write(txt);

                            Response.Flush();
                            Response.End();                            
                        }
                    }
                }
                else
                {
                    ScriptManager.RegisterStartupScript(this, this.GetType(), "Message", " alert ('Only text files can be uploaded!!');", true);
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
    }
    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        DataSet dsData = new DataSet();
        string emp_Id = Session["LoginId"].ToString();
        dsData = Facade.Servers.getMissingWelcomeNumbers(emp_Id);
        DataTable dtnew = dsData.Tables[0];

        string txt = string.Empty;

        foreach (DataRow row in dtnew.Rows)
        {
            foreach (DataColumn column in dtnew.Columns)
            {
                //Add the Data rows.
                txt += row[column.ColumnName].ToString() + "\t\t";
            }

            //Add new line.
            txt += "\r\n";
        }

        //Download the Text file.
        Response.Clear();
        Response.Buffer = true;
        Response.AddHeader("content-disposition", "attachment;filename=SqlExport.txt");
        Response.Charset = "";
        Response.ContentType = "application/text";
        Response.Output.Write(txt);

        Response.Flush();
        Response.End();
    }
}
