﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using System.Data.OleDb;
using System.Data;
using System.Windows.Forms;

public partial class AdminRequestForm : System.Web.UI.Page
{
    DataSet dsgetReqtype;
    DataSet dsgetAgentNo;
    DataSet dsgetpolicytype;
    DataSet dspolicies;
    DataSet dsgetcallingtype;
    DataSet dsgetserialno;
    DataSet dsfinal = new DataSet();
    DataTable dtcostagentno = new DataTable();
    DataSet dsBranchCode;

    DataTable newdatatable = new DataTable();
    int agentno;
    string costagentno;
    string policytype, statcode, pstatcode;
    string checkedRadioButton;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!this.IsPostBack)
        {
            get_RequestType();
            get_policy_type();
            get_calling_type();
            Panel2.Visible = false;
            Panel3.Visible = false;
            Panel5.Visible = false;

            get_Branch_Code();
            //string UserBranch = Session["branchCode"].ToString();
            //DataSet dsBranch = new DataSet();
            //if (UserBranch == "HO01")
            //{
            //    Session["cscBranch"] = "HO01";
            //}
            //else
            //{
            //    dsBranch = Facade.Servers.getcscBranch(UserBranch);
            //    string cscBranch = dsBranch.Tables[0].Rows[0]["DESCITEM"].ToString();
            //    Session["cscBranch"] = cscBranch;
            //}
        }
        //dtcostagentno.Columns.Add("Costagent_No");      
    }

    private void get_calling_type()
    {
        dsgetcallingtype = Facade.Servers.getall_Calling_types();
        DDL_Callingtype.DataSource = dsgetcallingtype.Tables[0];
        DDL_Callingtype.DataTextField = "DESCRIPTION";
        DDL_Callingtype.DataValueField = "DESCRIPTION";
        DDL_Callingtype.DataBind();
        DDL_Callingtype.Items.Insert(0, "--SELECT--");
    }

    private void get_Branch_Code()
    {
        dsBranchCode = Facade.Servers.getBranchCode();
        ddlBranchCode.DataSource = dsBranchCode.Tables[0];
        ddlBranchCode.DataTextField = "LONGDESC";
        ddlBranchCode.DataValueField = "DESCITEM";
        ddlBranchCode.DataBind();
        ddlBranchCode.Items.Insert(0, "--SELECT--");
    }

    private void get_policy_type()
    {
        dsgetpolicytype = Facade.Servers.getall_policy_types();
        DDLPolicytype.DataSource = dsgetpolicytype.Tables[0];
        DDLPolicytype.DataTextField = "PLAN_TYPE";
        DDLPolicytype.DataValueField = "PLAN_TYPE";
        DDLPolicytype.DataBind();
        DDLPolicytype.Items.Insert(0, "--SELECT--");
    }

    private void get_AgentNo()
    {
        string Userid = Session["EMPID"].ToString();
        string Username = Session["UserName"].ToString();
        string UserStatus = Session["status"].ToString();
        string cscBranch = Session["cscBranch"].ToString();

        dsgetAgentNo = Facade.Servers.get_agentno(cscBranch);
        DropDownListAgentno.DataSource = dsgetAgentNo.Tables[0];
        DropDownListAgentno.DataTextField = "AgentNo";
        DropDownListAgentno.DataValueField = "AGNTNUM";
        DropDownListAgentno.DataBind();
        DropDownListAgentno.Items.Insert(0, "--SELECT--");

        dsgetAgentNo = Facade.Servers.get_agentno(cscBranch);
        DDL_CostrecoveryNo.DataSource = dsgetAgentNo.Tables[0];
        DDL_CostrecoveryNo.DataTextField = "AgentNo";
        DDL_CostrecoveryNo.DataValueField = "AGNTNUM";
        DDL_CostrecoveryNo.DataBind();
        DDL_CostrecoveryNo.Items.Insert(0, "--SELECT--");

        Session["Cerate_User"] = Userid;
    }

    private void get_RecoveryAgentNo()
    {
        string UserBranch = Session["branchCode"].ToString();
        string cscBranch;

        if (Session["cscBranch"] != null )
        {
            cscBranch = Session["cscBranch"].ToString();
        }
        else
        {
            ScriptManager.RegisterStartupScript(this, this.GetType(), "Message", " alert ('You have not selected the branch!!');", true);
            return;
        }
      
        string Userid = Session["EMPID"].ToString();
        string Username = Session["UserName"].ToString();
        string UserStatus = Session["status"].ToString();

        dsgetAgentNo = Facade.Servers.get_agentno(cscBranch);
     
        ddlCostrecoveryNo.DataSource = dsgetAgentNo.Tables[0];
        ddlCostrecoveryNo.DataTextField = "AgentNo";
        ddlCostrecoveryNo.DataValueField = "AGNTNUM";
        ddlCostrecoveryNo.DataBind();
        ddlCostrecoveryNo.Items.Insert(0, "--SELECT--");
        ddlCostrecoveryNo.Items.Insert(1, "POLICY OWN AGENT");

        Session["Cerate_User"] = Userid;
    }

    private void get_RecruimentRecoveryAgentNo()
    {
        string UserBranch = Session["branchCode"].ToString();
        string cscBranch;

        if (Session["cscBranch"] != null)
        {
            cscBranch = Session["cscBranch"].ToString();
        }
        else
        {
            ScriptManager.RegisterStartupScript(this, this.GetType(), "Message", " alert ('You have not selected the branch!!');", true);
            return;
        }

        string Userid = Session["EMPID"].ToString();
        string Username = Session["UserName"].ToString();
        string UserStatus = Session["status"].ToString();

        dsgetAgentNo = Facade.Servers.get_agentno(cscBranch);

        ddlRecoveryAgent.DataSource = dsgetAgentNo.Tables[0];
        ddlRecoveryAgent.DataTextField = "AgentNo";
        ddlRecoveryAgent.DataValueField = "AGNTNUM";
        ddlRecoveryAgent.DataBind();
        ddlRecoveryAgent.Items.Insert(0, "--SELECT--");

        Session["Cerate_User"] = Userid;
    }

    private void get_RequestType()
    {
        dsgetReqtype = Facade.Servers.get_reqtype();
        DropDownList_reqtype.DataSource = dsgetReqtype.Tables[0];
        DropDownList_reqtype.DataTextField = "DESCRIPTION";
        DropDownList_reqtype.DataValueField = "DESCRIPTION";
        DropDownList_reqtype.DataBind();
        DropDownList_reqtype.Items.Insert(0, "--SELECT--");
    }

    protected void btnViewpolicy_Click(object sender, EventArgs e)
    {
        try
        {
            if (Validate_Data())
            {
                string _Duedatefrmmonth = "";
                string _Duefromtodate = "";
                string _Duetomonth = "";
                string _Duetodate = "";

                if (DateTime.Parse(Txt_Duedate_from.Text).Month.ToString().Trim().Length.Equals(1))
                {
                    _Duedatefrmmonth = "0" + DateTime.Parse(Txt_Duedate_from.Text).Month.ToString().Trim();
                }
                else
                {
                    _Duedatefrmmonth = DateTime.Parse(Txt_Duedate_from.Text).Month.ToString().Trim();
                }

                if (DateTime.Parse(Txt_Duedate_from.Text).Day.ToString().Trim().Length.Equals(1))
                {
                    _Duefromtodate = "0" + DateTime.Parse(Txt_Duedate_from.Text).Day.ToString().Trim();
                }
                else
                {
                    _Duefromtodate = DateTime.Parse(Txt_Duedate_from.Text).Day.ToString().Trim();
                }

                if (DateTime.Parse(Txt_Dueto_date.Text).Month.ToString().Trim().Length.Equals(1))
                {
                    _Duetomonth = "0" + DateTime.Parse(Txt_Dueto_date.Text).Month.ToString();
                }
                else
                {
                    _Duetomonth = DateTime.Parse(Txt_Dueto_date.Text).Month.ToString();
                }

                if (DateTime.Parse(Txt_Dueto_date.Text).Day.ToString().Length.Equals(1))
                {
                    _Duetodate = "0" + DateTime.Parse(Txt_Dueto_date.Text).Day.ToString();
                }
                else
                {
                    _Duetodate = DateTime.Parse(Txt_Dueto_date.Text).Day.ToString();
                }

                string riskdatefrom = "'" + Txt_riskdatefrom.Text.ToString() + "'";
                string riskdateto = "'" + Txt_riskdateto.Text.ToString() + "'";
                string mcfpfrom = "'" + MCFPfrom.Text.ToString() + "'";
                string mcfpto = "'" + MCFPTo.Text.ToString() + "'";

                string duedatefrom = "'" + Txt_Duedate_from.Text.ToString() + "'";
                string duedateto = "'" + Txt_Dueto_date.Text.ToString() + "'";

                //string duedatefrom = "'" + DateTime.Parse(Txt_Duedate_from.Text).Year.ToString() + _Duedatefrmmonth + _Duefromtodate + "'";
                //string duedateto = "'" + DateTime.Parse(Txt_Dueto_date.Text).Year.ToString() + _Duetomonth + _Duetodate + "'";
                string job_type = DropDownList_reqtype.SelectedItem.Text.ToString();
                Session["job_type"] = job_type;
                string call_type = DDL_Callingtype.SelectedItem.Text.ToString();
                Session["call_type"] = call_type;
                agentno = int.Parse(DropDownListAgentno.SelectedValue.ToString());
                policytype = "'" + DDLPolicytype.SelectedValue.ToString().Trim() + "'";
                Session["PolicyType"] = policytype;

                if (DDL_Callingtype.SelectedIndex > 0)
                {
                    string callingtype = DDL_Callingtype.SelectedValue.ToString();
                    dsgetserialno = Facade.Servers.get_serial_no(callingtype);
                    if (dsgetserialno.Tables[0].Rows.Count > 0)
                    {
                        //string serialno = dsgetserialno.Tables[0].Rows[0][0].ToString();
                        string description = dsgetserialno.Tables[0].Rows[0][1].ToString();
                        //Session["serial_no"] = serialno;
                        Session["des"] = description;
                    }
                    //if (callingtype == "Active")
                    //{
                    //    statcode = "'" + "IF" + "'";
                    //    pstatcode = " in('SP','PP','FP','PU')";


                    //}
                    //else
                    //{
                    //    statcode = "'" + "LA" + "'";
                    //    pstatcode = "=LA";

                    //}

                }

                if (Session["newpolicydtl"] == null)
                {
                    dspolicies = Facade.Servers.get_policies(agentno, riskdatefrom, riskdateto, duedatefrom,
                                                             duedateto, policytype, mcfpfrom, mcfpto);

                    Session["newpolicydtl"] = dspolicies;

                    //Session["FinalPolicyDtl"] = dspolicies;               
                }
                else
                {
                    dspolicies = Facade.Servers.get_policies(agentno, riskdatefrom, riskdateto, duedatefrom,
                                                             duedateto, policytype, mcfpfrom, mcfpto);

                    //DataSet dtnew = (DataSet)Session["newpolicydtl"];
                    //DataSet dtnew_1 = dspolicies;

                    //dtnew.Merge(dtnew_1);

                    Session["newpolicydtl"] = dspolicies;

                    //Session["FinalPolicyDtl"] = dtnew;
                }


                if (dspolicies.Tables[0].Rows.Count > 0)
                {
                    //costagentno = int.Parse(DDL_CostrecoveryNo.SelectedValue.ToString());
                    //costagentno = int.Parse(DDL_CostrecoveryNo.SelectedItem.Text.ToString());
                    costagentno = DDL_CostrecoveryNo.SelectedValue.ToString();

                    Session["Agent_no"] = costagentno;

                    //if (Session["Cost_agent_no"] == null)
                    //{
                    //    DataRow tempRow = dtcostagentno.NewRow();
                    //    tempRow["Costagent_No"] = costagentno;
                    //    dtcostagentno.Rows.Add(tempRow);

                    //    Session["Cost_agent_no"] = dtcostagentno;
                    //}
                    //else
                    //{

                    //    DataRow tempRow = dtcostagentno.NewRow();
                    //    tempRow["Costagent_No"] = costagentno;
                    //    dtcostagentno.Rows.Add(tempRow);

                    //    DataTable dtAgent = (DataTable)Session["Cost_agent_no"];

                    //    dtcostagentno.Merge(dtAgent);

                    //    Session["Cost_agent_no"] = dtcostagentno;
                    //}

                    //DataSet dsFinalPolicyDtl = (DataSet)Session["FinalPolicyDtl"];
                    checkedRadioButton = "radio2";
                    Session["checkedRadioButton"] = checkedRadioButton; 
                    Session["newdspolicies"] = dspolicies;

                    Response.Redirect("~/Policystatus.aspx", false);
                }
                else
                {
                    ScriptManager.RegisterStartupScript(this, this.GetType(), "Message", " alert ('No Data Found!!!') ;", true);
                }
            }
        }
        catch (Exception)
        {
            throw;
        }
    }

    private bool Validate_Data()
    {
        bool _OK = true;

        if (Txt_riskdatefrom.Text.ToString() == "" || Txt_riskdateto.Text.ToString() == "")
        {
            _OK = false;
            ScriptManager.RegisterStartupScript(this, this.GetType(), "Message", " alert ('Please Enter Risk Date!!!') ;", true);
        }
        if (Txt_riskdatefrom.Text.ToString() != "" || Txt_riskdateto.Text.ToString() != "")
        {
            string riskdatefrom_year = DateTime.Parse(Txt_riskdatefrom.Text).Year.ToString();
            string riskdatefrom_month = DateTime.Parse(Txt_riskdatefrom.Text).Month.ToString();
            string riskdatefrom_Date = DateTime.Parse(Txt_riskdatefrom.Text).Day.ToString();

            string riskdateto_year = DateTime.Parse(Txt_riskdateto.Text).Year.ToString();
            string riskdateto_month = DateTime.Parse(Txt_riskdateto.Text).Month.ToString();
            string riskdateto_Date = DateTime.Parse(Txt_riskdateto.Text).Day.ToString();

            if ((int.Parse(riskdatefrom_year)) > (int.Parse(riskdateto_year)))
            {
                _OK = false;
                ScriptManager.RegisterStartupScript(this, this.GetType(), "Message", " alert ('Entered Risk Date Year is not valid!!!') ;", true);
            }
            if ((int.Parse(riskdatefrom_year)) == (int.Parse(riskdateto_year)))
            {
                if ((int.Parse(riskdatefrom_month)) > (int.Parse(riskdateto_month)))
                {
                    _OK = false;
                    ScriptManager.RegisterStartupScript(this, this.GetType(), "Message", " alert ('Entered Risk Date Month is not valid!!!') ;", true);
                }
                else if ((int.Parse(riskdatefrom_month)) == (int.Parse(riskdateto_month)))
                {
                    if ((int.Parse(riskdatefrom_Date)) > (int.Parse(riskdateto_Date)))
                    {
                        _OK = false;
                        ScriptManager.RegisterStartupScript(this, this.GetType(), "Message", " alert ('Entered Risk Date Day is not valid!!!') ;", true);
                    }
                }
            }
        }

        if (Txt_Duedate_from.Text.ToString() == "" || Txt_Dueto_date.Text.ToString() == "")
        {
            _OK = false;
            ScriptManager.RegisterStartupScript(this, this.GetType(), "Message", " alert ('Please Enter Due Date!!!') ;", true);
        }

        if (Txt_Duedate_from.Text.ToString() != "" || Txt_Dueto_date.Text.ToString() != "")
        {
            string duedatefrom_year = DateTime.Parse(Txt_Duedate_from.Text).Year.ToString();
            string duedatefrom_month = DateTime.Parse(Txt_Duedate_from.Text).Month.ToString();
            string duedatefrom_Date = DateTime.Parse(Txt_Duedate_from.Text).Day.ToString();

            string duedateto_year = DateTime.Parse(Txt_Dueto_date.Text).Year.ToString();
            string duekdateto_month = DateTime.Parse(Txt_Dueto_date.Text).Month.ToString();
            string duedateto_Date = DateTime.Parse(Txt_Dueto_date.Text).Day.ToString();

            if ((int.Parse(duedatefrom_year)) > (int.Parse(duedateto_year)))
            {
                _OK = false;
                ScriptManager.RegisterStartupScript(this, this.GetType(), "Message", " alert ('Entered Due Date Year is not valid!!!') ;", true);
            }
            if ((int.Parse(duedatefrom_year)) == (int.Parse(duedateto_year)))
            {
                if ((int.Parse(duedatefrom_month)) > (int.Parse(duekdateto_month)))
                {
                    _OK = false;
                    ScriptManager.RegisterStartupScript(this, this.GetType(), "Message", " alert ('Entered Due Date Month is not valid!!!') ;", true);
                }
                else if ((int.Parse(duedatefrom_month)) == (int.Parse(duekdateto_month)))
                {
                    if ((int.Parse(duedatefrom_Date)) > (int.Parse(duedateto_Date)))
                    {
                        _OK = false;
                        ScriptManager.RegisterStartupScript(this, this.GetType(), "Message", " alert ('Entered Due Date Day is not valid!!!') ;", true);
                    }
                }
            }


        }
        if (MCFPfrom.Text.ToString() == "" || MCFPTo.Text.ToString() == "")
        {
            _OK = false;
            ScriptManager.RegisterStartupScript(this, this.GetType(), "Message", " alert ('Please Enter MCFP Value!!!') ;", true);
        }
        if (DropDownListAgentno.SelectedIndex <= 0)
        {
            _OK = false;
            ScriptManager.RegisterStartupScript(this, this.GetType(), "Message", " alert ('Please Select A Agent No!!!') ;", true);
        }
        if (DDLPolicytype.SelectedIndex <= 0)
        {
            _OK = false;
            ScriptManager.RegisterStartupScript(this, this.GetType(), "Message", " alert ('Please Select A Policy Type!!!') ;", true);
        }
        if (DDL_Callingtype.SelectedIndex <= 0)
        {
            _OK = false;
            ScriptManager.RegisterStartupScript(this, this.GetType(), "Message", " alert ('Please Select A Calling Type!!!') ;", true);
        }
        if (DropDownList_reqtype.SelectedIndex <= 0)
        {
            _OK = false;
            ScriptManager.RegisterStartupScript(this, this.GetType(), "Message", " alert ('Please Select A Request Type!!!') ;", true);
        }
        if (DDL_CostrecoveryNo.SelectedItem.Text == "--SELECT--")
        {
            _OK = false;
            ScriptManager.RegisterStartupScript(this, this.GetType(), "Message", " alert ('Please Select A Cost Recovery Agent No Type!!!') ;", true);
        }

        return _OK;
    }
    protected void DropDownList_reqtype_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            if (DropDownList_reqtype.SelectedIndex > 0)
            {
                string selecttype = DropDownList_reqtype.SelectedValue.ToString();
                //Lblselecttype.Text = selecttype;
            }
        }
        catch (Exception)
        {
            throw;
        }
    }

    protected void DropDownListAgentno_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            if (DropDownListAgentno.SelectedIndex > 0)
            {
                agentno = int.Parse(DropDownListAgentno.SelectedValue.ToString());
                //DDL_CostrecoveryNo.SelectedItem.Text = DropDownListAgentno.SelectedItem.Text.ToString();
                DDL_CostrecoveryNo.SelectedValue = DropDownListAgentno.SelectedValue.ToString();
            }
        }
        catch (Exception)
        {
            throw;
        }
    }

    protected void DDL_Callingtype_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            if (DDL_Callingtype.SelectedIndex > 0)
            {
                string callingtype = DDL_Callingtype.SelectedValue.ToString();

                //if (callingtype == "Active")
                //{
                //     statcode = "IF";
                //     pstatcode = "('SP','PP','FP')";


                //}
                //else
                //{
                //     statcode = "LA";
                //     pstatcode = "LA";

                //}
            }
        }
        catch (Exception)
        {
            throw;
        }
    }
    protected void DDLPolicytype_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            if (DDLPolicytype.SelectedIndex > 0)
            {
                policytype = DDLPolicytype.SelectedValue.ToString();
            }
        }
        catch (Exception)
        {
            throw;
        }
    }

    protected void DDL_CostrecoveryNo_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            if (DDL_CostrecoveryNo.SelectedIndex > 0)
            {
                int costagentno = int.Parse(DDL_CostrecoveryNo.SelectedValue.ToString());
                //costagentno = int.Parse(DDL_CostrecoveryNo.SelectedItem.Text.ToString());

            }
        }
        catch (Exception)
        {
            throw;
        }
    }
    protected void RadioButton1_CheckedChanged(object sender, EventArgs e)
    {
        if (ddlBranchCode.SelectedItem.Text != "--SELECT--")
        {
            Panel3.Visible = true;
            get_RecoveryAgentNo();
            Panel2.Visible = false;
            Panel5.Visible = false;
        }
        else
        {
            ScriptManager.RegisterStartupScript(this, this.GetType(), "Message", " alert ('Branch code cannot be empty!!!');", true);
            return;
        }
    }
    protected void RadioButton2_CheckedChanged(object sender, EventArgs e)
    {
        if (ddlBranchCode.SelectedItem.Text != "--SELECT--")
        {
            Panel2.Visible = true;
            get_AgentNo();
            Panel3.Visible = false;
            Panel5.Visible = false;
        }
        else
        {
            ScriptManager.RegisterStartupScript(this, this.GetType(), "Message", " alert ('Branch code cannot be empty!!!');", true);
            return;
        }
    }

    protected void RadioButton3_CheckedChanged(object sender, EventArgs e)
    {
        if (ddlBranchCode.SelectedItem.Text != "--SELECT--")
        {
            Panel5.Visible = true;
            get_RecruimentRecoveryAgentNo();
            Panel2.Visible = false;
            Panel3.Visible = false;
        }
        else
        {
            RadioButton3.Checked = false;
            ScriptManager.RegisterStartupScript(this, this.GetType(), "Message", " alert ('Branch code cannot be empty!!!');", true);
            return;
        }
    }

    protected void ViewPolicy2_Click(object sender, EventArgs e)
    {
        DataSet ds = new DataSet();
        DataSet dsPolicies = new DataSet();
        string emp_Id = Session["LoginId"].ToString();
        if (ddlCostrecoveryNo.SelectedValue.ToString() == "--SELECT--")
        {
            ScriptManager.RegisterStartupScript(this, this.GetType(), "Message", " alert ('Please Select A Cost Recovery Agent No Type!!!');", true);
            return;
        }
        else
        {
            string Recovery_CostAgent_no = ddlCostrecoveryNo.SelectedValue.ToString();
            Session["Agent_no"] = Recovery_CostAgent_no;
        }
        string call_type = DDL_Callingtype.SelectedItem.Text.ToString();
        Session["call_type"] = call_type;
        string job_type = DropDownList_reqtype.SelectedItem.Text.ToString();
        Session["job_type"] = job_type;
        string cscBranch = Session["cscBranch"].ToString();

        if (DDL_Callingtype.SelectedIndex > 0)
        {
            string callingtype = DDL_Callingtype.SelectedValue.ToString();
            dsgetserialno = Facade.Servers.get_serial_no(callingtype);
            if (dsgetserialno.Tables[0].Rows.Count > 0)
            {
                //string serialno = dsgetserialno.Tables[0].Rows[0][0].ToString();
                string description = dsgetserialno.Tables[0].Rows[0][1].ToString();
                //Session["serial_no"] = serialno;
                Session["des"] = description;
            }
        }

        if (fuattach.HasFile)
        {
            try
            {
                string strFilepPath;

                FileInfo fi = new FileInfo(fuattach.PostedFile.FileName);
                string ext = fi.Extension;
                string connString = "";

                string filename = Path.GetFullPath(fuattach.PostedFile.FileName);

                string DirectoryPath = Server.MapPath("~/files//");
                strFilepPath = DirectoryPath + fuattach.FileName;
                Directory.CreateDirectory(DirectoryPath);
                fuattach.SaveAs(strFilepPath);

                //ScriptManager.RegisterStartupScript(this, this.GetType(), "Message", " alert ('" + filename + "');", true);
                if (ext == ".xls")
                {
                    connString = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + strFilepPath + ";Extended Properties=\"Excel 8.0;HDR=No;IMEX=2\"";

                    string query = "SELECT f1 FROM [Sheet1$]";

                    OleDbConnection conn = new OleDbConnection(connString);
                    if (conn.State == ConnectionState.Closed)
                        conn.Open();
                    OleDbCommand cmd = new OleDbCommand(query, conn);
                    OleDbDataAdapter da = new OleDbDataAdapter(cmd);
                    DataSet dspolicyNo = new DataSet();
                    da.Fill(dspolicyNo);
                    conn.Close();
                    da.Dispose();
                    conn.Close();
                    conn.Dispose();

                    for (int i = 0; i < dspolicyNo.Tables[0].Rows.Count; i++)
                    {
                        Facade.Servers.saveJobRequestPolicyLog(emp_Id, dspolicyNo.Tables[0].Rows[i]["f1"].ToString());
                    }

                    DataSet dsMissingData = new DataSet();
                    dsMissingData = Facade.Servers.getMissingRecords(emp_Id, cscBranch);
                    Session["newdsMissingpolicies"] = dsMissingData;

                    File.Delete(strFilepPath);
                    Facade.Servers.RemoveUnwantedPolicyLog(emp_Id, cscBranch);
                    Facade.Servers.removePhoneIsNullPolicyLog(emp_Id);

                    DataSet dsData = new DataSet();
                    dsData = Facade.Servers.getPolicyLog(emp_Id);

                    if (dsData.Tables[0].Rows.Count > 0)
                    {
                        dsPolicies = Facade.Servers.getUploadedPolicyDetails(emp_Id);
                        Session["newdspolicies"] = dsPolicies;
                        checkedRadioButton = "radio1";
                        Session["checkedRadioButton"] = checkedRadioButton;
                        Response.Redirect("~/Policystatus.aspx", false);
                    }
                    else
                    {
                        ScriptManager.RegisterStartupScript(this, this.GetType(), "Message", " alert ('No records found!!');", true);
                    }
                }
                else if (ext.Trim() == ".xlsx")
                {
                    connString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + strFilepPath + ";Extended Properties=\"Excel 12.0;HDR=No;IMEX=2\"";

                    string query = "SELECT * FROM [Sheet1$]";
                    OleDbConnection conn = new OleDbConnection(connString);
                    if (conn.State == ConnectionState.Closed)
                        conn.Open();

                    OleDbCommand cmd = new OleDbCommand(query, conn);
                    OleDbDataAdapter da = new OleDbDataAdapter(cmd);
                    DataSet dspolicyNo = new DataSet();
                    da.Fill(dspolicyNo);
                    conn.Close();
                    da.Dispose();
                    conn.Close();
                    conn.Dispose();

                    for (int i = 0; i < dspolicyNo.Tables[0].Rows.Count; i++)
                    {
                        Facade.Servers.saveJobRequestPolicyLog(emp_Id, dspolicyNo.Tables[0].Rows[i]["f1"].ToString());
                    }

                    File.Delete(strFilepPath);
                    Facade.Servers.RemoveUnwantedPolicyLog(emp_Id, cscBranch);
                    Facade.Servers.removePhoneIsNullPolicyLog(emp_Id);

                    dsPolicies = Facade.Servers.getUploadedPolicyDetails(emp_Id);
                    Session["newdspolicies"] = dsPolicies;
                    Response.Redirect("~/Policystatus.aspx", false);
                }
                else if (ext == ".txt")
                {
                    if (!File.Exists(strFilepPath))
                    {
                        ScriptManager.RegisterStartupScript(this, this.GetType(), "Message", " alert ('File does not exist!!');", true);
                    }
                    else
                    {
                        if (new FileInfo(strFilepPath).Length == 0)
                        {
                            ScriptManager.RegisterStartupScript(this, this.GetType(), "Message", " alert ('File is empty!!');", true);
                        }
                        else
                        {
                            string strConnString = "Driver={Microsoft Text Driver (*.txt; *.csv)};Dbq=" + strFilepPath + "; Extensions=asc,csv,tab,txt; Persist Security Info=False";

                            DataTable dt = new DataTable();
                            DataColumn col = new DataColumn("policy_no");
                            col.DataType = System.Type.GetType("System.String");
                            dt.Columns.Add(col);

                            string[] aa = File.ReadAllLines(strFilepPath);
                            foreach (var item in aa)
                            {
                                DataRow dr = dt.NewRow();
                                dr[0] = item.ToString();
                                dt.Rows.Add(dr);
                            }
                            DataSet dsNew = new DataSet();
                            dsNew.Tables.Add(dt);

                            for (int i = 0; i < dsNew.Tables[0].Rows.Count; i++)
                            {
                                int count = i + 1;
                                Facade.Servers.saveJobRequestPolicyLog(emp_Id, dsNew.Tables[0].Rows[i]["policy_no"].ToString());
                            }

                            File.Delete(strFilepPath);
                            Facade.Servers.RemoveUnwantedPolicyLog(emp_Id, cscBranch);
                            Facade.Servers.removePhoneIsNullPolicyLog(emp_Id);

                            dsPolicies = Facade.Servers.getUploadedPolicyDetails(emp_Id);
                            Session["newdspolicies"] = dsPolicies;
                            checkedRadioButton = "radio1";
                            Session["checkedRadioButton"] = checkedRadioButton;
                            Response.Redirect("~/Policystatus.aspx", false);
                        }
                    }
                }
                Facade.Servers.removeJobRequestPolicyLog(emp_Id);
  
            }
            catch (Exception ex)
            {
                //throw;
                string error;
                error = new ApplicationException(" Error Occured.. Try Again!!!!", ex).Message;
                ScriptManager.RegisterStartupScript(this, this.GetType(), "", "confirm ('" + error + "');", true);
                //ClientScript.RegisterClientScriptBlock(this.GetType(), "alert", ex.ToString());
                Facade.Servers.removeJobRequestPolicyLog(emp_Id);
            }
        }       
    }

    protected void viewPolicyRecruitment_Click(object sender, EventArgs e)
    {
        DataSet ds = new DataSet();
        DataSet dsPolicies = new DataSet();
        string emp_Id = Session["LoginId"].ToString();
        if (ddlRecoveryAgent.SelectedValue.ToString() == "--SELECT--")
        {
            ScriptManager.RegisterStartupScript(this, this.GetType(), "Message", " alert ('Please Select A Cost Recovery Agent No Type!!!');", true);
            return;
        }
        else
        {
            string Recovery_CostAgent_no = ddlRecoveryAgent.SelectedValue.ToString();
            Session["Agent_no"] = Recovery_CostAgent_no;
        }
        string call_type = DDL_Callingtype.SelectedItem.Text.ToString();
        Session["call_type"] = call_type;
        string job_type = DropDownList_reqtype.SelectedItem.Text.ToString();
        Session["job_type"] = job_type;
        string cscBranch = Session["cscBranch"].ToString();

        if (DDL_Callingtype.SelectedIndex > 0)
        {
            string callingtype = DDL_Callingtype.SelectedValue.ToString();
            dsgetserialno = Facade.Servers.get_serial_no(callingtype);
            if (dsgetserialno.Tables[0].Rows.Count > 0)
            {
                string description = dsgetserialno.Tables[0].Rows[0][1].ToString();
                Session["des"] = description;
            }
        }

        Facade.Servers.removeJobRequestRecruitmentLog(emp_Id);

        if (fuattach1.HasFile)
        {
            try
            {
                string strFilepPath;

                FileInfo fi = new FileInfo(fuattach1.PostedFile.FileName);
                string ext = fi.Extension;
                string connString = "";

                string filename = Path.GetFullPath(fuattach1.PostedFile.FileName);

                string DirectoryPath = Server.MapPath("~/files//");
                strFilepPath = DirectoryPath + fuattach1.FileName;
                Directory.CreateDirectory(DirectoryPath);
                fuattach1.SaveAs(strFilepPath);

                //ScriptManager.RegisterStartupScript(this, this.GetType(), "Message", " alert ('" + filename + "');", true);
                if (ext == ".xls")
                {
                    connString = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + strFilepPath + ";Extended Properties=\"Excel 8.0;HDR=No;IMEX=2\"";

                    string query = "SELECT f1,f2 FROM [Sheet1$] where f1 is not null and f2 is not null";

                    OleDbConnection conn = new OleDbConnection(connString);
                    if (conn.State == ConnectionState.Closed)
                        conn.Open();
                    OleDbCommand cmd = new OleDbCommand(query, conn);
                    OleDbDataAdapter da = new OleDbDataAdapter(cmd);
                    DataSet dspolicyNo = new DataSet();
                    da.Fill(dspolicyNo);
                    conn.Close();
                    da.Dispose();
                    conn.Close();
                    conn.Dispose();                    

                    for (int i = 0; i < dspolicyNo.Tables[0].Rows.Count; i++)
                    {
                        string cus_name = dspolicyNo.Tables[0].Rows[i]["f1"].ToString();
                        string client_phone = dspolicyNo.Tables[0].Rows[i]["f2"].ToString();
                        Facade.Servers.saveJobRequestRecruitmentLog(emp_Id, cus_name, client_phone);
                    }

                    File.Delete(strFilepPath);

                    //DataSet dsData = new DataSet();
                    //dsData = Facade.Servers.getRecruitmentPolicyLog(emp_Id);

                    DataSet dsRecruitment = new DataSet();
                    dsRecruitment = Facade.Servers.getRecruitmentDetails(emp_Id);
                    /*-----------------Save To Master table--------------------------*/

                    int record_count = dsRecruitment.Tables[0].Rows.Count;
                    string User = emp_Id;
                    DateTime date = DateTime.Now;
                    string submit_date = DateTime.Now.Date.ToString("yyyy-MM-dd");
                    string estimated_date = Convert.ToDateTime(date.AddDays(1)).ToString("yyyy-MM-dd");
                    string status = "Pending";

                    string description = "RECRUITMENT CALLINGS";
                    DataSet recovery_amount = Facade.Servers.get_recovery_amount(description);
                    string ss = recovery_amount.Tables[0].Rows[0][0].ToString();
                    int amount = Convert.ToInt32(Convert.ToDouble(ss));

                    int total = amount * record_count;
                    string Total_cost = Convert.ToString(total);

                    DataSet dsCallCost = Facade.Servers.get_call_cost(call_type);
                    string call_cost = dsCallCost.Tables[0].Rows[0]["COST_PER_JOB"].ToString();

                    DataTable dt = new DataTable();
                    dt.Columns.Add("Client_No");
                    dt.Columns.Add("Policy_No");
                    dt.Columns.Add("Customer_Name");
                    dt.Columns.Add("PhoneNumber");
                    dt.Columns.Add("Due_Date");
                    dt.Columns.Add("Risk_Date");
                    dt.Columns.Add("Premium");
                    dt.Columns.Add("Mode");
                    dt.Columns.Add("cost_agent_no");
                    dt.Columns.Add("serial_No");
                    dt.Columns.Add("Policy_Type");
                    dt.Columns.Add("Description");
                    dt.Columns.Add("SO_CODE");
                    dt.Columns.Add("Branch_Code");
                    dt.Columns.Add("COST_PER_JOB");

                    for (int j = 0; j < dsRecruitment.Tables[0].Rows.Count; j++)
                    {
                        if (Session["AllPolicyDtl"] == null)
                        {
                            DataRow tempRow = dt.NewRow();
                            //tempRow["Client_No"] = rw.Cells[2].Text.ToString();
                            //tempRow["Policy_No"] = rw.Cells[3].Text.ToString();
                            tempRow["Customer_Name"] = dsRecruitment.Tables[0].Rows[j]["cus_name"].ToString();
                            tempRow["PhoneNumber"] = dsRecruitment.Tables[0].Rows[j]["client_phone"].ToString();
                            //tempRow["Due_Date"] = rw.Cells[6].Text.ToString();
                            //tempRow["Risk_Date"] = rw.Cells[5].Text.ToString();
                            tempRow["Premium"] = "0";
                            //tempRow["Mode"] = rw.Cells[9].Text.ToString();
                            string Recovery_Cost_agent_no = ddlRecoveryAgent.SelectedValue.ToString();
                            tempRow["cost_agent_no"] = Recovery_Cost_agent_no;
                            //tempRow["Policy_Type"] = rw.Cells[8].Text.ToString();
                            //tempRow["Description"] = description;
                            //tempRow["SO_CODE"] = Agent_no;
                            tempRow["Branch_Code"] = cscBranch;
                            tempRow["COST_PER_JOB"] = call_cost;
                            //tempRow["SO_CODE"] = policydetails.Tables[0].Rows[0]["so_code"].ToString();
                            //tempRow["Branch_Code"] = policydetails.Tables[0].Rows[0]["REGISTER"].ToString();

                            dt.Rows.Add(tempRow);
                            Session["AllPolicyDtl"] = dt;
                        }
                        else
                        {
                            DataRow tempRow = dt.NewRow();
                            //tempRow["Client_No"] = rw.Cells[2].Text.ToString();
                            //tempRow["Policy_No"] = rw.Cells[3].Text.ToString();
                            tempRow["Customer_Name"] = dsRecruitment.Tables[0].Rows[j]["cus_name"].ToString();
                            tempRow["PhoneNumber"] = dsRecruitment.Tables[0].Rows[j]["client_phone"].ToString();
                            //tempRow["Due_Date"] = rw.Cells[6].Text.ToString();
                            //tempRow["Risk_Date"] = rw.Cells[5].Text.ToString();
                            tempRow["Premium"] = "0";
                            //tempRow["Mode"] = rw.Cells[9].Text.ToString();
                            string Recovery_Cost_agent_no = ddlRecoveryAgent.SelectedValue.ToString();
                            tempRow["cost_agent_no"] = Recovery_Cost_agent_no;
                            //tempRow["Policy_Type"] = rw.Cells[8].Text.ToString();
                            //tempRow["Description"] = description;
                            //tempRow["SO_CODE"] = Agent_no;
                            tempRow["Branch_Code"] = cscBranch;
                            tempRow["COST_PER_JOB"] = call_cost;

                            dt.Rows.Add(tempRow);

                            DataTable dt_2 = (DataTable)Session["AllPolicyDtl"];
                            dt.Merge(dt_2);

                            Session["AllPolicyDtl"] = dt;
                            newdatatable = (DataTable)Session["AllPolicyDtl"];
                        }
                    }

                    int m = Facade.Servers.Save_Job_Requesting_data(User, submit_date, estimated_date, status, Total_cost, newdatatable, call_type, job_type);

                    if (m == 1)
                    {
                        ScriptManager.RegisterStartupScript(this, this.GetType(), "Message", " alert ('Successfully Saved!!') ;window.location='AdminRequestForm.aspx';", true);
                    }
                    else
                    {
                        ScriptManager.RegisterStartupScript(this, this.GetType(), "Message", " alert ('Error!!') ;", true);
                    }
                    //ScriptManager.RegisterStartupScript(this, this.GetType(), "Message", " alert ('No records found!!');", true);

                    /*-------------------------------------------------------------------------------------*/




                    //if (dsData.Tables[0].Rows.Count > 0)
                    //{
                    //    DataTable dtnew = dsData.Tables[0];

                    //    //Build the Text file data.
                    //    string txt = string.Empty;

                    //    //foreach (DataColumn column in dt.Columns)
                    //    //{
                    //    //    //Add the Header row for Text file.
                    //    //    txt += column.ColumnName + "\t\t";
                    //    //}

                    //    //Add new line.
                    //    //txt += "\r\n";

                    //    foreach (DataRow row in dtnew.Rows)
                    //    {
                    //        foreach (DataColumn column in dtnew.Columns)
                    //        {
                    //            //Add the Data rows.
                    //            txt += row[column.ColumnName].ToString() + "\t\t";
                    //        }

                    //        //Add new line.
                    //        txt += "\r\n";
                    //    }

                    //    //Download the Text file.
                    //    Response.Clear();
                    //    Response.Buffer = true;
                    //    Response.AddHeader("content-disposition", "attachment;filename=SqlExport.txt");
                    //    Response.Charset = "";
                    //    Response.ContentType = "application/text";
                    //    Response.Output.Write(txt);

                    //    Response.Flush();
                    //    Response.End();
                    //}
                    //else
                    //{
                    //    ScriptManager.RegisterStartupScript(this, this.GetType(), "Message", " alert ('No records found!!');", true);
                    //}
                }
                else if (ext.Trim() == ".xlsx")
                {
                    connString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + strFilepPath + ";Extended Properties=\"Excel 12.0;HDR=No;IMEX=2\"";

                    string query = "SELECT f1,f2 FROM [Sheet1$] where f1 is not null and f2 is not null";

                    OleDbConnection conn = new OleDbConnection(connString);
                    if (conn.State == ConnectionState.Closed)
                        conn.Open();
                    OleDbCommand cmd = new OleDbCommand(query, conn);
                    OleDbDataAdapter da = new OleDbDataAdapter(cmd);
                    DataSet dspolicyNo = new DataSet();
                    da.Fill(dspolicyNo);
                    conn.Close();
                    da.Dispose();
                    conn.Close();
                    conn.Dispose();

                    for (int i = 0; i < dspolicyNo.Tables[0].Rows.Count; i++)
                    {
                        string cus_name = dspolicyNo.Tables[0].Rows[i]["f1"].ToString();
                        string client_phone = dspolicyNo.Tables[0].Rows[i]["f2"].ToString();
                        Facade.Servers.saveJobRequestRecruitmentLog(emp_Id, cus_name, client_phone);
                    }

                    File.Delete(strFilepPath);

                    //DataSet dsData = new DataSet();
                    //dsData = Facade.Servers.getRecruitmentPolicyLog(emp_Id);


                    DataSet dsRecruitment = new DataSet();
                    dsRecruitment = Facade.Servers.getRecruitmentDetails(emp_Id);
                    /*-----------------Save To Master table--------------------------*/

                    int record_count = dsRecruitment.Tables[0].Rows.Count;
                    string User = emp_Id;
                    DateTime date = DateTime.Now;
                    string submit_date = DateTime.Now.Date.ToString("yyyy-MM-dd");
                    string estimated_date = Convert.ToDateTime(date.AddDays(1)).ToString("yyyy-MM-dd");
                    string status = "Pending";

                    string description = "RECRUITMENT CALLINGS";
                    DataSet recovery_amount = Facade.Servers.get_recovery_amount(description);
                    string ss = recovery_amount.Tables[0].Rows[0][0].ToString();
                    int amount = Convert.ToInt32(Convert.ToDouble(ss));

                    int total = amount * record_count;
                    string Total_cost = Convert.ToString(total);

                    DataSet dsCallCost = Facade.Servers.get_call_cost(call_type);
                    string call_cost = dsCallCost.Tables[0].Rows[0]["COST_PER_JOB"].ToString();

                    DataTable dt = new DataTable();
                    dt.Columns.Add("Client_No");
                    dt.Columns.Add("Policy_No");
                    dt.Columns.Add("Customer_Name");
                    dt.Columns.Add("PhoneNumber");
                    dt.Columns.Add("Due_Date");
                    dt.Columns.Add("Risk_Date");
                    dt.Columns.Add("Premium");
                    dt.Columns.Add("Mode");
                    dt.Columns.Add("cost_agent_no");
                    dt.Columns.Add("serial_No");
                    dt.Columns.Add("Policy_Type");
                    dt.Columns.Add("Description");
                    dt.Columns.Add("SO_CODE");
                    dt.Columns.Add("Branch_Code");
                    dt.Columns.Add("COST_PER_JOB");

                    for (int j = 0; j < dsRecruitment.Tables[0].Rows.Count; j++)
                    {
                        if (Session["AllPolicyDtl"] == null)
                        {
                            DataRow tempRow = dt.NewRow();
                            //tempRow["Client_No"] = rw.Cells[2].Text.ToString();
                            //tempRow["Policy_No"] = rw.Cells[3].Text.ToString();
                            tempRow["Customer_Name"] = dsRecruitment.Tables[0].Rows[j]["cus_name"].ToString();
                            tempRow["PhoneNumber"] = dsRecruitment.Tables[0].Rows[j]["client_phone"].ToString();
                            //tempRow["Due_Date"] = rw.Cells[6].Text.ToString();
                            //tempRow["Risk_Date"] = rw.Cells[5].Text.ToString();
                            tempRow["Premium"] = "0";
                            //tempRow["Mode"] = rw.Cells[9].Text.ToString();
                            string Recovery_Cost_agent_no = ddlRecoveryAgent.SelectedValue.ToString();
                            tempRow["cost_agent_no"] = Recovery_Cost_agent_no;
                            //tempRow["Policy_Type"] = rw.Cells[8].Text.ToString();
                            //tempRow["Description"] = description;
                            //tempRow["SO_CODE"] = Agent_no;
                            tempRow["Branch_Code"] = cscBranch;
                            tempRow["COST_PER_JOB"] = call_cost;
                            //tempRow["SO_CODE"] = policydetails.Tables[0].Rows[0]["so_code"].ToString();
                            //tempRow["Branch_Code"] = policydetails.Tables[0].Rows[0]["REGISTER"].ToString();

                            dt.Rows.Add(tempRow);
                            Session["AllPolicyDtl"] = dt;
                        }
                        else
                        {
                            DataRow tempRow = dt.NewRow();
                            //tempRow["Client_No"] = rw.Cells[2].Text.ToString();
                            //tempRow["Policy_No"] = rw.Cells[3].Text.ToString();
                            tempRow["Customer_Name"] = dsRecruitment.Tables[0].Rows[j]["cus_name"].ToString();
                            tempRow["PhoneNumber"] = dsRecruitment.Tables[0].Rows[j]["client_phone"].ToString();
                            //tempRow["Due_Date"] = rw.Cells[6].Text.ToString();
                            //tempRow["Risk_Date"] = rw.Cells[5].Text.ToString();
                            tempRow["Premium"] = "0";
                            //tempRow["Mode"] = rw.Cells[9].Text.ToString();
                            string Recovery_Cost_agent_no = ddlRecoveryAgent.SelectedValue.ToString();
                            tempRow["cost_agent_no"] = Recovery_Cost_agent_no;
                            //tempRow["Policy_Type"] = rw.Cells[8].Text.ToString();
                            //tempRow["Description"] = description;
                            //tempRow["SO_CODE"] = Agent_no;
                            tempRow["Branch_Code"] = cscBranch;
                            tempRow["COST_PER_JOB"] = call_cost;

                            dt.Rows.Add(tempRow);

                            DataTable dt_2 = (DataTable)Session["AllPolicyDtl"];
                            dt.Merge(dt_2);

                            Session["AllPolicyDtl"] = dt;
                            newdatatable = (DataTable)Session["AllPolicyDtl"];
                        }
                    }

                    int m = Facade.Servers.Save_Job_Requesting_data(User, submit_date, estimated_date, status, Total_cost, newdatatable, call_type, job_type);

                    if (m == 1)
                    {
                        ScriptManager.RegisterStartupScript(this, this.GetType(), "Message", " alert ('Successfully Saved!!') ;window.location='AdminRequestForm.aspx';", true);
                    }
                    else
                    {
                        ScriptManager.RegisterStartupScript(this, this.GetType(), "Message", " alert ('Error!!') ;", true);
                    }

                    //ScriptManager.RegisterStartupScript(this, this.GetType(), "Message", " alert ('No records found!!');", true);

                    /*-------------------------------------------------------------------------------------*/

                    //if (dsData.Tables[0].Rows.Count > 0)
                    //{

                    //    DataTable dtnew = dsData.Tables[0];

                    //    //Build the Text file data.
                    //    string txt = string.Empty;

                    //    //foreach (DataColumn column in dt.Columns)
                    //    //{
                    //    //    //Add the Header row for Text file.
                    //    //    txt += column.ColumnName + "\t\t";
                    //    //}

                    //    //Add new line.
                    //    //txt += "\r\n";

                    //    foreach (DataRow row in dtnew.Rows)
                    //    {
                    //        foreach (DataColumn column in dtnew.Columns)
                    //        {
                    //            //Add the Data rows.
                    //            txt += row[column.ColumnName].ToString() + "\t\t";
                    //        }

                    //        //Add new line.
                    //        txt += "\r\n";
                    //    }

                    //    //Download the Text file.
                    //    Response.Clear();
                    //    Response.Buffer = true;
                    //    Response.AddHeader("content-disposition", "attachment;filename=SqlExport.txt");
                    //    Response.Charset = "";
                    //    Response.ContentType = "application/text";
                    //    Response.Output.Write(txt);

                    //    Response.Flush();
                    //    Response.End();
                    //}
                    //else
                    //{
                    //    ScriptManager.RegisterStartupScript(this, this.GetType(), "Message", " alert ('No records found!!');", true);
                    //}
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
    }

    private object CreateSqlConnection()
    {
        throw new NotImplementedException();
    }

    protected void ddlBranchCode_SelectedIndexChanged(object sender, EventArgs e)
    {
        string branch = ddlBranchCode.SelectedValue.ToString();
        Session["cscBranch"] = branch;

        if (RadioButton1.Checked)
        {
            get_RecoveryAgentNo();
        }
        else if (RadioButton2.Checked)
        {
            get_AgentNo();
        }
    }
}
