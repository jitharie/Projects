﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class ViewCompletedJobs : System.Web.UI.Page
{
    DataSet dsData = new DataSet();
     
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (!this.IsPostBack)
            {
                loadBranch();
            }
        }
        catch (Exception)
        {
            throw;
        }
    }
    protected void ddlBranch_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlBranch.SelectedItem.Text.ToString() != "--Select--")
        {
            string branch = ddlBranch.SelectedItem.Text.ToString();
            string user = Session["LoginId"].ToString();

            dsData = Facade.Servers.loadGridView_Completed_jobs(user, branch);

            GridView_Completed_jobs.DataSource = dsData.Tables[0];
            GridView_Completed_jobs.DataBind();
        }
        else
        {
            ScriptManager.RegisterStartupScript(this, this.GetType(), "Message", " alert ('Please select a branch!!') ;", true);
        }   
    }

    private void loadBranch()
    {
        string user = Session["LoginId"].ToString();

        dsData = Facade.Servers.loadJobCompletedBranch(user);

        ddlBranch.DataSource = dsData.Tables[0];
        ddlBranch.DataValueField = "Branch_Code";
        ddlBranch.DataTextField = "Branch_Code";
        ddlBranch.DataBind();
        ddlBranch.Items.Insert(0, "--Select--");
    }
}
